@echo off
setlocal
pushd "%~dp0"
if not exist "MCKids.nes" (
  echo Copy your M.C. Kids USA ROM here and name it MCKids.nes.
  pause
  popd
  exit /b 1
)
"%~dp0MCKidsRecomp.exe" "%~dp0MCKids.nes" %*
set "GAME_EXIT=%errorlevel%"
echo.
echo Game exited with code %GAME_EXIT%.
pause
popd
endlocal
