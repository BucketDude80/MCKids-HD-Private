@echo off
setlocal
pushd "%~dp0"
if not exist "MCKids.nes" (
 echo Place this preview in your existing game folder beside MCKids.nes and SDL2.dll.
 pause
 popd
 exit /b 1
)
"%~dp0MCKidsRecomp-Widescreen.exe" "%~dp0MCKids.nes" --widescreen %*
set "GAME_EXIT=%errorlevel%"
echo.
echo Game exited with code %GAME_EXIT%.
pause
popd
endlocal
