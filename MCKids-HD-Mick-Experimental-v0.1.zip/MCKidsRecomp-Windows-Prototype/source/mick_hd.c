/*
 * Experimental HD Mick replacement, transparent PNG on 4x game presentation.
 * Uses game's first 8 OAM sprite slots to position its player. Importantly,
 * the NES machine and its timings are NOT modified. Optional, original default.
 *
 * Known limitations: first-player Mick only; guessed animation selection; the
 * 12 illustration poses are concept art, not a verified frame-for-frame match;
 * foreground sprite compositing isn't fully solved; original sprite masking
 * within 16x32 can hide intersecting sprites. No soundtrack/level HD support.
 */
#include "mick_hd.h"
#include "cyc_render.h"
#include "cyc_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_NO_HDR
#include "engine/runner/src/stb_image.h"

#define SCALE 4
#define CELL_W 96
#define CELL_H 128
#define MAX_W 512
#define MAX_H 240
static const char *const pose_names[]={"idle","blink","walk1","walk2","walk3","walk4",
                                      "jump_start","jump","land","crouch","push","victory"};
#define POSES 12
static uint8_t *poses[POSES];
static uint32_t *output;
static bool active, image_ok, attempted;
static uint64_t serial, last_serial=(uint64_t)-1;
static int output_w, last_x=-1, last_y=-1, x_position, y_position, pose=0;
static int last_dx, jump_timer, facing_left, player_tiles;
static unsigned ticks;

void mick_hd_enable(void){ active=true; }

void mick_hd_power_on(void){
    serial=0;last_serial=(uint64_t)-1;
    last_x=last_y=-1;ticks=0;jump_timer=0;pose=0;facing_left=0;x_position=-1;player_tiles=0;
    if(active)cyc_render_capture_background(true);
}
static bool load_pngs(void){
    if(attempted)return image_ok;
    attempted=true;
    for(int i=0;i<POSES;i++){
        char path[256]; int w=0,h=0,n=0;
        snprintf(path,sizeof path,"hd_mick/%s.png",pose_names[i]);
        poses[i]=stbi_load(path,&w,&h,&n,4);
        if(!poses[i]||w!=CELL_W||h!=CELL_H){
            fprintf(stderr,"[Mick HD] cannot load %s (expected %dx%d RGBA); leaving original graphics\n",path,CELL_W,CELL_H);
            return false;
        }
    }
    image_ok=true;
    fprintf(stderr,"[Mick HD] 12 sprite assets loaded; 4x renderer active (experimental)\n");
    return true;
}

/* Track the in-game OAM player; first 8 NES slots are his 16x32 character in
 * the tested USA build. Playfield type $02 avoids title-screen false matches. */
void mick_hd_frame(void){
    if(!active)return;
    serial++;
    const uint8_t *ram=cyc_cpu_ram(),*o=cyc_render_oam();
    if(ram[0x430]!=2||o[0]>=208){x_position=-1;last_x=last_y=-1;return;}
    /* Mick's 16x32 graphic normally uses eight 8x8 OAM slots. At the
     * screen edge the game may draw just four. Remaining slots then contain
     * completely different objects. Never count those as player pixels. */
    int minx=256,miny=240, maxx=0,maxy=0, count=0;
    int flip_count=0;
    for(int i=0;i<8;i++){
        int sy=o[i*4],tile=o[i*4+1],attrib=o[i*4+2],sx=o[i*4+3];
        /* Player uses sprite palette 1. NPCs/items typically use other
         * palettes. Stop at the first non-player slot in the OAM run. */
        if(sy>=239 || sx>=248 || (attrib&3)!=1)break;
        /* Recognised player sprite tiles in the ordinary animations. Other
         * special animations deliberately fall back to original NES drawing
         * until the extra poses have been mapped from a captured save. */
        bool ordinary=tile<=0x1f || tile==0x44 || tile==0x45 ||
                      tile==0x64 || tile==0x65 || tile==0x74 || tile==0x75;
        if(!ordinary)break;
        if(sx<minx)minx=sx;
        if(sy<miny)miny=sy;
        if(sx>maxx)maxx=sx;
        if(sy>maxy)maxy=sy;
        flip_count+=(attrib&0x40)!=0;
        count++;
    }
    /* If OAM was reallocated by an interaction (e.g. carrying a block),
     * do not place a second, potentially stale, HD character elsewhere. */
    /* Mixed animation layouts should be left to the NES renderer for now;
     * covering only half a special pose can create a duplicate figure. */
    bool special_tail=false;
    if(count>=4 && count<8){
        int i=count;
        int next_attr=o[i*4+2],next_x=o[i*4+3],next_y=o[i*4];
        special_tail=((next_attr&3)==1 && next_y<239 &&
                      abs(next_x-minx)<=16 && abs(next_y-miny)<=32);
    }
    if(count<4||special_tail||maxx-minx>8||maxy-miny>24||minx>240||miny>205){
        x_position=-1;last_x=last_y=-1;return;
    }
    facing_left=(flip_count*2>count);
    player_tiles=count;
    x_position=minx;y_position=miny+1;
    int dx=last_x<0?0:minx-last_x;
    int dy=last_y<0?0:miny-last_y;
    ++ticks;
    if(dy || o[1]==0x44){jump_timer=5;}
    else if(jump_timer>0)--jump_timer;
    /* Sprite tile #04/#06 identifies running even with a stationary player
     * screen X (the camera scrolls the level rather than the character). */
    bool stepping=(o[1]==0x04 || o[1]==0x06 || dx!=0);
    if(jump_timer>0)pose=(dy>0 && jump_timer==1)?8:7;
    else if(stepping)pose=2+(ticks/5)%4;
    else if(o[13]==0x01)pose=1;  /* short blink frame */
    else pose=0;
    last_x=minx;last_y=miny;last_dx=dx;
}

static uint32_t blend(uint32_t under,const uint8_t *rgba){
    unsigned a=rgba[3];
    if(a==255)return 0xFF000000u|((uint32_t)rgba[0]<<16)|((uint32_t)rgba[1]<<8)|rgba[2];
    if(!a)return under;
    unsigned b=255-a;
    unsigned r=(rgba[0]*a+((under>>16)&255)*b+127)/255;
    unsigned g=(rgba[1]*a+((under>>8)&255)*b+127)/255;
    unsigned bl=(rgba[2]*a+(under&255)*b+127)/255;
    return 0xFF000000u|(r<<16)|(g<<8)|bl;
}

const uint32_t *mick_hd_present(int *width,int *height){
    if(!active || !load_pngs())return NULL;
    int w=0,h=0;
    const uint32_t *native=cyc_render_present(&w,&h);
    if(!native || w<256||w>MAX_W||h!=MAX_H)return NULL;
    if(!output){output=(uint32_t *)malloc((size_t)MAX_W*MAX_H*SCALE*SCALE*sizeof(uint32_t));if(!output)return NULL;}
    /* Only regenerate when the machine completed a frame. */
    if(last_serial==serial && output_w==w){*width=w*SCALE;*height=h*SCALE;return output;}
    const int sw=w*SCALE;
    for(int y=0;y<h;y++){
        const uint32_t *in=native+(size_t)y*w;
        for(int sy=0;sy<SCALE;sy++){
            uint32_t *dst=output+(size_t)(y*SCALE+sy)*sw;
            for(int x=0;x<w;x++){
                uint32_t c=in[x];for(int sx=0;sx<SCALE;sx++)dst[x*SCALE+sx]=c;
            }
        }
    }
    if(x_position>=0 && x_position<=240 && y_position<208){
        static uint32_t background[256*240];
        if(cyc_render_background(background)){
            int origin=cyc_render_native_origin(w);
            const uint8_t *o=cyc_render_oam();
            /* Restore only the pixels belonging to Mick's actual NES
             * sprite tiles. The v0.1 rectangular erase could overwrite
             * neighbouring blocks, enemies and carry-object pixels. */
            for(int i=0;i<player_tiles;i++){
                const uint8_t *slot=&o[i*4];
                int y0=slot[0]+1,x0=slot[3];
                unsigned attr=slot[2];
                int palette=16+(attr&3)*4;
                for(int dy=0;dy<8;dy++){
                    int y=y0+dy;
                    if(y<0||y>=240)continue;
                    int row=(attr&0x80)?7-dy:dy;
                    uint16_t pattern=(uint16_t)(cyc_render_line_sprite_table(y)+slot[1]*16+row);
                    uint8_t lo=cyc_render_chr(pattern),hi=cyc_render_chr((uint16_t)(pattern+8));
                    for(int dx=0;dx<8;dx++){
                        int x=x0+dx,sx=x+origin;
                        if(x<0||x>=256||sx<0||sx>=w)continue;
                        if(x<8 && !(cyc_render_line_mask(y)&0x04))continue;
                        int bit=(attr&0x40)?dx:7-dx;
                        unsigned pixel=((lo>>bit)&1)|(((hi>>bit)&1)<<1);
                        if(!pixel)continue;
                        if(native[(size_t)y*w+sx]!=cyc_render_color(palette+pixel))continue;
                        uint32_t back=background[y*256+x];
                        for(int yy=0;yy<SCALE;yy++){
                            uint32_t *dst=output+(size_t)(y*SCALE+yy)*sw+(size_t)sx*SCALE;
                            for(int xx=0;xx<SCALE;xx++)dst[xx]=back;
                        }
                    }
                }
            }
        }
        /* Anchor bottom centre to original 16x32 NES character, but allow a
         * 24px-wide sprite silhouette. All PNGs pre-scaled to 96x128 canvas. */
        int ox=(x_position+cyc_render_native_origin(w)-4)*SCALE;
        int oy=(y_position)*SCALE;
        const uint8_t *img=poses[pose];
        for(int y=0;y<CELL_H;y++){
            int sy=oy+y;if(sy<0||sy>=h*SCALE)continue;
            for(int x=0;x<CELL_W;x++){
                int sx=ox+x;if(sx<0||sx>=sw)continue;
                const uint8_t *rgba=img+4*((size_t)y*CELL_W+(facing_left?(CELL_W-1-x):x));
                if(rgba[3]){uint32_t *p=output+(size_t)sy*sw+sx;*p=blend(*p,rgba);}
            }
        }
    }
    last_serial=serial;output_w=w;
    *width=w*SCALE;*height=h*SCALE;
    return output;
}
