/*
 * Experimental HD Mick replacement, transparent PNG on 4x game presentation.
 * Finds player tile groups in NES OAM, including shifted/short animation
 * layouts used during throwing and crouching. Importantly,
 * the NES machine and its timings are NOT modified. Optional, original default.
 *
 * Known limitations: first-player Mick only; guessed animation selection; the
 * 13 illustration poses are concept art, not a verified frame-for-frame match;
 * foreground sprite compositing isn't fully solved; original sprite masking
 * within 16x32 can hide intersecting sprites. No soundtrack/level HD support.
 */
#include "mick_hd.h"
#include "cyc_render.h"
#include "cyc_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_NO_HDR
#include "engine/runner/src/stb_image.h"

#define SCALE 4
#define CELL_W 96
#define CELL_H 128
#define MAX_W 512
#define MAX_H 240
static const char *const pose_names[]={"idle","blink","walk1","walk2","walk3","walk4",
                                      "jump_start","jump","land","crouch","push","victory","carry","carry_crouch",
                                      "spin_side_a","spin_diag_a","spin_side_b","spin_diag_b"};
#define POSES 18
static uint8_t *poses[POSES];
static int pose_width[POSES],pose_height[POSES];
static uint32_t *output;
static bool active, image_ok, attempted;
static uint64_t serial, last_serial=(uint64_t)-1;
static int output_w, last_x=-1, last_y=-1, x_position, y_position, pose=0;
static int last_dx, jump_timer, facing_left, upside_down, carrying, player_tiles, player_first;
static int carried_block_start=-1;
static int spin_mode=0;
static unsigned ticks;

void mick_hd_enable(void){ active=true; }

void mick_hd_power_on(void){
    serial=0;last_serial=(uint64_t)-1;
    last_x=last_y=-1;ticks=0;jump_timer=0;pose=0;facing_left=upside_down=carrying=0;x_position=-1;player_tiles=0;player_first=0;carried_block_start=-1;spin_mode=0;
    if(active)cyc_render_capture_background(true);
}
static bool load_pngs(void){
    if(attempted)return image_ok;
    attempted=true;
    for(int i=0;i<POSES;i++){
        char path[256]; int w=0,h=0,n=0;
        snprintf(path,sizeof path,"hd_mick/%s.png",pose_names[i]);
        poses[i]=stbi_load(path,&w,&h,&n,4);
        int expected_w=(i>=14)?128:CELL_W;
        int expected_h=(i>=14)?128:CELL_H;
        if(!poses[i]||w!=expected_w||h!=expected_h){
            fprintf(stderr,"[Mick HD] cannot load %s (expected %dx%d RGBA); leaving original graphics\n",path,expected_w,expected_h);
            return false;
        }
        pose_width[i]=w;pose_height[i]=h;
    }
    image_ok=true;
    fprintf(stderr,"[Mick HD] 18 sprite assets loaded; 4x renderer active (experimental)\n");
    return true;
}

/* Locate Mick by the contiguous palette-1 tile group, rather than assuming
 * he always occupies OAM slots 0-7. When a block is thrown the game puts the
 * flying object's four tiles in front of Mick's OAM tiles. When crouching,
 * Mick instead uses SIX tiles, with 0x22/0x23 and 0x32/0x33 body tiles.
 * Do not cover non-player sprites when the evidence is ambiguous. */
static bool player_tile(unsigned tile){
    return tile<=0x3f || tile==0x44 || tile==0x45 ||
           tile==0x40 || tile==0x41 || tile==0x50 || tile==0x51 ||
           tile==0x54 || tile==0x55 || tile==0x64 || tile==0x65 ||
           tile==0x74 || tile==0x75;
}

void mick_hd_frame(void){
    if(!active)return;
    serial++;
    const uint8_t *ram=cyc_cpu_ram(),*o=cyc_render_oam();
    if(ram[0x430]!=2){x_position=-1;last_x=last_y=-1;return;}
    int best_start=-1,best_count=0,best_minx=0,best_miny=0;
    int best_maxy=0,best_flips=0,best_upside=0,best_score=-100000;
    /* 48 of the 64 OAM slots are examined. Only contiguous player-colour
     * groups are admitted; sprites with other palettes terminate a group. */
    for(int start=0;start<48;start++){
        int mx=256,my=240,xmax=0,ymax=0,flip=0,vertical=0,count=0;
        for(int i=start;i<64 && count<8;i++){
            int sy=o[4*i],tile=o[4*i+1],attrib=o[4*i+2],sx=o[4*i+3];
            if(sy>=239 || sx>=248 || (attrib&3)!=1 || !player_tile((unsigned)tile))break;
            int min_x=sx<mx?sx:mx,max_x=sx>xmax?sx:xmax;
            int min_y=sy<my?sy:my,max_y=sy>ymax?sy:ymax;
            if(max_x-min_x>8 || max_y-min_y>24)break;
            mx=min_x;xmax=max_x;my=min_y;ymax=max_y;
            flip+=!!(attrib&0x40);vertical+=!!(attrib&0x80);
            count++;
        }
        if(count<4 || mx>240 || my>205 || xmax-mx!=8 ||
           (ymax-my!=8 && ymax-my!=16 && ymax-my!=24))continue;
        /* For the target ROM, Mick's tile layout has two columns per row
         * (except while carrying a block). Pick the candidate nearest the
         * previously tracked player to avoid mistaking nearby enemies. */
        int score=count*100-start;
        if(last_x>=0 && abs(mx-last_x)<=24 && abs(my-last_y)<=32)score+=400;
        if(score>best_score){best_score=score;best_start=start;best_count=count;
            best_minx=mx;best_miny=my;best_maxy=ymax;best_flips=flip;best_upside=vertical;}
    }
    /* Triangle-box impact spins use 32px wide sprite groups, not Mick's
     * usual 16px column pair. Recognize the two observed sprite arrangements
     * explicitly. Do not turn off the HD overlay during these transitions. */
    spin_mode=0;
    if((o[2]&3)==1 && o[0]<239 &&
       o[1]==0x40 && o[5]==0x41 && o[17]==0x50 && o[21]==0x51){
        spin_mode=1;best_start=0;best_count=8;
    }else if((o[2]&3)==1 && o[0]<239 &&
             o[1]==0x0a && o[5]==0x0b && o[9]==0x19 && o[13]==0x1a){
        spin_mode=2;best_start=0;best_count=11;
    }else if((o[2]&3)==1 && o[0]<239 && (o[2]&0xc0)==0xc0 &&
             o[1]==0x04 && o[5]==0x05 && o[9]==0x14 &&
             o[13]==0x15 && o[4*10+1]==0x55){
        /* Inverted diagonal: the NES rearranges eleven CHR tiles, with
         * both flip flags set, mid-way through a triangle-box tumble. */
        spin_mode=2;best_start=0;best_count=11;
    }
    if(spin_mode){
        best_minx=256;best_miny=240;best_maxy=0;best_flips=best_upside=0;
        int maxx=0;
        for(int i=0;i<best_count;i++){
            int x=o[(best_start+i)*4+3],y=o[(best_start+i)*4];
            if(x<best_minx)best_minx=x;if(x>maxx)maxx=x;
            if(y<best_miny)best_miny=y;if(y>best_maxy)best_maxy=y;
        }
        /* The 32x32 spinning sprite is positioned around its NES OAM centre. */
        x_position=best_minx+4+((maxx-best_minx+8)-32)/2;
        y_position=best_miny+1+((best_maxy-best_miny+8)-32)/2;
        player_first=best_start;player_tiles=best_count;
        facing_left=upside_down=carrying=0;carried_block_start=-1;
        pose=(spin_mode==1?14:15)+((ticks/4)%2)*2;
        ++ticks;last_x=best_minx;last_y=y_position;last_dx=0;
        return;
    }
    if(best_start<0){x_position=-1;last_x=last_y=-1;carried_block_start=-1;return;}
    player_first=best_start;player_tiles=best_count;
    facing_left=best_flips*2>best_count;
    upside_down=best_upside*2>best_count;
    const unsigned head=o[player_first*4+1];
    /* Holding a block is not a single sprite layout. In particular, crouched
     * carrying Mick uses FIVE sprites (21,22,23,32,33) and standing up can
     * briefly use head 20 with body tiles 40/41 and 50/51. Detect the actual
     * 2x2 carried block near Mick, rather than identifying the pose only by
     * his first tile ID. The same block tiles appear in other parts of a level,
     * so their proximity to the player's head matters. */
    int block_first=-1;
    for(int j=0;j<48 && j+3<64;j++){
        const uint8_t *b=o+j*4;
        if((b[1]!=0x4a && b[1]!=0x4c) || (b[2]&3)!=0 || b[0]>=239)continue;
        if(o[(j+1)*4+1]!=b[1]+1 || o[(j+2)*4+1]!=b[1]+0x10 ||
           o[(j+3)*4+1]!=b[1]+0x11)continue;
        int bx=b[3],by=b[0];
        if(abs((bx+4)-(best_minx+4))<=12 &&
           by>=best_miny-20 && by<=best_miny+8){
            block_first=j;break;
        }
    }
    carrying=(head==0x54 || head==0x55 || block_first>=0);
    carried_block_start=block_first;
    /* In the crouched carrying pose the head is tile 0x21, with FIVE tiles
     * total, not the 6 of an ordinary crouch. Both have a 16px Y span.
     * Re-anchor the 32px HD canvas to the original feet for both poses. */
    bool crouching=(best_count==5 || best_count==6) &&
                    best_maxy-best_miny==16;
    int new_y=best_miny+1-(crouching?8:0);
    /* The illustrated carry-crouch silhouette extends three pixels below the
     * NES foot baseline; adjust presentation only, not hitboxes or physics. */
    if(crouching && carrying)new_y-=3;
    x_position=best_minx;y_position=new_y;
    int dx=last_x<0?0:best_minx-last_x;
    int dy=last_y<0?0:new_y-last_y;
    ++ticks;
    if(head==0x44)jump_timer=5;
    else if(head==0x04 || head==0x06)jump_timer=0; /* walk uphill/downhill */
    else if(abs(dy)>2 && !carrying && !crouching)jump_timer=5;
    else if(jump_timer>0)--jump_timer;
    bool stepping=(head==0x04 || head==0x06 || dx!=0);
    if(crouching && carrying)pose=13;
    else if(crouching)pose=9;
    else if(carrying)pose=12;
    else if(jump_timer>0)pose=(dy>0 && jump_timer==1)?8:7;
    else if(stepping)pose=2+(ticks/5)%4;
    else if(o[(player_first+3)*4+1]==0x01)pose=1;
    else pose=0;
    last_x=best_minx;last_y=new_y;last_dx=dx;
}

static uint32_t blend(uint32_t under,const uint8_t *rgba){
    unsigned a=rgba[3];
    if(a==255)return 0xFF000000u|((uint32_t)rgba[0]<<16)|((uint32_t)rgba[1]<<8)|rgba[2];
    if(!a)return under;
    unsigned b=255-a;
    unsigned r=(rgba[0]*a+((under>>16)&255)*b+127)/255;
    unsigned g=(rgba[1]*a+((under>>8)&255)*b+127)/255;
    unsigned bl=(rgba[2]*a+(under&255)*b+127)/255;
    return 0xFF000000u|(r<<16)|(g<<8)|bl;
}

const uint32_t *mick_hd_present(int *width,int *height){
    if(!active || !load_pngs())return NULL;
    int w=0,h=0;
    const uint32_t *native=cyc_render_present(&w,&h);
    if(!native || w<256||w>MAX_W||h!=MAX_H)return NULL;
    if(!output){output=(uint32_t *)malloc((size_t)MAX_W*MAX_H*SCALE*SCALE*sizeof(uint32_t));if(!output)return NULL;}
    /* Only regenerate when the machine completed a frame. */
    if(last_serial==serial && output_w==w){*width=w*SCALE;*height=h*SCALE;return output;}
    const int sw=w*SCALE;
    for(int y=0;y<h;y++){
        const uint32_t *in=native+(size_t)y*w;
        for(int sy=0;sy<SCALE;sy++){
            uint32_t *dst=output+(size_t)(y*SCALE+sy)*sw;
            for(int x=0;x<w;x++){
                uint32_t c=in[x];for(int sx=0;sx<SCALE;sx++)dst[x*SCALE+sx]=c;
            }
        }
    }
    if(x_position>=0 && x_position<=240 && y_position<208){
        static uint32_t background[256*240];
        if(cyc_render_background(background)){
            int origin=cyc_render_native_origin(w);
            const uint8_t *o=cyc_render_oam();
            /* Restore only the pixels belonging to Mick's actual NES
             * sprite tiles. The v0.1 rectangular erase could overwrite
             * neighbouring blocks, enemies and carry-object pixels. */
            for(int i=0;i<player_tiles;i++){
                const uint8_t *slot=&o[(player_first+i)*4];
                int y0=slot[0]+1,x0=slot[3];
                unsigned attr=slot[2];
                int palette=16+(attr&3)*4;
                for(int dy=0;dy<8;dy++){
                    int y=y0+dy;
                    if(y<0||y>=240)continue;
                    int row=(attr&0x80)?7-dy:dy;
                    uint16_t pattern=(uint16_t)(cyc_render_line_sprite_table(y)+slot[1]*16+row);
                    uint8_t lo=cyc_render_chr(pattern),hi=cyc_render_chr((uint16_t)(pattern+8));
                    for(int dx=0;dx<8;dx++){
                        int x=x0+dx,sx=x+origin;
                        if(x<0||x>=256||sx<0||sx>=w)continue;
                        if(x<8 && !(cyc_render_line_mask(y)&0x04))continue;
                        int bit=(attr&0x40)?dx:7-dx;
                        unsigned pixel=((lo>>bit)&1)|(((hi>>bit)&1)<<1);
                        if(!pixel)continue;
                        if(native[(size_t)y*w+sx]!=cyc_render_color(palette+pixel))continue;
                        uint32_t back=background[y*256+x];
                        for(int yy=0;yy<SCALE;yy++){
                            uint32_t *dst=output+(size_t)(y*SCALE+yy)*sw+(size_t)sx*SCALE;
                            for(int xx=0;xx<SCALE;xx++)dst[xx]=back;
                        }
                    }
                }
            }
        }
        /* Anchor bottom centre to original 16x32 NES character, but allow a
         * 24px-wide sprite silhouette. All PNGs pre-scaled to 96x128 canvas. */
        int ox=(x_position+cyc_render_native_origin(w)-4)*SCALE;
        int oy=y_position*SCALE;
        const uint8_t *img=poses[pose];
        const int pw=pose_width[pose],ph=pose_height[pose];
        for(int y=0;y<ph;y++){
            int sy=oy+y;if(sy<0||sy>=h*SCALE)continue;
            for(int x=0;x<pw;x++){
                int sx=ox+x;if(sx<0||sx>=sw)continue;
                /* The NES uses bit 7 for vertical and bit 6 for horizontal
                 * inversion, independently. Transform the HD image about the
                 * whole character bounds, not each 8x8 CHR tile. */
                int src_x=facing_left?(pw-1-x):x;
                int src_y=upside_down?(ph-1-y):y;
                const uint8_t *rgba=img+4*((size_t)src_y*pw+src_x);
                if(rgba[3]){uint32_t *p=output+(size_t)sy*sw+sx;*p=blend(*p,rgba);}
            }
        }
        /* A carried block is meant to draw in front of Mick's raised hands.
         * Overlay only the block's own nontransparent NES CHR pixels from the
         * unmodified presentation, instead of a solid 16x16 rectangle that
         * would cover parts of the HD player and erase sky background. */
        if(carried_block_start>=0){
            const uint8_t *o=cyc_render_oam();
            int origin=cyc_render_native_origin(w);
            for(int i=0;i<4;i++){
                const uint8_t *slot=&o[(carried_block_start+i)*4];
                int y0=slot[0]+1,x0=slot[3];
                unsigned attr=slot[2],palette=16+(attr&3)*4;
                for(int dy=0;dy<8;dy++){
                    int y=y0+dy;
                    if(y<0||y>=240)continue;
                    int row=(attr&0x80)?7-dy:dy;
                    uint16_t pattern=(uint16_t)(cyc_render_line_sprite_table(y)+slot[1]*16+row);
                    uint8_t lo=cyc_render_chr(pattern),hi=cyc_render_chr((uint16_t)(pattern+8));
                    for(int dx=0;dx<8;dx++){
                        int x=x0+dx,sx=x+origin;
                        if(x<0||x>=256||sx<0||sx>=w)continue;
                        int bit=(attr&0x40)?dx:7-dx;
                        unsigned pixel=((lo>>bit)&1)|(((hi>>bit)&1)<<1);
                        if(!pixel)continue;
                        uint32_t object_color=cyc_render_color(palette+pixel);
                        /* Do not replace another layer if the NES itself
                         * had clipped this object pixel by sprite priority. */
                        if(native[(size_t)y*w+sx]!=object_color)continue;
                        for(int yy=0;yy<SCALE;yy++){
                            uint32_t *dst=output+(size_t)(y*SCALE+yy)*sw+(size_t)sx*SCALE;
                            for(int xx=0;xx<SCALE;xx++)dst[xx]=object_color;
                        }
                    }
                }
            }
        }
    }
    last_serial=serial;output_w=w;
    *width=w*SCALE;*height=h*SCALE;
    return output;
}
