/* Optional M.C. Kids HD Mick proof-of-concept presentation layer.
 * The game, 6502 CPU, physics, collision and PPU remain unmodified.
 */
#ifndef MCKIDS_HD_H
#define MCKIDS_HD_H
#include <stdint.h>
void mick_hd_enable(void);
void mick_hd_power_on(void);
void mick_hd_frame(void);
const uint32_t *mick_hd_present(int *width, int *height);
#endif
