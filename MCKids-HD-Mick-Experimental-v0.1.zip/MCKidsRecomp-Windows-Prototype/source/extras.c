/* M.C. Kids US: experimental map-backed 16:9 scenery extension.
 * Presentation only; CPU, collisions, OAM and timing remain native.
 */
#include "cyc_host_extras.h"
#include "cyc_core.h"
#include "cyc_render.h"
#include "cyc_video.h"
#include "mick_hd.h"
#include <string.h>
#include <stdlib.h>

static int wide;
static int camera(int approx, int phase) {
    int delta=approx-phase;
    return phase+16*(delta>=0?(delta+8)/16:-((-delta+8)/16));
}
static int compose(uint32_t *out,int width,int height,int origin,
                   const uint32_t *native,void *ctx) {
    (void)ctx;
    const uint8_t *r=cyc_cpu_ram();size_t size=0;
    const uint8_t *w=cyc_cart_ram(&size);
    if(!wide||!w||size<8192)return 0;
    int mw=r[0x77b],mh=r[0x77c];
    int start=0x701+4*w[0x700];
    /* Menus and small rooms keep the original picture. */
    if(mw<27||mh<15||start+mw*mh>8192||r[0x430]!=2)return 0;
    int ax=(r[0x681]+256*r[0x682])/4-128;
    int ay=(r[0x683]+256*r[0x684])/4-144;
    /* The RAM values are camera targets, not edge-clamped positions. */
    if(ax<0)ax=0;
    if(ax>mw*16-256)ax=mw*16-256;
    int cx=camera(ax,cyc_render_line_scroll_x(0)&15);
    int cy=camera(ay,cyc_render_line_scroll_y(0)&15);
    if(cx<0||cy<0||cx+256>mw*16||cy>=mh*16)return 0;
    if(origin>cx)origin=cx;
    int right=mw*16-cx-256;
    if(width-256-origin>right)origin=width-256-right;
    cyc_render_set_native_origin(origin);
    uint32_t colors[16];for(int i=0;i<16;i++)colors[i]=cyc_render_color(i);
    for(int y=0;y<height;y++) {
        int wy=cy+y;
        uint32_t backdrop=cyc_render_line_backdrop(y);
        for(int x=0;x<width;x++) {
            if(x>=origin+((cyc_render_line_mask(y)&2)?0:8)&&x<origin+256){out[y*width+x]=native[y*256+x-origin];continue;}
            int wx=cx+x-origin;
            uint32_t color=backdrop;
            if(wx>=0&&wx<mw*16&&wy>=0&&wy<mh*16&&(cyc_render_line_mask(y)&8)) {
                int id=w[start+(wy/16)*mw+wx/16];
                int quadrant=((wy&8)?2:0)+((wx&8)?1:0);
                int tile=w[quadrant*256+id];
                int addr=cyc_render_line_bg_table(y)+tile*16+(wy&7);
                int bit=7-(wx&7);
                int pixel=((cyc_render_chr(addr)>>bit)&1)|(((cyc_render_chr(addr+8)>>bit)&1)<<1);
                /* Tile flags select palette in descending bit priority. */
                int flags=w[0x400+id];
                int pal=(flags&4)?0:(flags&2)?1:(flags&1)?2:3;
                if(pixel)color=colors[pal*4+pixel];
            }
            out[y*width+x]=color;
        }
    }
    return 1;
}
static void setup(void *ctx) {
    (void)ctx;cyc_render_set_compositor(compose,NULL);
    cyc_video_set_mode(wide?NES_VIDEO_16_9:NES_VIDEO_STOCK);
}
static bool option(void *ctx,const char *name,const char *value) {
    (void)value;
    if(!strcmp(name,"--hd-mick")){mick_hd_enable();mick_hd_power_on();return true;}
    if(strcmp(name,"--widescreen"))return false;
    wide=1;setup(ctx);
    fprintf(stderr,"[M.C. Kids] experimental 16:9 scenery; offscreen objects retain original visibility\n");
    return true;
}
static const CycHostOption options[]={{"--widescreen",false,"Experimental 16:9 level scenery (objects retain native visibility)"},{"--hd-mick",false,"Experimental 4x resolution HD Mick sprite replacement"}};
static void power_on(void *ctx){mick_hd_power_on();setup(ctx);}
static const uint32_t *present(void *ctx,int *width,int *height){(void)ctx;return mick_hd_present(width,height);}
static void frame_end(void *ctx){(void)ctx;mick_hd_frame();}
static const CycHostExtras extras={.present=present,.frame_end=frame_end,.power_on=power_on,.state_loaded=setup,.options=options,.option_count=2,.option=option};
const CycHostExtras *cyc_host_extras(void){return &extras;}
