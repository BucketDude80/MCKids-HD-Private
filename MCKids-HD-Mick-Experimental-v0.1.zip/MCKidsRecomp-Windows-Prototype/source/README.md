# M.C. Kids recompilation prototype 2

Windows x64 executable supplied in the parent folder. This source project also builds on Linux. First-level movement, jumping, scrolling and arch collection were tested through scripted input on Linux. Windows execution and a physical Xbox controller still require user testing. This is an early prototype, not a completed whole-game port.

## Source and identity
NESRecomp: https://github.com/mstan/nesrecomp
Bundled revision: 2b4fcdb98c9e702be3fb365cfc645003c50b5fc1 (engine unchanged).
ROM SHA-256: 1b82b268b713672fcd022cbb41fd64154cdf17ac5e38bb6951ccbeb9d0755d94
ROM: M.C Kids (U) [!].nes, 262160 bytes, Mapper 4/MMC3.
No ROM is included. Game additions are CMakeLists.txt, extras.c and profiled seeds.txt.
extras.c supplies an explicit no-extra-features hook, avoiding MinGW weak-symbol archive linking issues.

## Validation
- Title screen: initial 600-frame profile rebuild matched all frame/state hashes and ran 99.3% of CPU cycles natively.
- First level entered: Lolli! The Garden.
- Scripted walking, jumping, camera scrolling and collection of an arch were observed in screenshots.
- Final 500-frame gameplay replay (frames 8500–8999) matched interpreter-only mode in every recorded frame/state hash and byte-for-byte in the 48 kHz audio WAV.
- During that replay 14791248 CPU cycles were native and 99000 used the $6000+ fallback; ROM interpreter cycles were zero. This is about 99.34% native for the resumed segment. The runtime prints a misleading 5.5% because its denominator includes cycles restored from the earlier save state; the native counter starts at resume.
- This comparison uses the SAME NES hardware runtime. No independent emulator comparison or full-game completion test was performed.
- Windows binary cross-compiled with MinGW-w64 GCC 13.2; inspected as PE32+ x64. Its only non-system DLL import is SDL2.dll, included. Windows executable not run in this Linux environment.
- SDL controller mappings inspected in engine/runner/cyc/cyc_input.c. Physical controller not tested.

## Build
Requires CMake 3.20+, Python 3.11+, C11 compiler. Set NESRECOMP_ROM to the absolute ROM path.
Windows with Visual Studio 2022 C++ build tools:

    cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DNESRECOMP_ROM="C:/path/MCKids.nes"
    cmake --build build --config Release --parallel 4

Linux headless:

    cmake -S . -B build -DNESRECOMP_HEADLESS=ON -DCMAKE_BUILD_TYPE=Release -DNESRECOMP_ROM="/path/MCKids.nes"
    cmake --build build --parallel 4
    ./build/MCKidsRecomp /path/MCKids.nes --load-state results/enter.cycstate --frames 9000 --input results/move-input.txt --hash-out native.csv --wav-out native.wav

Repeat with --interp-only to compare the same replay. Source is compiled against the supplied ROM's identity.
Cross builds accept NESRECOMP_HOST_COMPILER pointing to an already built host NESRecomp.

## Next testing
Windows startup, sound, physical Xbox input, later levels and completion. Retains interpreter fallback, NES hardware modelling and original graphics. See engine/LICENSE and bundled third-party notices.
