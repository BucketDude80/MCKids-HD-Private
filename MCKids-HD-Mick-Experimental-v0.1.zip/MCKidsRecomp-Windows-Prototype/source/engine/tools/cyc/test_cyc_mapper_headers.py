#!/usr/bin/env python3
"""Accept known NES 2.0 boards and reject unknown IDs/variants in all loaders."""
import argparse
from pathlib import Path
import subprocess
from itertools import chain

from mapper_fixtures import mapper_fixtures
from latch_fixtures import latch_fixtures
from fineprg_fixtures import fineprg_fixtures
from vrc_fixtures import vrc_fixtures
from expansion_fixtures import expansion_fixtures
from vrc7_fixtures import vrc7_fixtures
from bandai_fixtures import bandai_fixtures
from mmc5_fixtures import mmc5_fixtures
from mmc1_fixtures import mmc1_fixtures
from mapper40_fixtures import mapper40_fixtures
from mmc3_variant_fixtures import mmc3_variant_fixtures
from sunsoft_fixtures import sunsoft_fixtures
from namco_fixtures import namco_fixtures
from jaleco_fixtures import jaleco_fixtures
from taito_fixtures import taito_fixtures
from tengen_fixtures import tengen_fixtures


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--recompiler', type=Path, required=True)
    ap.add_argument('--interp', type=Path, required=True)
    ap.add_argument('--oracle', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    checked = set()
    count = 0
    identities = []
    for _, image, _, _ in chain(mapper_fixtures(), latch_fixtures(), fineprg_fixtures(), vrc_fixtures(), expansion_fixtures(), vrc7_fixtures(), bandai_fixtures(), mmc5_fixtures(), mmc1_fixtures(), mapper40_fixtures(), mmc3_variant_fixtures(), sunsoft_fixtures(), namco_fixtures(), jaleco_fixtures(), taito_fixtures(), tengen_fixtures()):
        mapper = (image[6] >> 4) | (image[7] & 0xf0)
        if mapper in checked:
            continue
        checked.add(mapper)
        for variant, byte8, accepted in [('unspecified', 0, True), ('submapper', 0xf0, False), ('extended_id', 1, False)]:
            case = out / f'mapper{mapper}_{variant}'
            case.mkdir(exist_ok=True)
            rom = bytearray(image)
            rom[7] |= 8
            rom[8] = byte8
            if not rom[5] or mapper in (119, 77):  # TQROM and LROG017 also carry 8 KiB CHR RAM
                rom[11] = 8 if mapper == 13 else 9 if mapper == 96 else 7
            if mapper == 77:
                rom[6] |= 8      # LROG017's nametables are RAM: a NES 2.0 header says four-screen
            (case / 'test.nes').write_bytes(rom)
            sub = byte8 >> 4
            if mapper == 210 and not sub and not byte8 & 15:
                sub = 1 if rom[6] & 2 else 2  # unknown 210 submapper: 175 with battery, else 340
            identities.append((case / 'test.nes', f'{mapper | (byte8 & 15) << 8} {sub}'))
            (case / 'game.toml').write_text('[game]\noutput_prefix="test"\ncycle_accurate=true\n')
            for name, exe, extra in [
                ('compiler', args.recompiler, ['--game', 'game.toml']),
                ('interp', args.interp, ['--frames', '1']),
                ('oracle', args.oracle, ['--frames', '1']),
            ]:
                p = subprocess.run([str(exe.resolve()), 'test.nes', *extra], cwd=case,
                                   capture_output=True, text=True, timeout=30,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                (case / f'{name}.log').write_text(p.stdout + p.stderr)
                if (p.returncode == 0) != accepted:
                    raise AssertionError(f'{case.name}: {name} header acceptance was {p.returncode}, expected {accepted}')
                count += 1
    # --cart-info reports each image's decoded board, accepted or not, and '? ?' for non-iNES files.
    junk = out / 'not_ines.nes'
    junk.write_bytes(bytes(32))
    identities.append((junk, '? ?'))
    p = subprocess.run([str(args.recompiler.resolve()), '--cart-info'], input=''.join(f'{r}\n' for r, _ in identities),
                       capture_output=True, text=True, timeout=60,
                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    got = [line.split(' ', 3) for line in p.stdout.splitlines() if line.startswith('CART ')]
    if p.returncode != 0 or len(got) != len(identities):
        raise AssertionError(f'--cart-info answered {len(got)} of {len(identities)} ROMs (exit {p.returncode})')
    for (rom, expected), line in zip(identities, got):
        if line[3] != str(rom) or f'{line[1]} {line[2]}' != expected:
            raise AssertionError(f'--cart-info {rom}: got {line[1:3]}, expected {expected}')
    print(f'{count} header acceptance/rejection checks passed ({len(checked)} mapper IDs); '
          f'{len(identities)} --cart-info identities')


if __name__ == '__main__':
    main()
