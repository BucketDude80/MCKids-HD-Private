/*
 * game_config.h — Per-game recompiler configuration
 *
 * Loaded from game.toml (TOML format only — .cfg is no longer supported).
 * Encapsulates all game-specific addresses that the generic recompiler
 * needs to handle correctly (dispatch tables, bank-switch trampolines, etc.).
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>

#define GAME_CFG_MAX_TRAMPOLINES       8
#define GAME_CFG_MAX_KNOWN_TABLES     32
#define GAME_CFG_MAX_SPLIT_TABLES     16
#define GAME_CFG_MAX_EXTRA_FUNCS      4096
#define GAME_CFG_MAX_INLINE_DISPATCHES 8
#define GAME_CFG_MAX_INLINE_POINTERS   8
#define GAME_CFG_MAX_NOP_JSRS          8
#define GAME_CFG_MAX_RAM_READ_HOOKS   16
#define GAME_CFG_MAX_BANK_SWITCHES     8
#define GAME_CFG_MAX_SRAM_MAPS         4
#define GAME_CFG_MAX_EXTRA_LABELS   1024
#define GAME_CFG_MAX_DATA_REGIONS   256
#define GAME_CFG_MAX_MERGE_FUNCS     16
#define GAME_CFG_MAX_MERGE_RANGES    16
#define GAME_CFG_MAX_STACK_BAIL_FUNCS 16
#define GAME_CFG_MAX_INDIRECT_CONTINUATIONS 16
#define GAME_CFG_MAX_DEDUP_EXCLUDES 4096

/*
 * Trampoline: a JSR whose operand address is a known bank-switch dispatch
 * routine. The bytes immediately after the JSR are inline data (not code).
 * inline_bytes: how many bytes after the JSR to consume as data (typ. 3).
 * bs_fn_addr:   the recompiled bank-switch function to call (e.g. 0xCC1A).
 *
 * kind selects the dispatch shape:
 *   TRAMP_SIMPLE (0): inline order [bank, lo, hi]; a single bank-switch fn
 *     (bs_fn_addr) switches one 16KB window, target called, window restored.
 *     This is the Faxanadu $F859 / MMC1 shape.
 *   TRAMP_MMC3_REGION (1): inline order [lo, hi, bank]; the target's hi byte
 *     selects an MMC3 8KB window — $80-$9F → R6 ($8000, bs_fn_8000/bank_save_8000),
 *     $A0-$BF → R7 ($A000, bs_fn_a000/bank_save_a000), else no switch (fixed/RAM).
 *     The raw 8KB bank is converted to the recompiler's 16KB (addr,bank) at the
 *     call site.  This is the Kirby $D805 shape.  bank is always passed in A.
 */
enum { TRAMP_SIMPLE = 0, TRAMP_MMC3_REGION = 1 };

typedef struct {
    uint16_t addr;          /* JSR target address (the trampoline entry) */
    int      inline_bytes;  /* extra data bytes following the JSR opcode  */
    uint16_t bs_fn_addr;    /* bank-switch function address in fixed bank  */
    int      addr_adjust;   /* added to inline addr (1=RTS convention, 0=JMP indirect) */
    char     bank_reg;      /* register holding bank number: 'A' or 'X' (default 'X') */
    uint16_t bank_save_addr;/* address to read current bank from before switch */
    int      kind;          /* TRAMP_SIMPLE (default) or TRAMP_MMC3_REGION */
    uint16_t bs_fn_8000;    /* MMC3 R6 ($8000) switch fn (kind=MMC3_REGION) */
    uint16_t bs_fn_a000;    /* MMC3 R7 ($A000) switch fn (kind=MMC3_REGION) */
    uint16_t bank_save_8000;/* saved-bank addr for R6 region (e.g. $0048)   */
    uint16_t bank_save_a000;/* saved-bank addr for R7 region (e.g. $0049)   */
} TrampolineEntry;

/*
 * Known 2-byte little-endian dispatch table.
 * Each pair of bytes is (target-1) stored as a LE16.
 * start..end is the half-open byte range within the given bank.
 */
typedef struct {
    int      bank;
    uint16_t start;
    uint16_t end;
} KnownTable;

/*
 * Split dispatch table: lo-bytes and hi-bytes in separate arrays.
 * target = (hi[i] << 8 | lo[i]) + adjust.
 *   adjust=1 (default): RTS-computed-goto tables store (target-1).
 *   adjust=0: JMP-indirect tables store the exact target address.
 * stride=1: packed; stride=2: interleaved pairs.
 */
typedef struct {
    int      bank;
    uint16_t lo_start;
    uint16_t hi_start;
    int      count;
    int      stride;
    int      adjust;
} KnownSplitTable;

/*
 * Extra function seed: a function that is dispatched dynamically and cannot
 * be discovered via static pointer/table scans.
 */
typedef struct {
    uint16_t addr;
    int      bank;   /* -1 for fixed bank */
} ExtraFunc;

/* [[mod_function_hook]] id and content key (see GameConfig). */
#define GAME_CFG_MAX_MOD_HOOK_KEYS 256
#define GAME_CFG_MOD_HOOK_BYTES     16
typedef struct {
    char     id[64];                         /* "" = none */
    uint8_t  len;                            /* 0 = no content key */
    uint32_t crc32;                          /* CRC-32 of the len bytes at the site */
} ModHookKey;

typedef struct {
    uint16_t addr;
    int      bank;          /* -1 for fixed bank */
    bool     replace_group; /* false: one identity; true: its proven group */
} ReplaceFunc;

/*
 * Inline indexed dispatch: JSR to a routine that pops the return address to
 * find an inline address table immediately after the JSR instruction.
 * The called routine dispatches via A register: entry = table[A].
 * Table entries are 2-byte little-endian absolute addresses.
 * Table ends when a hi byte < 0x80 is found (no valid ROM address).
 *
 * Usage in game.toml:  inline_dispatch <hex_addr>
 * Example (SMB):      inline_dispatch 8E04
 */
typedef struct {
    uint16_t addr;  /* JSR target (the dispatch routine) */
} InlineDispatch;

typedef struct {
    uint16_t addr;
    uint8_t  zp_lo;
    uint8_t  zp_hi;
    int      call;   /* 1 = also call the function after loading ZP */
} InlinePointer;

/*
 * RAM read hook: when the generated code reads from this address via
 * absolute addressing, wrap the value through game_ram_read_hook(pc, addr, val).
 * This lets game-specific extras.c adjust the returned value per-call-site.
 *
 * With `indexed = true`, absolute-indexed reads (LDA $nnnn,X / $nnnn,Y)
 * whose BASE address matches are hooked too; the hook receives the
 * runtime-computed effective address, so policy can dispatch on it.
 * Read-modify-write instructions (INC/DEC/shifts) are never hooked —
 * virtualizing their read would corrupt the writeback.
 *
 * Usage in game.toml:  [[ram_read_hook]]
 *                      addr = 0x071D
 *                      indexed = true   # optional, default false
 */
typedef struct {
    uint16_t addr;
    int      indexed;
} RamReadHook;

/*
 * Bank-switch routine: a JSR target that switches the mapper's switchable
 * bank to the value currently in the A register.
 *
 * Usage in game.toml:  bank_switch <hex_addr>
 * Example (Zelda):    bank_switch FFAC
 */
typedef struct {
    uint16_t addr;  /* JSR target address of bank-switch routine */
} BankSwitchRoutine;

/*
 * SRAM-to-ROM mapping: a region of SRAM that is a copy of ROM code.
 * When the walker encounters a JSR/JMP to an address in the SRAM range,
 * it translates to the corresponding ROM address and adds it as a function.
 * The ROM entry point is also seeded so internal calls get walked.
 *
 * Usage in game.toml:  sram_map <sram_start> <rom_start> <bank> <size>
 * Example (Zelda):    sram_map 6C90 A500 1 1370
 */
typedef struct {
    uint16_t sram_start;  /* Start of SRAM region (e.g., $6C90) */
    uint16_t rom_start;   /* Corresponding ROM address (e.g., $A500) */
    int      bank;        /* ROM bank containing the source code */
    uint16_t size;        /* Size of the mapped region in bytes */
} SramMap;

/*
 * Data region: a range of PRG ROM that contains data, not code.
 * The pointer scanner will not scan these bytes for function pointers,
 * and the function walker will not try to walk them as code.
 *
 * Usage in game.toml:  data_region <bank> <hex_start> <hex_end>
 * Example:            data_region 0 A200 A800
 */
typedef struct {
    int      bank;
    uint16_t start;
    uint16_t end;     /* exclusive */
} DataRegion;

/*
 * Merge functions: two function entry points that should be generated as
 * a single function body with multiple labels. JMPs between them become
 * goto statements instead of function calls. The lower address is the
 * canonical entry; the higher is a secondary label within the same body.
 *
 * Usage in game.toml:  merge_func <bank> <addr1_hex> <addr2_hex>
 * Example:            merge_func 1 A046 A047
 */
typedef struct {
    int      bank;
    uint16_t addr_lo;   /* lower address (canonical function entry) */
    uint16_t addr_hi;   /* higher address (secondary entry label) */
} MergeFunc;

/*
 * Merge range: ALL function entry points within [addr_lo, addr_hi] in the
 * given bank are merged into a single body.  The lowest-addressed entry point
 * becomes the canonical function; all others become secondary labels.
 * JMPs targeting any address within the range generate `goto` instead of
 * tail-calls, fixing loop-back JMPs that would otherwise over-pop S.
 *
 * Usage in game.toml:
 *   [[merge_range]]
 *   bank = 7
 *   addr_lo = 0xEF11
 *   addr_hi = 0xEF8D
 *   public = true  # optional, default true
 */
typedef struct {
    int      bank;
    uint16_t addr_lo;   /* inclusive lower bound */
    uint16_t addr_hi;   /* inclusive upper bound */
    bool     public_wrappers; /* emit dispatchable wrappers for secondary labels */
} MergeRange;

/*
 * Indirect continuation: a configured JMP site whose caller has pushed
 * a synthetic RTS operand before dispatch. If the dispatched callee returns by
 * popping that operand, generated code resumes at continuation instead of
 * returning to the C caller.
 *
 * Usage in game.toml:
 *   [[indirect_continuation]]
 *   bank = 17
 *   jmp_addr = 0x9855
 *   continuation = 0x98D9
 */
typedef struct {
    int      bank;
    uint16_t jmp_addr;
    uint16_t continuation;
} IndirectContinuation;

typedef struct {
    char            output_prefix[64];  /* e.g. "faxanadu" → generated/faxanadu_full.c */
    char            annotations_path[512]; /* override for annotations.csv */
    char            symbol_file[512]; /* optional .sym file for readable codegen comments */

    TrampolineEntry trampolines[GAME_CFG_MAX_TRAMPOLINES];
    int             trampoline_count;

    KnownTable      known_tables[GAME_CFG_MAX_KNOWN_TABLES];
    int             known_table_count;

    KnownSplitTable known_split_tables[GAME_CFG_MAX_SPLIT_TABLES];
    int             known_split_table_count;

    ExtraFunc       extra_funcs[GAME_CFG_MAX_EXTRA_FUNCS];
    int             extra_func_count;

    /* Function seeds that must execute as one interpreter island even when
     * static discovery could otherwise emit a native body. */
    ExtraFunc       force_interp_funcs[GAME_CFG_MAX_EXTRA_FUNCS];
    int             force_interp_count;

    InlineDispatch  inline_dispatches[GAME_CFG_MAX_INLINE_DISPATCHES];
    int             inline_dispatch_count;

    RamReadHook     ram_read_hooks[GAME_CFG_MAX_RAM_READ_HOOKS];
    int             ram_read_hook_count;

    BankSwitchRoutine bank_switches[GAME_CFG_MAX_BANK_SWITCHES];
    int              bank_switch_count;

    SramMap          sram_maps[GAME_CFG_MAX_SRAM_MAPS];
    int              sram_map_count;

    InlinePointer   inline_pointers[GAME_CFG_MAX_INLINE_POINTERS];
    int             inline_pointer_count;

    uint16_t        nop_jsrs[GAME_CFG_MAX_NOP_JSRS]; /* JSR targets to skip entirely */
    int             nop_jsr_count;

    uint16_t        push_jsrs[GAME_CFG_MAX_NOP_JSRS]; /* JSR targets that need 6502 return addr pushed */
    int             push_jsr_count;

    uint16_t        return_adjust_funcs[GAME_CFG_MAX_NOP_JSRS]; /* JSR targets that rewrite their RTS operand */
    int             return_adjust_func_count;

    /* JSR targets whose callee consumes the pushed return address as data
     * (e.g. inline bytecode trampolines). At push_jsr sites for these targets
     * the post-call S-mismatch bail is replaced with an S restore. */
    uint16_t        absorb_jsr_rets[GAME_CFG_MAX_NOP_JSRS];
    int             absorb_jsr_ret_count;

    /* JSR targets whose callee leaves the pushed return address on the 6502
     * stack (its RTS is a plain C return). At push_jsr sites for these
     * targets the post-call S-mismatch bail is replaced with an S restore,
     * and execution falls through to site+3 (no goto). */
    uint16_t        restore_jsrs[GAME_CFG_MAX_NOP_JSRS];
    int             restore_jsr_count;

    struct {
        uint16_t target;  /* JMP destination that needs the dummy push */
        uint16_t source;  /* 0 = match any JMP site; nonzero = only this JMP source PC */
    }               push_jmps[GAME_CFG_MAX_NOP_JSRS];
    int             push_jmp_count;

    ExtraFunc        extra_labels[GAME_CFG_MAX_EXTRA_LABELS];
    int              extra_label_count;

    DataRegion       data_regions[GAME_CFG_MAX_DATA_REGIONS];
    int              data_region_count;

    MergeFunc        merge_funcs[GAME_CFG_MAX_MERGE_FUNCS];
    int              merge_func_count;

    MergeRange       merge_ranges[GAME_CFG_MAX_MERGE_RANGES];
    int              merge_range_count;

    IndirectContinuation indirect_continuations[GAME_CFG_MAX_INDIRECT_CONTINUATIONS];
    int              indirect_continuation_count;

    ReplaceFunc      replace_funcs[GAME_CFG_MAX_EXTRA_FUNCS];  /* body provided by extras.c */
    int              replace_func_count;

    /* [[mod_function_hook]]: function entries that dispatch trusted,
     * statically linked mod callbacks. Unlike replace_func, which is a
     * compile-time substitution that drops the original body entirely, this
     * KEEPS the original and lets a mod decide per call whether to run it —
     * which is what a launcher-toggleable mod needs. Codegen emits
     *     if (nes_mod_function_entry(0xADDR)) return;
     * as the first statement of the entry. Empty by default, so a project
     * that does not opt in emits no callback and no overhead.
     * Usage in game.toml:  [[mod_function_hook]]
     *                      addr = 0xB0E9
     *                      bank = 0        # optional; omitted matches any bank
     *                      id = "game.feature.hook"   # optional plugin id
     *                      bytes = "A5 0E C9 08"      # optional content key, or
     *                      length = 4                 # ... the key as the length
     *                      crc32 = 0x1234ABCD         # and CRC-32 of those bytes
     *
     * The cycle backend (cyc_codegen.c) keys a hook on the code actually at
     * the address: the `length` bytes there (1-16, given as `bytes` or by
     * their CRC-32, which keeps the program's own bytes out of a repository)
     * must be the key when the hook fires, which is what makes a hook in RAM
     * meaningful (an FDS program loads different files at the same address).
     * A hook at a RAM address must declare one, and some disk file must hold
     * it there. `id` names the plugin that registers for this site
     * (nes_mod_register_function_entry_plugin); the cycle host refuses a
     * registration whose id/address no site declares. */
    ExtraFunc        mod_function_hooks[GAME_CFG_MAX_EXTRA_FUNCS];
    /* Opt-in: also intercept branch/fallthrough entry inside an emitted body.
     * The callback owns the remainder of the native routine, just as for JSR. */
    bool             mod_function_hook_internal[GAME_CFG_MAX_EXTRA_FUNCS];
    int              mod_function_hook_count;
    /* id / content key of hook i (i < GAME_CFG_MAX_MOD_HOOK_KEYS; a hook past
     * that index may not declare either, which the loader rejects). */
    ModHookKey       mod_function_hook_keys[GAME_CFG_MAX_MOD_HOOK_KEYS];

    ExtraFunc        dedup_excludes[GAME_CFG_MAX_DEDUP_EXCLUDES];
    int              dedup_exclude_count;

    uint16_t         stack_bail_funcs[GAME_CFG_MAX_STACK_BAIL_FUNCS];
    int              stack_bail_func_count;

    /* Conditional bail functions: functions whose body CONTAINS inline bail
     * code (PLA PLA + RTS) that fires conditionally.  Unlike stack_bail_func
     * (which ALWAYS bails), these sometimes return normally.  At JSR call
     * sites, the codegen emits an S check: if S changed beyond the JSR
     * push/pop, the bail fired and the caller must also return. */
    uint16_t         cond_bail_funcs[GAME_CFG_MAX_STACK_BAIL_FUNCS];
    int              cond_bail_func_count;

    bool             push_all_jsr;  /* emit 6502 stack push/pop on every JSR/RTS */
    bool             disable_ptr_scan; /* skip switchable→fixed ROM pointer scan */
    bool             disable_secondary; /* skip secondary entry classification */
    bool             deduplicate_functions; /* exact generated-body sharing, opt-in */
    bool             cycle_accurate; /* emit <prefix>_cyc.c for runner/cyc instead (cyc_codegen.c) */
    /* [game] cycle_seed_file: instruction addresses observed running on the
     * interpreter (written by the cycle-accurate host's --miss-log), used as
     * extra discovery entry points. Resolved relative to game.toml. */
    char             cycle_seed_file[512];
    /* [game] cycle_capture_file: RAM code that ran on the interpreter with no
     * compiled view (the cycle host's --capture-log: instructions, chunk
     * snapshots, bytes rewritten under a view). The compiler seeds disk files
     * with it and compiles snapshots of code no disk file holds. Resolved
     * relative to game.toml. */
    char             cycle_capture_file[512];
    /* [game] fds = true and [fds] image / bios: a Famicom Disk System title.
     * The paths are resolved relative to game.toml. The compiler builds the
     * RAM Adapter's BIOS as the program's ROM (cycle backend only). */
    bool             fds;
    char             fds_image[512];
    char             fds_bios[512];
    /* [fds] hle = "auto-swap,fast-load": the HLE axes the program asks for by
     * default (common/nes_fds_hle.h); empty = none. */
    char             fds_hle[128];
    /* [game] console = "nes" | "famicom" | "default": the audio output stage
     * the cycle host uses by default (runner/cyc cyc_set_console); 0 = the
     * board's default, 1 = nes, 2 = famicom. */
    uint8_t          console;
    /* [game] name: the title players see (window, launcher); empty = output_prefix */
    char             display_name[128];
    /* [game] cycle_inline_jsr = ["E7BB:2", ...]: subroutines that take N
     * bytes of inline arguments after the JSR and return past them, so the
     * cycle-accurate discovery continues at JSR + 3 + N. */
    struct { uint16_t target; uint8_t bytes; } cycle_inline_jsr[64];
    int              cycle_inline_jsr_count;
} GameConfig;

/* Initialize to empty (no dispatch tables, prefix derived from ROM name) */
void game_config_init_empty(GameConfig *cfg);

/*
 * Load config from a game.toml file (.cfg is no longer supported).
 * Returns true on success; cfg remains empty on failure.
 * game_dir is set to the directory containing the file (for annotations lookup).
 */
bool game_config_load(GameConfig *cfg, const char *path);
