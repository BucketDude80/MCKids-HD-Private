/*
 * main_runner.c — SDL2 window, VBlank-callback NMI, PNG screenshot save
 *
 * NES architecture: RESET never returns (it IS the main game loop).
 * NMI fires asynchronously every VBlank. We simulate this by hooking
 * ppu_read_reg($2002): when the game reads the VBlank flag, we call
 * nes_vblank_callback() which runs func_NMI() + renders the frame.
 *
 * Usage: NESRecompGame.exe <baserom.nes>
 * - 768x720 window (256x240 NES, 3x scale)
 * - PNG screenshot every 60 frames (rotating 01..10)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <setjmp.h>

#ifdef _WIN32
#include <direct.h>
#define runner_mkdir(path) _mkdir(path)
#else
#include <sys/stat.h>
#define runner_mkdir(path) mkdir((path), 0755)
#endif

#include <SDL.h>
#include "startup_timing.h"
#include "nes_runtime.h"
#include "input_script.h"
#include "logical_input.h"
#if NESRECOMP_ENABLE_MODS
#include "mod_runtime.h"
#endif
uint8_t g_logical_input[4];
uint8_t nes_input_seat(int seat) {
    if (seat == 1) return g_controller1_buttons;
    if (seat == 2) return g_controller2_buttons;
    return seat >= 3 && seat <= NESRECOMP_INPUT_SEATS ? g_logical_input[seat-1] : 0;
}
#include "savestate.h"
#include "mod_audio.h"
#include "logger.h"
#include "apu.h"
#include "mapper.h"
#include "game_extras.h"
#include "debug_server.h"
#include "keybinds.h"
#include "controller.h"
#include "crc32.h"
#include "color_lut.h"
#include "save_ram.h"
#include "config.h"
#include "hdpack.h"
#include "nes_video.h"
#include "ppu_dot.h"
#include "interp.h"
#include "nes_rb_state.h"
#include "nes_rb_probe.h"
#ifdef NESRECOMP_NET
#include "nes_netplay.h"
#include "nes_netplay_identity.h"
#include "nes_netplay_rb.h"
#endif

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

/* Always-on audio observability (round-2). Env-gated: zero effect unless
 * RECOMP_AUDIO_DEBUG=<dir> is set. See recomp_audio_debug.h. */
#define RECOMP_AUDIO_DEBUG_IMPL
#include "recomp_audio_debug.h"

/* Shared clock-domain bridge (round-2): a real SDL audio callback pulls from a
 * persistent band-limited resampler + fill controller, decoupling the steady host
 * consumer from the bursty video-paced producer. This is the NES crackle fix:
 * measurement showed the old SDL_QueueAudio push model let the queue hit 0 (SDL
 * fills underruns with silence -> crackle). */
#define RECOMP_AUDIO_DRC_IMPL
#include "recomp_audio_drc.h"
static rab_bridge   s_bridge;
static int          s_bridge_ready = 0;
static SDL_mutex   *s_audio_mtx    = NULL;

/* ---- Script / record / savestate paths (set from CLI) ---- */
static const char *s_script_path    = NULL;
static const char *s_record_path    = NULL;
static const char *s_loadstate_path = NULL;
static char        s_savestate_dir[1024] = "./savestates";

static void savestate_slots_init(void) {
    char exe_dir[1024];
    nesrecomp_exe_dir(exe_dir, sizeof(exe_dir));
    snprintf(s_savestate_dir, sizeof(s_savestate_dir), "%ssavestates", exe_dir);
    runner_mkdir(s_savestate_dir); /* EEXIST is expected after the first run. */
}

static int savestate_slot_from_scancode(SDL_Scancode scancode) {
    if (scancode < SDL_SCANCODE_F1 || scancode > SDL_SCANCODE_F12) return 0;
    return (int)(scancode - SDL_SCANCODE_F1) + 1;
}

static void savestate_slot_path(int slot, char *out, size_t out_len) {
    snprintf(out, out_len, "%s/slot%02d.sav", s_savestate_dir, slot);
}

/* ---- Smoke test mode (--smoke N) ---- */
static int         s_smoke_frames   = 0;     /* 0 = normal, >0 = headless smoke test */
static int         s_smoke_interval = 100;   /* hash framebuffer every N frames */
static const char *s_smoke_output   = NULL;  /* output file path (NULL = stdout) */
#define SMOKE_MAX_HASHES 10000
static uint32_t    s_smoke_hashes[SMOKE_MAX_HASHES];

/* Permanent host-stack checkpoint for save-state loads. A state restores the
 * NES stack, not the nested C calls that happened to be active when F1 was
 * pressed, so the current callback finishes and then jumps back here. */
static jmp_buf s_guest_resume_jmp;
static int     s_guest_resume_ready = 0;

/* Rollback (netplay and NES_RB_PROBE) restarts the guest continuation at the
 * end of EVERY outer callback, not only after a load: the main thread's next
 * segment is always rebuilt from (resume PC, charged) + guest state, so a
 * live tick and a replayed tick run the identical host path by construction.
 * Measured need (2026-09-25): SMB's idle loop is `JMP $8057`, which native
 * code charges as 3+2 cycles in func_RESET's body but 3 then 2 per iteration
 * in func_8057_b0 (the resume handoff target) -- a resumed timeline landed
 * the next VBlank one CPU cycle off the live one (NES_RB_PROBE: runtime_blob
 * nes_cycles/ops_count +-1 on every probe). See docs/NETPLAY.md. */
static int rb_restart_every_tick(void);

static void finish_frame_callback(void) {
    uint16_t pc = 0;
    int charged = 0;
    int have_point = rb_restart_every_tick() &&
                     runtime_get_savestate_resume(&pc, &charged);
    int outermost = runtime_end_frame_callback();
    if (outermost && s_guest_resume_ready && !runtime_guest_resume_pending() &&
        have_point)
        runtime_request_guest_resume(pc, charged);
    if (outermost && s_guest_resume_ready && runtime_guest_resume_pending())
        longjmp(s_guest_resume_jmp, 1);
}

/* [STATE] trace aux state (NESRECOMP_TRACE_STATE) */
static uint8_t s_state_pre33      = 0;   /* $33 before this frame's NMI */
static int     s_state_nmi_en     = 0;   /* $2000 bit7 at frame boundary */
static int     s_state_depth      = 0;   /* vblank depth at frame boundary */
static int     s_state_shim_fired = 0;   /* legacy nested-NMI shim ran */

static uint64_t s_rb_resumes = 0;   /* continuation restarts (evidence) */
static int rb_restart_every_tick(void);
static void run_guest_execution(void) {
    (void)setjmp(s_guest_resume_jmp);
    s_guest_resume_ready = 1;

    uint16_t resume_pc = 0;
    int tick_charged = 0;
    if (runtime_take_guest_resume(&resume_pc, &tick_charged)) {
        runtime_prepare_guest_resume(resume_pc, tick_charged);
        s_rb_resumes++;
        if (!rb_restart_every_tick()) {
            printf("[SaveState] Resuming guest execution at $%04X\n", resume_pc);
            fflush(stdout);
        }
        if (!nes_interp_resume(resume_pc))
            nes_write_runtime_fault("save-state guest resume failed");
        else
            nes_write_runtime_fault("save-state guest resume returned unexpectedly");
        return;
    }

    game_run_main();
    nes_write_runtime_fault("game_run_main returned unexpectedly");
}
static int         s_smoke_hash_frames[SMOKE_MAX_HASHES];
static int         s_smoke_hash_count = 0;

/* ---- Uncapped benchmark mode (--benchmark N) ----
 * Runs the same fully-rendered headless frame path as --smoke, but avoids
 * periodic framebuffer hashing and times only the requested post-warmup
 * frames. This deliberately excludes SDL presentation, audio, pacing, and
 * process startup. */
static int         s_benchmark_frames = 0;
static int         s_benchmark_warmup = 300;
static const char *s_benchmark_output = NULL;
static Uint64      s_benchmark_start = 0;
static int         s_benchmark_breakdown = 0;
static Uint64      s_benchmark_callback_ticks = 0;
static Uint64      s_benchmark_nmi_ticks = 0;
static Uint64      s_benchmark_post_nmi_ticks = 0;
static Uint64      s_benchmark_sprite0_ticks = 0;
static Uint64      s_benchmark_ppu_ticks = 0;
static Uint64      s_benchmark_post_render_ticks = 0;

#ifndef NESRECOMP_BENCH_BUILD_ID
#define NESRECOMP_BENCH_BUILD_ID __DATE__ " " __TIME__
#endif

static int headless_run_active(void) {
    return s_smoke_frames > 0 || s_benchmark_frames > 0 || s_script_path != NULL;
}

static void benchmark_breakdown_reset(void) {
    s_benchmark_callback_ticks = 0;
    s_benchmark_nmi_ticks = 0;
    s_benchmark_post_nmi_ticks = 0;
    s_benchmark_sprite0_ticks = 0;
    s_benchmark_ppu_ticks = 0;
    s_benchmark_post_render_ticks = 0;
}
#ifdef NESRECOMP_NET
static jmp_buf s_netplay_return;
static int s_netplay_return_ready;
static void netplay_return_to_lobby(const char *why) {
    fprintf(stderr, "[Netplay] Returning to lobby: %s\n", why ? why : "match ended");
    nes_netplay_log_summary();
    fflush(stderr); fflush(stdout);
    /* Harnesses that grade one match per process (tools/rb_loopback.sh). */
    if (getenv("NES_NET_EXIT_ON_RETURN")) {
        nesrecomp_expect_process_exit();
        exit(3);
    }
    if (s_netplay_return_ready) longjmp(s_netplay_return, 1);
    exit(0);
}
#endif

/* ---- rollback tick gate --------------------------------------------------
 * Netplay (and the offline determinism probe) own the per-tick boundary at
 * the top of the OUTERMOST frame callback, before the NMI handler runs:
 *   - the snapshot/digest taken there is the state BEFORE this tick;
 *   - a baseline load there makes the rest of this callback replay the load
 *     tick, and finish_frame_callback() then discards the stale native stack
 *     and resumes the restored guest continuation (run_guest_execution);
 *   - the rows the driver published are applied right before the NMI, after
 *     every local input source, so the published rows are the only input any
 *     seat sees while a session is active;
 *   - a replayed tick runs the same code as a live one and only its SDL
 *     present, wall-clock pacing and audio delivery are skipped.
 * With neither active nothing here runs and the callback is unchanged. */
static int     s_rb_tick_replay = 0;     /* this tick is a replay: no present */
static int     s_rb_rows_valid = 0;
static uint8_t s_rb_rows[4];
static int     s_rb_resim_audio_mark = -1;
static Uint64  s_rb_tick_t0 = 0;        /* admit time of the running tick */
static uint8_t s_rb_local_test_pad(void);

#ifdef NESRECOMP_NET
static void rb_on_publish(const uint8_t *rows, int slots, int replay) {
    memset(s_rb_rows, 0, sizeof(s_rb_rows));
    for (int i = 0; i < slots && i < 4; ++i) s_rb_rows[i] = rows[i];
    s_rb_rows_valid = 1;
    s_rb_tick_replay = replay ? 1 : 0;
}

/* Resim audio goes to scratch: everything the replayed ticks push into the
 * APU output ring is dropped at resim end, so the player hears no tick twice
 * (recomp-ai-rules/NETPLAY.md §1). The APU's simulation state is untouched. */
static void rb_on_resim(int begin) {
    if (begin) s_rb_resim_audio_mark = apu_output_ring_head();
    else if (s_rb_resim_audio_mark >= 0) {
        apu_output_ring_rewind(s_rb_resim_audio_mark);
        s_rb_resim_audio_mark = -1;
    }
}

static uint8_t rb_sample_local_pad(void) {
    uint8_t pad = 0;
    int src;
    if (nes_netplay_is_spectator()) return 0;
    pad = s_rb_local_test_pad();
    if (pad) return pad;
    if (headless_run_active()) return 0;
    /* The local peer plays with ITS player-1 device, whatever seat it holds. */
    src = g_nes_config.player_src[0];
    {
        const uint8_t *keys = SDL_GetKeyboardState(NULL);
        if (src == 1) pad |= keybinds_read_player(keys, 1);
        if (src == 2) pad |= controller_read_player(1);
    }
    return pad;
}

static void rb_netplay_gate(void) {
    const char *why = NULL;
    nes_netplay_frame_end();
    s_rb_rows_valid = 0;
    s_rb_tick_replay = 0;
    for (;;) {
        SDL_Event ev;
        int a;
        if (nes_netplay_quiesced()) {
            const char *shot = getenv("NES_NET_SCREENSHOT");
            if (shot && shot[0]) runner_screenshot(shot);
            /* A lobby match drains and goes back to the room; a harness
             * process (rb_loopback.sh) exits once both sides are idle. */
            if (getenv("NES_LOBBY_SELFTEST") || getenv("NES_NET_QUIESCE_RETURN"))
                netplay_return_to_lobby("match_complete");
            fprintf(stderr, "[Netplay] drained — exiting (frame %llu)\n",
                    (unsigned long long)g_frame_count);
            nes_netplay_log_summary();
            fflush(stderr); fflush(stdout);
            nesrecomp_expect_process_exit();
            exit(0);
        }
        {
            /* NES_NET_MATCH_TICKS=N: a bounded match -- ask for the
             * coordinated stop at sim tick N (every peer drains). */
            static int s_match_ticks = -1;
            if (s_match_ticks < 0) {
                const char *e = getenv("NES_NET_MATCH_TICKS");
                s_match_ticks = (e && e[0]) ? atoi(e) : 0;
            }
            if (s_match_ticks > 0 && nes_netplay_sim_tick() >= (uint32_t)s_match_ticks)
                nes_netplay_request_quiesce();
        }
        if (nes_netplay_return_to_lobby_requested(&why))
            netplay_return_to_lobby(why);
        if (!headless_run_active() && SDL_WasInit(SDL_INIT_EVENTS)) {
            while (SDL_PollEvent(&ev)) {
                controller_handle_event(&ev);
                if (ev.type == SDL_QUIT ||
                    (ev.type == SDL_WINDOWEVENT && ev.window.event == SDL_WINDOWEVENT_CLOSE) ||
                    (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_ESCAPE))
                    netplay_return_to_lobby("local player left");
            }
        }
        nes_netplay_stage_local(rb_sample_local_pad());
        a = nes_netplay_poll_admit();
        if (a != NES_NETPLAY_ADMIT_STALL) { s_rb_tick_t0 = SDL_GetPerformanceCounter(); break; }
        SDL_Delay(1);
    }
}
/* Engine-level session key: widescreen changes what the game simulates for
 * the extended margins, so a match runs the HOST's value on every peer and
 * each peer's own preference comes back when the session ends. */
static int s_ws_offline = -1;
static int ws_get(char *out, int cap) { return snprintf(out, (size_t)cap, "%d", g_nes_config.widescreen ? 1 : 0); }
static int ws_offer(char *out, int cap) {
    /* The player's own setting, not a previous match's applied value. */
    int v = s_ws_offline >= 0 ? s_ws_offline : g_nes_config.widescreen;
    return snprintf(out, (size_t)cap, "%d", v ? 1 : 0);
}
static int ws_apply(const char *v) {
    if (!v || (strcmp(v, "0") && strcmp(v, "1"))) return 0;
    if (s_ws_offline < 0) s_ws_offline = g_nes_config.widescreen;
    g_nes_config.widescreen = atoi(v);
    return 1;
}
static void ws_restore(void) {
    if (s_ws_offline >= 0) g_nes_config.widescreen = s_ws_offline;
    s_ws_offline = -1;
}
#endif

/* The interpreter bridge the continuation restart runs through, counted
 * (PRINCIPLES.md "The interpreter may bridge -- but only honestly"). */
void nes_rb_log_bridge(void) {
    NesInterpStats st;
    nes_interp_get_stats(&st);
    fprintf(stderr, "RB_BRIDGE restarts=%llu interp_instrs=%llu interp_runs=%llu "
                    "native_handoffs=%llu resume_reentries=%llu declines=%llu "
                    "watchdog_trips=%llu interp_enabled=%d\n",
            (unsigned long long)s_rb_resumes, (unsigned long long)st.instrs_total,
            (unsigned long long)st.runs, (unsigned long long)st.native_handoffs,
            (unsigned long long)st.native_resume_reentries,
            (unsigned long long)st.declines, (unsigned long long)st.watchdog_trips,
            nes_interp_is_enabled());
}

static int rb_restart_every_tick(void) {
#ifdef NESRECOMP_NET
    if (nes_netplay_active()) return 1;
#endif
    return nes_rb_probe_active();
}

#ifdef NESRECOMP_NET
/* The engine's session keys. Called by the runner and by the lobby before
 * the room publishes its caps (the room's text must already carry every key
 * a peer will require). Idempotent. */
void nes_runner_register_session_keys(void) {
    (void)nes_netplay_session_register("widescreen", ws_get, ws_apply, ws_restore);
    (void)nes_netplay_session_set_offer("widescreen", ws_offer);
}
#endif

static void rb_frame_top(void) {
#ifdef NESRECOMP_NET
    if (nes_netplay_active()) { rb_netplay_gate(); return; }
#endif
    if (nes_rb_probe_active()) {
        nes_rb_probe_top();
        s_rb_tick_replay = nes_rb_probe_replaying();
    }
}

static void rb_pre_tick(void) {
    if (s_rb_rows_valid) {
        g_controller1_buttons = s_rb_rows[0];
        g_controller2_buttons = s_rb_rows[1];
        g_logical_input[2] = s_rb_rows[2];
        g_logical_input[3] = s_rb_rows[3];
        s_rb_rows_valid = 0;
    }
    if (nes_rb_probe_active()) nes_rb_probe_pre_tick();
    /* Guest code runs from here on: the cached snapshot image is stale. */
    nes_rb_state_invalidate();
}

/* NES_NET_TEST_PAD=<seed>[:<start_tick>]: a scripted local pad for harnesses
 * -- a deterministic per-seed pattern (walk right, run, jump on a period,
 * Start once to leave the title), so peers mispredict each other for real.
 * It is a LOCAL sample: it reaches the match only through the published rows,
 * exactly like a controller. */
static uint8_t s_rb_local_test_pad(void) {
    static int init = 0, seed = -1, start_tick = 0;
    uint32_t n;
    if (!init) {
        const char *e = getenv("NES_NET_TEST_PAD");
        init = 1;
        if (e && e[0]) {
            seed = atoi(e);
            const char *c = strchr(e, ':');
            start_tick = c ? atoi(c + 1) : 90;
        }
    }
    if (seed < 0) return 0;
    /* Keyed to the session's sim tick, so a stalled admit re-samples the
     * same value and every peer's pattern is a function of the tick alone. */
#ifdef NESRECOMP_NET
    n = nes_netplay_sim_tick();
#else
    n = (uint32_t)g_frame_count;
#endif
    if ((int)n < start_tick) return 0;
    {
        uint32_t t = n - (uint32_t)start_tick;
        uint8_t pad = 0;
        /* Start: seat 0 leaves the title / attract once, near the beginning. */
        if (seed == 0 && t < 6) return 0x10;
        if (t < 60) return 0;
        pad |= 0x01;                                   /* right */
        if (((t / (37 + 11 * (uint32_t)seed)) & 3) == 2) pad = 0x02;  /* back off */
        if ((t % (53 + 7 * (uint32_t)seed)) < 18) pad |= 0x80;        /* jump */
        if (((t / 97) + (uint32_t)seed) & 1) pad |= 0x40;             /* run */
        return pad;
    }
}

/* ---- SDL state (file-level so nes_vblank_callback can access) ---- */
static SDL_Window        *s_window    = NULL;
static SDL_Renderer      *s_renderer  = NULL;
static SDL_Texture       *s_texture   = NULL;
/* HD texture pack output: when a pack is active the native render still runs at
 * g_render_width x 240, then hdpack_upscale() builds this HD frame (scale x). */
static SDL_Texture       *s_hd_texture = NULL;
static uint32_t          *s_hd_buf     = NULL;
static int                s_hd_scale   = 1;
/* Widescreen globals — default to standard 4:3 NES output.
 * Games override these in game_on_init() before the first frame. */
int g_render_width    = 256;
int g_widescreen_left = 0;
int g_widescreen_right = 0;

/* Per-frame effective margins; -1 = follow the configured margins. */
int g_ws_eff_left  = -1;
int g_ws_eff_right = -1;

/* Widescreen sprite-X sidecar — inert until a game sets g_ws_oam_sidecar.
 * See nes_runtime.h for the population model. */
int     g_ws_oam_sidecar   = 0;
int16_t g_oam_x16[64];
int16_t g_ws_shadow_x16[64];
int16_t g_ws_obj_true_rel  = 0;
uint8_t g_ws_obj_rel8      = 0;
uint8_t g_ws_obj_ctx_valid = 0;
int     g_ws_obj_delta_min = -24;
int     g_ws_obj_delta_max = 56;

/* Width-sized pixel buffers. Allocated once (video_alloc_buffers) at the widest
 * supported framebuffer, NES_MAX_RENDER_WIDTH x 240, so a live aspect change
 * (nes_video.h) never moves them: pointers already handed to the zapper probe
 * and the dot-PPU stay valid; only the SDL textures are re-created. */
#define VIDEO_BUF_BYTES ((size_t)NES_MAX_RENDER_WIDTH * 240u * sizeof(uint32_t))
static uint32_t          *s_framebuf = NULL;
/* Present-time color-LUT scratch (palette swap applied to a COPY only when an
 * alternate palette is opted in via NESRECOMP_PALETTE; default Raw = unused). */
static uint32_t          *s_present_buf = NULL;

/* On-demand render for Zapper light detection.  The game reads the light sensor
 * mid-frame (during func_NMI / the main loop), so we render the CURRENT PPU state
 * into a PRIVATE buffer and expose it as the zapper snapshot.
 *
 * Both renderer paths use the private buffer: the dot-PPU because it publishes
 * s_framebuf only at the frame boundary (present buffer is a frame stale); the
 * per-frame renderer because writing the live display buffer s_framebuf here
 * painted a mid-frame snapshot into the presented/dumped frame — a phantom
 * flicker that only appeared in captures (the frame-boundary render at
 * main loop ~813 re-rendered s_framebuf, so live display was usually spared).
 * Rendering into s_zapper_snapbuf keeps the two paths symmetric and leaves the
 * display buffer untouched. */
static uint32_t          *s_zapper_snapbuf = NULL;

static void video_alloc_buffers(void) {
    if (s_framebuf) return;
    s_framebuf       = (uint32_t *)calloc(1, VIDEO_BUF_BYTES);
    s_present_buf    = (uint32_t *)calloc(1, VIDEO_BUF_BYTES);
    s_zapper_snapbuf = (uint32_t *)calloc(1, VIDEO_BUF_BYTES);
    if (!s_framebuf || !s_present_buf || !s_zapper_snapbuf) {
        fprintf(stderr, "[Video] framebuffer allocation failed\n");
        exit(1);
    }
}

/* Apply a queued geometry change (nes_video.h). Called at exactly one point
 * per frame -- after SDL_RenderPresent, before the next frame renders -- so
 * g_render_width never changes while a frame is in flight. Pre-window
 * requests were applied immediately by nes_video and never reach here. */
static void video_apply_pending(void) {
    int left, right;
    if (!nes_video_take_pending(&left, &right)) return;
    nes_video_commit(left, right);
    /* Stale narrower/wider content would sit misaligned under the new
     * geometry until the next real render (a rendering-off frame keeps the
     * previous picture on purpose); start from black. */
    memset(s_framebuf, 0, VIDEO_BUF_BYTES);
    if (!s_renderer) return;
    if (s_texture) SDL_DestroyTexture(s_texture);
    s_texture = SDL_CreateTexture(s_renderer, SDL_PIXELFORMAT_ARGB8888,
                                  SDL_TEXTUREACCESS_STREAMING, g_render_width, 240);
    if (!s_texture) {
        fprintf(stderr, "SDL_CreateTexture (resize): %s\n", SDL_GetError());
        exit(1);
    }
    if (s_hd_texture && hdpack_active()) {
        int hw = g_render_width * s_hd_scale, hh = 240 * s_hd_scale;
        uint32_t *nb = (uint32_t *)realloc(s_hd_buf, (size_t)hw * hh * sizeof(uint32_t));
        if (nb && hdpack_resize(g_render_width) == 0) {
            s_hd_buf = nb;
            SDL_DestroyTexture(s_hd_texture);
            s_hd_texture = SDL_CreateTexture(s_renderer, SDL_PIXELFORMAT_ARGB8888,
                                             SDL_TEXTUREACCESS_STREAMING, hw, hh);
            SDL_RenderSetLogicalSize(s_renderer, hw, hh);
        } else {
            /* Pack side channel could not follow: drop to native output. */
            if (nb) s_hd_buf = nb;
            free(s_hd_buf); s_hd_buf = NULL;
            SDL_DestroyTexture(s_hd_texture); s_hd_texture = NULL;
            hdpack_unload();
            s_hd_scale = 1;
            SDL_RenderSetLogicalSize(s_renderer, g_render_width, 240);
        }
    } else {
        SDL_RenderSetLogicalSize(s_renderer, g_render_width, 240);
    }
    printf("[Video] render width %d (%dL + 256 + %dR), aspect %s\n",
           g_render_width, g_widescreen_left, g_widescreen_right,
           nes_video_aspect_name(nes_video_aspect_mode()));
}

static void zapper_on_demand_render(void) {
    if (g_dot_ppu_on)
        ppu_dot_render_snapshot(s_zapper_snapbuf);
    else
        ppu_render_frame(s_zapper_snapbuf);
    runtime_set_zapper_snapshot(s_zapper_snapbuf);
}

/* Pace normal play to the NTSC NES frame rate. SDL_GetTicks() only has
 * millisecond precision, so the old fixed 16 ms delay targeted 62.5 Hz and
 * accumulated wake-up error by restarting its clock every frame. Keep a
 * high-resolution absolute deadline instead; reset it after turbo or a long
 * host stall so normal play resumes without trying to repay stale time. */
static int s_turbo_hotkey_held = 0;

static int turbo_active(void) {
    return g_turbo || s_turbo_hotkey_held;
}

static void pace_ntsc_frame(void) {
    static double next_frame = 0.0;
    const double ntsc_hz = 60.0988;

    if (turbo_active()) {
        next_frame = 0.0;
        return;
    }

    const Uint64 frequency = SDL_GetPerformanceFrequency();
    const Uint64 now_counter = SDL_GetPerformanceCounter();
    const double frame_ticks = (double)frequency / ntsc_hz;
    const double now = (double)now_counter;

    if (next_frame == 0.0 || now > next_frame + frame_ticks * 4.0)
        next_frame = now + frame_ticks;
    else
        next_frame += frame_ticks;

    for (;;) {
        const double current = (double)SDL_GetPerformanceCounter();
        const double remaining_ticks = next_frame - current;
        if (remaining_ticks <= 0.0) break;

        const double remaining_ms =
            remaining_ticks * 1000.0 / (double)frequency;
        if (remaining_ms > 1.5)
            SDL_Delay((Uint32)(remaining_ms - 1.0));
        else
            SDL_Delay(0);
    }
}

/* ---- OAM debug window (--debug flag) ---- */
static int                s_debug         = 0;
static SDL_Window        *s_dbg_window    = NULL;
static SDL_Renderer      *s_dbg_renderer  = NULL;
static SDL_Texture       *s_dbg_texture   = NULL;
static uint32_t           s_dbg_buf[256 * 256];

/* ---- RAM Watch Window ----
 * Shows tracked RAM addresses as large human-readable cards.
 * Uses direct SDL_RenderFillRect — no pixel buffer, no coordinate flip risk.
 * Add entries with watch_add() before the game loop starts. */
#define WATCH_W          560
#define WATCH_ENTRY_H     90
#define MAX_WATCH         8

typedef struct {
    uint16_t   addr;
    const char *label;
    uint8_t    last_val;
    int        flash;     /* countdown in frames; >0 = recently changed */
    int        dirty;     /* needs redraw */
} WatchEntry;

static WatchEntry    s_watch[MAX_WATCH];
static int           s_watch_count     = 0;
static SDL_Window   *s_watch_window    = NULL;
static SDL_Renderer *s_watch_renderer  = NULL;

static void watch_add(uint16_t addr, const char *label) {
    if (s_watch_count >= MAX_WATCH) return;
    s_watch[s_watch_count++] = (WatchEntry){ addr, label, 0xFF, 0, 1 };
}

/* ---- 8x8 Bitmap Font (ASCII 0x20–0x7F) ---- */
static const uint8_t s_font8[96][8] = {
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}, /* 20   */
    {0x18,0x3C,0x3C,0x18,0x18,0x00,0x18,0x00}, /* 21 ! */
    {0x36,0x36,0x00,0x00,0x00,0x00,0x00,0x00}, /* 22 " */
    {0x36,0x36,0x7F,0x36,0x7F,0x36,0x36,0x00}, /* 23 # */
    {0x0C,0x3E,0x03,0x1E,0x30,0x1F,0x0C,0x00}, /* 24 $ */
    {0x00,0x63,0x33,0x18,0x0C,0x66,0x63,0x00}, /* 25 % */
    {0x1C,0x36,0x1C,0x6E,0x3B,0x33,0x6E,0x00}, /* 26 & */
    {0x06,0x06,0x03,0x00,0x00,0x00,0x00,0x00}, /* 27 ' */
    {0x18,0x0C,0x06,0x06,0x06,0x0C,0x18,0x00}, /* 28 ( */
    {0x06,0x0C,0x18,0x18,0x18,0x0C,0x06,0x00}, /* 29 ) */
    {0x00,0x66,0x3C,0xFF,0x3C,0x66,0x00,0x00}, /* 2A * */
    {0x00,0x0C,0x0C,0x3F,0x0C,0x0C,0x00,0x00}, /* 2B + */
    {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C,0x06}, /* 2C , */
    {0x00,0x00,0x00,0x3F,0x00,0x00,0x00,0x00}, /* 2D - */
    {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C,0x00}, /* 2E . */
    {0x60,0x30,0x18,0x0C,0x06,0x03,0x01,0x00}, /* 2F / */
    {0x3E,0x63,0x73,0x7B,0x6F,0x67,0x3E,0x00}, /* 30 0 */
    {0x0C,0x0E,0x0C,0x0C,0x0C,0x0C,0x3F,0x00}, /* 31 1 */
    {0x1E,0x33,0x30,0x1C,0x06,0x33,0x3F,0x00}, /* 32 2 */
    {0x1E,0x33,0x30,0x1C,0x30,0x33,0x1E,0x00}, /* 33 3 */
    {0x38,0x3C,0x36,0x33,0x7F,0x30,0x78,0x00}, /* 34 4 */
    {0x3F,0x03,0x1F,0x30,0x30,0x33,0x1E,0x00}, /* 35 5 */
    {0x1C,0x06,0x03,0x1F,0x33,0x33,0x1E,0x00}, /* 36 6 */
    {0x3F,0x33,0x30,0x18,0x0C,0x0C,0x0C,0x00}, /* 37 7 */
    {0x1E,0x33,0x33,0x1E,0x33,0x33,0x1E,0x00}, /* 38 8 */
    {0x1E,0x33,0x33,0x3E,0x30,0x18,0x0E,0x00}, /* 39 9 */
    {0x00,0x0C,0x0C,0x00,0x00,0x0C,0x0C,0x00}, /* 3A : */
    {0x00,0x0C,0x0C,0x00,0x00,0x0C,0x0C,0x06}, /* 3B ; */
    {0x18,0x0C,0x06,0x03,0x06,0x0C,0x18,0x00}, /* 3C < */
    {0x00,0x00,0x3F,0x00,0x00,0x3F,0x00,0x00}, /* 3D = */
    {0x06,0x0C,0x18,0x30,0x18,0x0C,0x06,0x00}, /* 3E > */
    {0x1E,0x33,0x30,0x18,0x0C,0x00,0x0C,0x00}, /* 3F ? */
    {0x3E,0x63,0x7B,0x7B,0x7B,0x03,0x1E,0x00}, /* 40 @ */
    {0x0C,0x1E,0x33,0x33,0x3F,0x33,0x33,0x00}, /* 41 A */
    {0x3F,0x66,0x66,0x3E,0x66,0x66,0x3F,0x00}, /* 42 B */
    {0x3C,0x66,0x03,0x03,0x03,0x66,0x3C,0x00}, /* 43 C */
    {0x1F,0x36,0x66,0x66,0x66,0x36,0x1F,0x00}, /* 44 D */
    {0x7F,0x46,0x16,0x1E,0x16,0x46,0x7F,0x00}, /* 45 E */
    {0x7F,0x46,0x16,0x1E,0x16,0x06,0x0F,0x00}, /* 46 F */
    {0x3C,0x66,0x03,0x03,0x73,0x66,0x7C,0x00}, /* 47 G */
    {0x33,0x33,0x33,0x3F,0x33,0x33,0x33,0x00}, /* 48 H */
    {0x1E,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* 49 I */
    {0x78,0x30,0x30,0x30,0x33,0x33,0x1E,0x00}, /* 4A J */
    {0x67,0x66,0x36,0x1E,0x36,0x66,0x67,0x00}, /* 4B K */
    {0x0F,0x06,0x06,0x06,0x46,0x66,0x7F,0x00}, /* 4C L */
    {0x63,0x77,0x7F,0x7F,0x6B,0x63,0x63,0x00}, /* 4D M */
    {0x63,0x67,0x6F,0x7B,0x73,0x63,0x63,0x00}, /* 4E N */
    {0x1C,0x36,0x63,0x63,0x63,0x36,0x1C,0x00}, /* 4F O */
    {0x3F,0x66,0x66,0x3E,0x06,0x06,0x0F,0x00}, /* 50 P */
    {0x1E,0x33,0x33,0x33,0x3B,0x1E,0x38,0x00}, /* 51 Q */
    {0x3F,0x66,0x66,0x3E,0x36,0x66,0x67,0x00}, /* 52 R */
    {0x1E,0x33,0x07,0x0E,0x38,0x33,0x1E,0x00}, /* 53 S */
    {0x3F,0x2D,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* 54 T */
    {0x33,0x33,0x33,0x33,0x33,0x33,0x3F,0x00}, /* 55 U */
    {0x33,0x33,0x33,0x33,0x33,0x1E,0x0C,0x00}, /* 56 V */
    {0x63,0x63,0x63,0x6B,0x7F,0x77,0x63,0x00}, /* 57 W */
    {0x63,0x63,0x36,0x1C,0x1C,0x36,0x63,0x00}, /* 58 X */
    {0x33,0x33,0x33,0x1E,0x0C,0x0C,0x1E,0x00}, /* 59 Y */
    {0x7F,0x63,0x31,0x18,0x4C,0x66,0x7F,0x00}, /* 5A Z */
    {0x1E,0x06,0x06,0x06,0x06,0x06,0x1E,0x00}, /* 5B [ */
    {0x03,0x06,0x0C,0x18,0x30,0x60,0x40,0x00}, /* 5C \ */
    {0x1E,0x18,0x18,0x18,0x18,0x18,0x1E,0x00}, /* 5D ] */
    {0x08,0x1C,0x36,0x63,0x00,0x00,0x00,0x00}, /* 5E ^ */
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF}, /* 5F _ */
    {0x0C,0x0C,0x18,0x00,0x00,0x00,0x00,0x00}, /* 60 ` */
    {0x00,0x00,0x1E,0x30,0x3E,0x33,0x6E,0x00}, /* 61 a */
    {0x07,0x06,0x06,0x3E,0x66,0x66,0x3B,0x00}, /* 62 b */
    {0x00,0x00,0x1E,0x33,0x03,0x33,0x1E,0x00}, /* 63 c */
    {0x38,0x30,0x30,0x3E,0x33,0x33,0x6E,0x00}, /* 64 d */
    {0x00,0x00,0x1E,0x33,0x3F,0x03,0x1E,0x00}, /* 65 e */
    {0x1C,0x36,0x06,0x0F,0x06,0x06,0x0F,0x00}, /* 66 f */
    {0x00,0x00,0x6E,0x33,0x33,0x3E,0x30,0x1F}, /* 67 g */
    {0x07,0x06,0x36,0x6E,0x66,0x66,0x67,0x00}, /* 68 h */
    {0x0C,0x00,0x0E,0x0C,0x0C,0x0C,0x1E,0x00}, /* 69 i */
    {0x30,0x00,0x30,0x30,0x30,0x33,0x33,0x1E}, /* 6A j */
    {0x07,0x06,0x66,0x36,0x1E,0x36,0x67,0x00}, /* 6B k */
    {0x0E,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* 6C l */
    {0x00,0x00,0x33,0x7F,0x7F,0x6B,0x63,0x00}, /* 6D m */
    {0x00,0x00,0x1F,0x33,0x33,0x33,0x33,0x00}, /* 6E n */
    {0x00,0x00,0x1E,0x33,0x33,0x33,0x1E,0x00}, /* 6F o */
    {0x00,0x00,0x3B,0x66,0x66,0x3E,0x06,0x0F}, /* 70 p */
    {0x00,0x00,0x6E,0x33,0x33,0x3E,0x30,0x78}, /* 71 q */
    {0x00,0x00,0x3B,0x6E,0x66,0x06,0x0F,0x00}, /* 72 r */
    {0x00,0x00,0x3E,0x03,0x1E,0x30,0x1F,0x00}, /* 73 s */
    {0x08,0x0C,0x3E,0x0C,0x0C,0x2C,0x18,0x00}, /* 74 t */
    {0x00,0x00,0x33,0x33,0x33,0x33,0x6E,0x00}, /* 75 u */
    {0x00,0x00,0x33,0x33,0x33,0x1E,0x0C,0x00}, /* 76 v */
    {0x00,0x00,0x63,0x6B,0x7F,0x7F,0x36,0x00}, /* 77 w */
    {0x00,0x00,0x63,0x36,0x1C,0x36,0x63,0x00}, /* 78 x */
    {0x00,0x00,0x33,0x33,0x33,0x3E,0x30,0x1F}, /* 79 y */
    {0x00,0x00,0x3F,0x19,0x0C,0x26,0x3F,0x00}, /* 7A z */
    {0x38,0x0C,0x0C,0x07,0x0C,0x0C,0x38,0x00}, /* 7B { */
    {0x18,0x18,0x18,0x00,0x18,0x18,0x18,0x00}, /* 7C | */
    {0x07,0x0C,0x0C,0x38,0x0C,0x0C,0x07,0x00}, /* 7D } */
    {0x6E,0x3B,0x00,0x00,0x00,0x00,0x00,0x00}, /* 7E ~ */
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF}, /* 7F   */
};

/* Draw one character directly via SDL_RenderFillRect. font8x8_basic: bit0 = leftmost pixel. */
static void watch_draw_char(int x, int y, char c, int sc, uint8_t r, uint8_t g, uint8_t b) {
    if (c < 0x20 || c > 0x7F) c = '?';
    const uint8_t *glyph = s_font8[(uint8_t)c - 0x20];
    SDL_SetRenderDrawColor(s_watch_renderer, r, g, b, 255);
    for (int gy = 0; gy < 8; gy++)
        for (int gx = 0; gx < 8; gx++)
            if (glyph[gy] & (1 << gx)) {
                SDL_Rect px = { x + gx*sc, y + gy*sc, sc, sc };
                SDL_RenderFillRect(s_watch_renderer, &px);
            }
}

static void watch_draw_str(int x, int y, const char *str, int sc, uint8_t r, uint8_t g, uint8_t b) {
    for (; *str; str++, x += 8 * sc)
        watch_draw_char(x, y, *str, sc, r, g, b);
}

static void watch_render_frame(void) {
    if (!s_watch_window || !s_watch_renderer || s_watch_count == 0) return;

    /* Check for changes */
    static uint32_t s_last_miss_count = 0xFFFFFFFF;
    int any_dirty = (g_miss_count_any != s_last_miss_count);
    s_last_miss_count = g_miss_count_any;
    for (int i = 0; i < s_watch_count; i++) {
        WatchEntry *e = &s_watch[i];
        uint8_t cur = g_ram[e->addr];
        if (cur != e->last_val) { e->last_val = cur; e->flash = 45; e->dirty = 1; }
        else if (e->flash > 0)  { e->flash--;                        e->dirty = 1; }
        if (e->dirty) any_dirty = 1;
    }
    if (!any_dirty) return;

    SDL_SetRenderDrawColor(s_watch_renderer, 10, 10, 20, 255);
    SDL_RenderClear(s_watch_renderer);

    for (int i = 0; i < s_watch_count; i++) {
        WatchEntry *e = &s_watch[i];
        e->dirty = 0;
        int oy = 6 + i * WATCH_ENTRY_H;
        int flashing = (e->flash > 0);

        /* Card background */
        SDL_SetRenderDrawColor(s_watch_renderer,
            flashing ? 20 : 15, flashing ? 30 : 15, flashing ? 16 : 26, 255);
        SDL_Rect card = { 8, oy, WATCH_W - 16, WATCH_ENTRY_H - 4 };
        SDL_RenderFillRect(s_watch_renderer, &card);

        /* Left accent bar */
        SDL_SetRenderDrawColor(s_watch_renderer,
            flashing ? 0x44 : 0x22, flashing ? 0xFF : 0x33, flashing ? 0x44 : 0x66, 255);
        SDL_Rect bar = { 8, oy, 6, WATCH_ENTRY_H - 4 };
        SDL_RenderFillRect(s_watch_renderer, &bar);

        /* Value: 2-digit hex, scale 4 */
        char val_str[8];
        snprintf(val_str, sizeof(val_str), "%02X", e->last_val);
        watch_draw_str(20, oy + 6, val_str, 4,
            flashing ? 0x88 : 0x00, 0xFF, flashing ? 0x88 : 0x99);

        /* Address, scale 2 */
        char addr_str[8];
        snprintf(addr_str, sizeof(addr_str), "$%04X", e->addr);
        watch_draw_str(110, oy + 14, addr_str, 2, 0x44, 0x55, 0x77);

        /* Description, scale 2 */
        watch_draw_str(20, oy + 52, e->label, 2, 0x99, 0xAA, 0xCC);

        /* Separator */
        SDL_SetRenderDrawColor(s_watch_renderer, 0x1A, 0x1A, 0x2A, 255);
        SDL_Rect sep = { 8, oy + WATCH_ENTRY_H - 5, WATCH_W - 16, 1 };
        SDL_RenderFillRect(s_watch_renderer, &sep);
    }

    /* Dispatch miss monitor — unique bank/address list */
    {
        int oy = 6 + s_watch_count * WATCH_ENTRY_H;

        /* Header */
        SDL_SetRenderDrawColor(s_watch_renderer, 0x22, 0x08, 0x08, 255);
        SDL_Rect hdr = { 8, oy, WATCH_W - 16, 18 };
        SDL_RenderFillRect(s_watch_renderer, &hdr);
        char hdr_str[40];
        snprintf(hdr_str, sizeof(hdr_str), "DISPATCH MISSES  total:%u", g_miss_count_any);
        watch_draw_str(14, oy + 4, hdr_str, 1, 0x88, 0x44, 0x44);

        /* One row per unique missed bank/address pair */
        int row_h = 18;
        int n = g_miss_unique_count;
        SDL_SetRenderDrawColor(s_watch_renderer, 15, 10, 10, 255);
        SDL_Rect body = { 8, oy + 20, WATCH_W - 16, (n > 0 ? n : 1) * row_h + 4 };
        SDL_RenderFillRect(s_watch_renderer, &body);

        if (n == 0) {
            watch_draw_str(20, oy + 24, "none", 1, 0x44, 0x44, 0x44);
        } else {
            for (int i = 0; i < n; i++) {
                int is_last = (g_miss_unique_addrs[i] == g_miss_last_addr &&
                               g_miss_unique_banks[i] == g_miss_last_bank);
                char row[24];
                snprintf(row, sizeof(row), "%d:$%04X",
                         g_miss_unique_banks[i], g_miss_unique_addrs[i]);
                int rx = 20 + (i % 3) * 120;
                int ry = oy + 24 + (i / 3) * row_h;
                watch_draw_str(rx, ry, row, 2,
                    is_last ? 0xFF : 0xAA,
                    is_last ? 0x66 : 0x55,
                    is_last ? 0x22 : 0x55);
            }
        }
    }

    SDL_RenderPresent(s_watch_renderer);
}

/* ---- Audio state ---- */
static SDL_AudioDeviceID  s_audio_dev = 0;
#define AUDIO_SAMPLES_PER_FRAME 735
#define AUDIO_MAX_SAMPLES_PER_FRAME 900
#define AUDIO_SOURCE_RATE        44100.0
static int16_t            s_audio_frame[AUDIO_MAX_SAMPLES_PER_FRAME];
/* Carry-accumulator sample push: the guest's true frame length (measured as
 * the delta between consecutive VBlank boundary cycle stamps) converts into a
 * fractional sample count at the APU source rate. Each frame pushes
 * floor(carry + frame_len * rate / cpu_hz) samples and keeps the fraction, so
 * the audio clock tracks the video clock with zero long-term drift instead of
 * assuming a fixed 29780.5-cycle frame. */
static double s_audio_sample_carry = 0.0;

/* SDL audio callback (round-2): runs on the audio thread at the device's steady
 * cadence and pulls mono samples from the bridge. This is the consumer that the
 * old push model lacked; it never stalls on video-frame jitter. */
static void nes_audio_cb(void *ud, Uint8 *stream, int len) {
    (void)ud;
    int frames = len / (int)sizeof(int16_t);   /* mono S16 */
    if (s_bridge_ready) {
        SDL_LockMutex(s_audio_mtx);
        rab_pull(&s_bridge, (int16_t *)stream, frames);
        SDL_UnlockMutex(s_audio_mtx);
        recomp_audio_debug_push_i16("t3_bridge_out", (int16_t *)stream,
                                    frames, s_bridge.cfg.host_rate, 1);
    } else {
        SDL_memset(stream, 0, (size_t)len);
    }
}

/* ---- Screenshot ---- */
/* Non-static wrapper so ppu_renderer.c can save PNGs */
void save_png(const char *path, int w, int h, const void *rgb, int stride) {
    stbi_write_png(path, w, h, 3, rgb, stride);
}

/* Save an ARGB8888 buffer as PNG. Callable from game code (emulated mode screenshots). */
void runner_save_argb_png(const char *path, const uint32_t *argb, int w, int h) {
    static uint8_t rgb[NES_MAX_RENDER_WIDTH * 240 * 3];  /* max framebuffer width */
    int pixels = w * h;
    for (int i = 0; i < pixels; i++) {
        uint32_t px = argb[i];
        rgb[i*3+0] = (px >> 16) & 0xFF;
        rgb[i*3+1] = (px >>  8) & 0xFF;
        rgb[i*3+2] = (px      ) & 0xFF;
    }
    stbi_write_png(path, w, h, 3, rgb, w * 3);
}

static void save_screenshot(void) {
    char path[128];
    snprintf(path, sizeof(path), "C:/temp/mm3_shot_%04llu.png",
             (unsigned long long)g_frame_count);
    static uint8_t rgb[256 * 240 * 3];
    for (int i = 0; i < 256 * 240; i++) {
        uint32_t px = s_framebuf[i];
        rgb[i*3+0] = (px >> 16) & 0xFF;
        rgb[i*3+1] = (px >>  8) & 0xFF;
        rgb[i*3+2] = (px      ) & 0xFF;
    }
    stbi_write_png(path, 256, 240, 3, rgb, 256*3);
    printf("[Shot] Saved %s\n", path);
}

/* Save the current native framebuffer to a given path as PNG.
 * Callable from game hooks (e.g. TCP screenshot command). */
void runner_screenshot(const char *path) {
    runner_save_argb_png(path, s_framebuf, g_render_width, 240);
}

uint32_t *runner_get_framebuffer(void) {
    return s_framebuf;
}

/* ---- Debug trace log (C:/temp/debug_trace.txt) ---- */
#if !defined(NESRECOMP_TRACE) || NESRECOMP_TRACE
static FILE *s_debug_log = NULL;

static void debug_log_open(void) {
    s_debug_log = fopen("C:/temp/debug_trace.txt", "w");
    if (s_debug_log) {
        fprintf(s_debug_log, "FRAME,slot,Y,tile,attr,X\n");
        fflush(s_debug_log);
    }
}

/* One-time dump of CHR tiles A0-C0 + all 32 palette bytes when item sprites appear */
static int s_chr_dumped = 0;
static void chr_dump_once(uint64_t frame) {
    if (s_chr_dumped) return;
    s_chr_dumped = 1;
    FILE *f = fopen("C:/temp/chr_dump.txt", "w");
    if (!f) return;
    /* Palette dump */
    fprintf(f, "PALETTE:");
    for (int i = 0; i < 32; i++) fprintf(f, " %02X", g_ppu_pal[i]);
    fprintf(f, "  (at frame %llu)\n", (unsigned long long)frame);
    /* CHR tile dump */
    fprintf(f, "CHR_ADDR,B0,B1,B2,B3,B4,B5,B6,B7,B8,B9,BA,BB,BC,BD,BE,BF\n");
    for (int tile = 0xA0; tile <= 0xC0; tile++) {
        int addr = tile * 16;
        fprintf(f, "%04X", addr);
        for (int b = 0; b < 16; b++) fprintf(f, ",%02X", g_chr_ram[addr+b]);
        fprintf(f, "\n");
    }
    fclose(f);
    printf("[CHR] Dumped CHR+PAL at frame %llu\n", (unsigned long long)frame);
}

/* Call at NMI time to log one line per frame. Comment out when not debugging. */
static void debug_log_frame(uint64_t frame) {
    if (!s_debug_log) return;
    /* Log all visible OAM entries every frame: FRAME,slot,Y,tile,attr,X */
    for (int s = 0; s < 64; s++) {
        uint8_t sy = g_ppu_oam[s*4+0];
        if (sy < 240) {
            fprintf(s_debug_log, "%llu,%d,%02X,%02X,%02X,%02X\n",
                    (unsigned long long)frame, s,
                    sy, g_ppu_oam[s*4+1],
                    g_ppu_oam[s*4+2], g_ppu_oam[s*4+3]);
        }
    }
    fflush(s_debug_log);
}
#else
static inline void debug_log_open(void) {}
static inline void debug_log_frame(uint64_t frame) { (void)frame; }
#endif

/* ---- Zapper mouse → NES coordinate conversion ---- */
static void zapper_mouse_to_nes(int mouse_x, int mouse_y) {
    if (!s_renderer || !s_window) return;
    /* Get the actual renderer output size (accounts for DPI scaling) */
    int out_w, out_h;
    SDL_GetRendererOutputSize(s_renderer, &out_w, &out_h);
    /* Get window size to compute DPI ratio */
    int win_w, win_h;
    SDL_GetWindowSize(s_window, &win_w, &win_h);
    /* Mouse events use window coordinates — scale to output pixels */
    float dpi_x = (float)out_w / win_w;
    float dpi_y = (float)out_h / win_h;
    float px = mouse_x * dpi_x;
    float py = mouse_y * dpi_y;
    /* Compute letterboxed render area within the output */
    float scale_x = (float)out_w / g_render_width;
    float scale_y = (float)out_h / 240.0f;
    float scale = (scale_x < scale_y) ? scale_x : scale_y;
    float render_w = g_render_width * scale;
    float render_h = 240.0f * scale;
    float offset_x = (out_w - render_w) / 2.0f;
    float offset_y = (out_h - render_h) / 2.0f;
    /* Map to NES coordinates */
    int nes_x = (int)((px - offset_x) * g_render_width / render_w);
    int nes_y = (int)((py - offset_y) * 240.0f / render_h);
    if (nes_x < 0) nes_x = 0;
    if (nes_x > 255) nes_x = 255;
    if (nes_y < 0) nes_y = 0;
    if (nes_y > 239) nes_y = 239;
    g_zapper_x = nes_x;
    g_zapper_y = nes_y;
}

/* ---- Smoke test results ---- */
static void smoke_write_results(void) {
    FILE *f = s_smoke_output ? fopen(s_smoke_output, "w") : stdout;
    if (!f) f = stdout;
    fprintf(f, "{\n");
    fprintf(f, "  \"frames_run\": %llu,\n", (unsigned long long)g_frame_count);
    fprintf(f, "  \"dispatch_miss_count\": %u,\n", g_miss_count_any);
    fprintf(f, "  \"dispatch_miss_unique\": %u,\n",
            (unsigned)g_miss_unique_total);
    fprintf(f, "  \"dispatch_misses\": [");
    for (int i = 0; i < g_miss_unique_count; i++) {
        fprintf(f, "%s\"$%04X\"", i ? ", " : "", g_miss_unique_addrs[i]);
    }
    fprintf(f, "],\n");
    fprintf(f, "  \"dispatch_miss_keys\": [");
    for (int i = 0; i < g_miss_unique_count; i++) {
        fprintf(f, "%s{\"bank\":%d,\"addr\":\"$%04X\"}",
                i ? ", " : "", g_miss_unique_banks[i],
                g_miss_unique_addrs[i]);
    }
    fprintf(f, "],\n");
    fprintf(f, "  \"frame_hashes\": {\n");
    for (int i = 0; i < s_smoke_hash_count; i++) {
        fprintf(f, "    \"%d\": \"%08x\"%s\n",
                s_smoke_hash_frames[i], s_smoke_hashes[i],
                (i < s_smoke_hash_count - 1) ? "," : "");
    }
    fprintf(f, "  }\n");
    fprintf(f, "}\n");
    if (s_smoke_output && f != stdout) fclose(f);
}

static void benchmark_write_results(Uint64 end_counter) {
    Uint64 frequency = SDL_GetPerformanceFrequency();
    Uint64 elapsed_ticks = end_counter >= s_benchmark_start
        ? end_counter - s_benchmark_start : 0;
    double elapsed = frequency && end_counter >= s_benchmark_start
        ? (double)elapsed_ticks / (double)frequency
        : 0.0;
    double ms_per_frame = s_benchmark_frames > 0
        ? elapsed * 1000.0 / (double)s_benchmark_frames : 0.0;
    double fps = elapsed > 0.0
        ? (double)s_benchmark_frames / elapsed : 0.0;
    uint32_t final_crc = crc32_compute(
        (const uint8_t *)s_framebuf,
        (size_t)g_render_width * 240 * sizeof(uint32_t));

    FILE *f = s_benchmark_output ? fopen(s_benchmark_output, "w") : stdout;
    if (!f) f = stdout;
    fprintf(f, "{\n");
    fprintf(f, "  \"build_id\": \"%s\",\n", NESRECOMP_BENCH_BUILD_ID);
    fprintf(f, "  \"warmup_frames\": %d,\n", s_benchmark_warmup);
    fprintf(f, "  \"measured_frames\": %d,\n", s_benchmark_frames);
    fprintf(f, "  \"elapsed_seconds\": %.9f,\n", elapsed);
    fprintf(f, "  \"ms_per_frame\": %.6f,\n", ms_per_frame);
    fprintf(f, "  \"fps\": %.3f,\n", fps);
    fprintf(f, "  \"render_width\": %d,\n", g_render_width);
    fprintf(f, "  \"final_frame_crc32\": \"%08x\",\n", final_crc);
    fprintf(f, "  \"dispatch_miss_count\": %u%s\n",
            g_miss_count_any, s_benchmark_breakdown ? "," : "");
    if (s_benchmark_breakdown) {
        Uint64 known_callback_ticks =
            s_benchmark_nmi_ticks +
            s_benchmark_post_nmi_ticks +
            s_benchmark_sprite0_ticks +
            s_benchmark_ppu_ticks +
            s_benchmark_post_render_ticks;
        Uint64 callback_other_ticks =
            s_benchmark_callback_ticks > known_callback_ticks
                ? s_benchmark_callback_ticks - known_callback_ticks : 0;
        Uint64 guest_ticks = elapsed_ticks > s_benchmark_callback_ticks
            ? elapsed_ticks - s_benchmark_callback_ticks : 0;
#define BENCHMARK_PHASE_JSON(name, ticks, comma) \
        fprintf(f, "    \"" name "_ms_per_frame\": %.6f,\n", \
                frequency && s_benchmark_frames > 0 \
                    ? (double)(ticks) * 1000.0 / \
                      ((double)frequency * (double)s_benchmark_frames) : 0.0); \
        fprintf(f, "    \"" name "_percent\": %.3f%s\n", \
                elapsed_ticks ? (double)(ticks) * 100.0 / (double)elapsed_ticks : 0.0, \
                comma)
        fprintf(f, "  \"breakdown\": {\n");
        BENCHMARK_PHASE_JSON("guest_between_callbacks", guest_ticks, ",");
        BENCHMARK_PHASE_JSON("nmi", s_benchmark_nmi_ticks, ",");
        BENCHMARK_PHASE_JSON("post_nmi", s_benchmark_post_nmi_ticks, ",");
        BENCHMARK_PHASE_JSON("ppu_render", s_benchmark_ppu_ticks, ",");
        BENCHMARK_PHASE_JSON("sprite0_predict", s_benchmark_sprite0_ticks, ",");
        BENCHMARK_PHASE_JSON("post_render", s_benchmark_post_render_ticks, ",");
        BENCHMARK_PHASE_JSON("callback_other", callback_other_ticks, "");
        fprintf(f, "  }\n");
#undef BENCHMARK_PHASE_JSON
    }
    fprintf(f, "}\n");
    if (s_benchmark_output && f != stdout) fclose(f);
}

/* ---- VBlank callback (called from ppu_read_reg when $2002 bit7 fires) ---- */
void nes_vblank_callback(void) {
    static uint64_t s_cb_count = 0;
    int benchmark_measure_callback =
        s_benchmark_breakdown &&
        s_benchmark_start != 0 &&
        runtime_get_vblank_depth() <= 1;
    Uint64 benchmark_callback_start = benchmark_measure_callback
        ? SDL_GetPerformanceCounter() : 0;
    Uint64 benchmark_phase_start;
    int pre_nmi_rendered = 0;
    int pre_nmi_render_irq = 0;
    runtime_begin_frame_callback();
    nes_fallback_telemetry_frame_boundary();
    if (s_cb_count == 0) { /* debug_log_open(); */ }
    s_cb_count++;
    if (runtime_get_vblank_depth() <= 1) {
        s_rb_tick_replay = 0;
        rb_frame_top();
    }

    /* Dot-PPU: complete the just-finished frame and publish it to the
     * presentation framebuffer, then arm the next frame's visible region.
     * Runs before the NMI handler below (so PPU memory still reflects the
     * finished frame) and before the present further down. No-op when off. */
    ppu_dot_frame_boundary();
    if (g_pre_nmi_render_on && !g_dot_ppu_on) {
        extern int g_render_irq_fired;
        extern uint8_t g_render_irq_ppuctrl_before, g_render_irq_ppuctrl_after;
        extern uint8_t g_render_irq_scrollx_before, g_render_irq_scrollx_after;
        extern uint8_t g_render_irq_scrolly_before, g_render_irq_scrolly_after;
        extern int g_render_irq_chr_changed;
        ppu_render_frame(s_framebuf);
        pre_nmi_rendered = 1;
        pre_nmi_render_irq =
            g_render_irq_fired &&
            (g_render_irq_chr_changed ||
             g_render_irq_ppuctrl_before != g_render_irq_ppuctrl_after ||
             g_render_irq_scrollx_before != g_render_irq_scrollx_after ||
             g_render_irq_scrolly_before != g_render_irq_scrolly_after);
    }
    if (s_debug && (s_cb_count <= 100 || s_cb_count % 60 == 0))
        printf("[VBlank] callback #%llu frame=%llu\n",
               (unsigned long long)s_cb_count, (unsigned long long)g_frame_count);

    /* In headless modes, skip all SDL input/event handling. There is no
     * window or real keyboard, so the only queued key events are ones an input
     * script injected (KEY_TAP); route those to the game hook so scripted host
     * keys (e.g. voxel camera numpad) take effect, and drop everything else. */
    if (headless_run_active()) {
        if (SDL_WasInit(SDL_INIT_EVENTS)) {
            SDL_Event ev;
            while (SDL_PollEvent(&ev)) {
#ifdef NESRECOMP_GAME_SDL_EVENT_HOOK
                extern void NESRECOMP_GAME_SDL_EVENT_HOOK(const SDL_Event *event);
                if (ev.type == SDL_KEYDOWN || ev.type == SDL_KEYUP)
                    NESRECOMP_GAME_SDL_EVENT_HOOK(&ev);
#else
                (void)ev;
#endif
            }
        }
        goto smoke_skip_input;
    }

    /* Handle SDL events */
    SDL_Event ev;
    while (SDL_PollEvent(&ev)) {
        controller_handle_event(&ev);  /* gamepad hotplug */
#ifdef NESRECOMP_GAME_SDL_EVENT_HOOK
        extern void NESRECOMP_GAME_SDL_EVENT_HOOK(const SDL_Event *event);
        NESRECOMP_GAME_SDL_EVENT_HOOK(&ev);
#endif
        if (ev.type == SDL_QUIT) {
            fprintf(stderr, "[RunnerExit] SDL_QUIT during frame input at frame %llu\n",
                    (unsigned long long)g_frame_count);
            exit(0);
        }
        if (ev.type == SDL_WINDOWEVENT &&
            ev.window.event == SDL_WINDOWEVENT_CLOSE) {
            fprintf(stderr, "[RunnerExit] SDL_WINDOWEVENT_CLOSE at frame %llu\n",
                    (unsigned long long)g_frame_count);
            exit(0);
        }
        if (ev.type == SDL_WINDOWEVENT &&
            ev.window.event == SDL_WINDOWEVENT_SIZE_CHANGED && s_renderer) {
            /* Live aspect ("Fit"): only queue the geometry change here; it is
             * applied after this frame's present (video_apply_pending). */
            int out_w = 0, out_h = 0;
            SDL_GetRendererOutputSize(s_renderer, &out_w, &out_h);
            nes_video_on_window_resized(out_w, out_h);
        }
        if (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_ESCAPE) {
#ifdef NESRECOMP_NET
            if (nes_netplay_active())
                netplay_return_to_lobby("local player left");
#endif
            fprintf(stderr, "[RunnerExit] Escape key at frame %llu\n",
                    (unsigned long long)g_frame_count);
            exit(0);
        }
        if (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_TAB
#ifdef NESRECOMP_NET
            && !nes_netplay_active()   /* no wall-clock catch-up online */
#endif
            )
            s_turbo_hotkey_held = 1;
        if (ev.type == SDL_KEYUP && ev.key.keysym.sym == SDLK_TAB)
            s_turbo_hotkey_held = 0;
        if (ev.type == SDL_KEYDOWN && !ev.key.repeat) {
            int slot = savestate_slot_from_scancode(ev.key.keysym.scancode);
            if (slot &&
#ifdef NESRECOMP_NET
                !nes_netplay_active()
#else
                1
#endif
            ) {
                char path[1200];
                savestate_slot_path(slot, path, sizeof(path));
                if (ev.key.keysym.mod & KMOD_SHIFT) {
                    savestate_save(path);
                } else {
                    uint64_t load_frame = g_frame_count;
                    if (savestate_load(path)) {
                        record_loadstate(load_frame, path);
                        record_sync_frame(g_frame_count); /* restored frame baseline */
                    }
                }
            }
        }
        /* Toggle fullscreen: Alt+Enter. Flips between windowed and the
         * CONFIGURED tri-state mode (2 = exclusive, otherwise borderless-desktop)
         * so the hotkey respects the launcher's choice. SDL_WINDOW_FULLSCREEN_DESKTOP
         * contains the SDL_WINDOW_FULLSCREEN bit, so masking with plain
         * SDL_WINDOW_FULLSCREEN alone still detects EITHER mode. */
        if (ev.type == SDL_KEYDOWN && s_window &&
            ev.key.keysym.sym == SDLK_RETURN && (ev.key.keysym.mod & KMOD_ALT)) {
            Uint32 is_fs = SDL_GetWindowFlags(s_window) & SDL_WINDOW_FULLSCREEN;
            Uint32 want = (g_nes_config.fullscreen == 2)
                              ? SDL_WINDOW_FULLSCREEN
                              : SDL_WINDOW_FULLSCREEN_DESKTOP;
            SDL_SetWindowFullscreen(s_window, is_fs ? 0 : want);
        }
    }

    /* Zapper mouse input: poll absolute mouse position each frame. A script
     * TRIGGER takes precedence — the mouse must not clobber a scripted aim/
     * trigger (it would reset g_zapper_x/y/trigger every frame, defeating any
     * headless deterministic Zapper test). */
    if (g_zapper_enabled && keybinds_zapper_mouse() && s_window && !script_has_trigger_override()) {
        int mx, my;
        Uint32 buttons = SDL_GetMouseState(&mx, &my);
        zapper_mouse_to_nes(mx, my);
        g_zapper_trigger = (buttons & SDL_BUTTON_LMASK) ? 1 : 0;
    }

    /* Update controllers from keyboard state via configurable keybinds */
    if (!headless_run_active()) {
        const uint8_t *keys = SDL_GetKeyboardState(NULL);
        /* P1 may use keyboard or gamepad. P2 is an explicitly assigned gamepad
         * (or a netplay peer), never a second hidden keyboard layout. */
        int s1 = g_nes_config.player_src[0], s2 = g_nes_config.player_src[1];
        uint8_t btn = (uint8_t)((s1 == 1 ? keybinds_read_player(keys, 1) : 0) |
                                (s1 == 2 ? controller_read_player(1)      : 0));

        /* Recording: capture combined input before script override */
        record_tick(g_frame_count, btn, turbo_active());

        /* Script override: if a script is loaded, use its button state */
        int sp = script_get_buttons();
        if (sp >= 0) btn = (uint8_t)sp;

        /* TCP debug server override: set_input command */
        int tcp_btn = debug_server_get_input_override();
        if (tcp_btn >= 0) btn = (uint8_t)tcp_btn;

        g_controller1_buttons = btn;
        g_controller2_buttons = (uint8_t)(s2 == 2 ? controller_read_player(2) : (NESRECOMP_INPUT_SEATS > 2 && s2 == 1 ? keybinds_read_player(keys,2) : 0));
        for (int p=2; p<NESRECOMP_INPUT_SEATS; ++p) {
            int src = g_nes_config.player_src[p];
            g_logical_input[p] = src==1 ? keybinds_read_player(keys,p+1) : src==2 ? controller_read_player(p+1) : 0;
        }
    }

smoke_skip_input:

    if (headless_run_active()) {
        int sp = script_get_buttons();
        if (sp >= 0) g_controller1_buttons = (uint8_t)sp;
        int tcp_btn = debug_server_get_input_override();
        if (tcp_btn >= 0) g_controller1_buttons = (uint8_t)tcp_btn;
        g_controller2_buttons = 0;
    }

    for (int p=2; p<=NESRECOMP_INPUT_SEATS; ++p) {
        int sp=script_get_player_buttons(p);
        if (p==2) { if(sp>=0) g_controller2_buttons=(uint8_t)sp; }
        else if(sp>=0) g_logical_input[p-1]=(uint8_t)sp;
    }

    /* Nested callbacks resolve guest spin-waits but do not present or advance
     * g_frame_count, so consuming WAIT commands there runs scripts ahead. */
    if (runtime_get_vblank_depth() <= 1)
        script_tick(g_frame_count, g_ram);

    /* TCP debug server: poll for commands each frame. Polled in smoke mode
     * too — headless runs are the main consumer of automated TCP probes,
     * and the poll is non-blocking. */
    debug_server_poll();

    /* Log per-frame state BEFORE NMI runs */
    debug_log_frame(s_cb_count);

    if (s_debug) {
        log_on_change("$46_mode", g_ram[0x46]);
        log_on_change("$68_palChg", g_ram[0x68]);
        log_on_change("$5E_state", g_ram[0x5E]);
        log_on_change("$66_ppuUpd", g_ram[0x66]);
    }
    /* Clear sprite-0 hit (bit6) and sprite-overflow (bit5) at frame start.
     * Real NES clears these at the pre-render scanline. The per-frame renderer
     * approximates by clearing here (VBlank start). The dot-PPU clears them at
     * the actual pre-render line instead (ppu_dot.c) — clearing at VBlank start
     * breaks games whose NMI waits for the PREVIOUS frame's sprite-0 hit to
     * clear (SMB's Sprite0Clr) before waiting for the new one. */
    if (!g_dot_ppu_on)
        g_ppustatus &= ~0x60;
    /* Set VBlank flag unconditionally — game can poll $2002 to detect it. */
    g_ppustatus |= 0x80;
    /* Gate NMI on PPUCTRL bit7 (NMI enable). On real NES, the PPU only
     * generates an NMI at VBlank if bit7 of $2000 is set. The game clears
     * this bit during room transitions (while PPU rendering is disabled) to
     * prevent the NMI handler from running the sprite-0 spin-wait with
     * rendering off, which would loop forever. */
    if (s_debug)
        log_on_change("NMI_enable", (g_ppuctrl >> 7) & 1);
    if (runtime_get_vblank_depth() <= 1)
        rb_pre_tick();
    game_on_frame(g_frame_count);
    save_ram_tick();   /* wall-time-throttled dirty SRAM flush; no-op when inactive */


    /* Frame boundary: always call game_run_nmi so per-frame work (oracle
     * sync in --verify, frame counter advancement, etc.) runs every
     * wall-clock frame regardless of NMI-enable.  game_run_nmi is
     * responsible for gating the game's actual NMI handler on
     * (g_ppuctrl & 0x80) and the nested-depth check internally. */
    if (getenv("NESRECOMP_TRACE_STATE")) {
        static uint64_t s_state_dbg_frame = 0;
        s_state_pre33  = g_ram[0x33];
        s_state_nmi_en = (g_ppuctrl >> 7) & 1;
        s_state_depth  = runtime_get_vblank_depth();
        s_state_dbg_frame = g_frame_count;
    }
    if ((g_ppuctrl & 0x80) && runtime_get_vblank_depth() > 1) {
        if (g_nested_nmi_policy == NESTED_NMI_RUN_HANDLER) {
            /* Re-entrant-NMI game (e.g. SMB3): its handler is nested-safe by
             * design and progression DEPENDS on the nested run (the nested
             * IntNMI takes the light path and DECs VBlank_Tick, releasing
             * in-NMI wait loops). Run it with the same register/stack
             * save-restore discipline as the top-level path. */
            uint8_t s_pre = g_cpu.S;
            uint8_t a_pre = g_cpu.A, x_pre = g_cpu.X, y_pre = g_cpu.Y;
            uint8_t n_pre = g_cpu.N, v_pre = g_cpu.V, d_pre = g_cpu.D;
            uint8_t i_pre = g_cpu.I, z_pre = g_cpu.Z, c_pre = g_cpu.C;
            uint8_t p_save = (uint8_t)((g_cpu.N<<7)|(g_cpu.V<<6)|(1<<5)|
                                       (g_cpu.D<<3)|(g_cpu.I<<2)|(g_cpu.Z<<1)|g_cpu.C);
            g_ram[0x100+g_cpu.S] = 0x00;   g_cpu.S--;   /* PCH placeholder */
            g_ram[0x100+g_cpu.S] = 0x00;   g_cpu.S--;   /* PCL placeholder */
            g_ram[0x100+g_cpu.S] = p_save; g_cpu.S--;   /* P (status flags) */
            g_cpu.I = 1; /* NMI sets I after pushing the interrupted P */
            runtime_note_interrupt_entry();
            nes_dring_mark('N', (uint16_t)runtime_get_vblank_depth());
            nes_fring_push('N', (uint16_t)runtime_get_vblank_depth());
            game_run_nmi();
            nes_dring_mark('n', (uint16_t)runtime_get_vblank_depth());
            if (g_rti_target == 0) {
                g_cpu.S = s_pre;
                g_cpu.A = a_pre; g_cpu.X = x_pre; g_cpu.Y = y_pre;
                g_cpu.N = n_pre; g_cpu.V = v_pre; g_cpu.D = d_pre;
                g_cpu.I = i_pre; g_cpu.Z = z_pre; g_cpu.C = c_pre;
            }
        } else {
            /* Legacy: skip the handler (would corrupt mid-VRAM transfer
             * state), but still set $1A/$20 to resolve any spin-wait (SMB).
             * A game may explicitly opt in to an additional flag address;
             * Tetris uses $33, which is unrelated state in other titles. */
            nes_resolve_nested_nmi_spin_flags();
            s_state_shim_fired = 1;
        }
    } else {
        /* Top-level frame boundary (or NMI-disabled frame): delegate to
         * game_run_nmi which decides whether to execute func_NMI. The
         * generated func_NMI simulates the hardware stack frame so direct
         * callers (verify mode, game overrides) get the same semantics. */
        int nmi_will_run = (g_ppuctrl & 0x80) != 0;
        uint8_t s_pre_nmi = g_cpu.S;
        /* Save all CPU registers.  On real 6502, the NMI handler's
         * PHP/PHA/.../PLA/PLP sequence always restores A/X/Y/flags.
         * But the recompiled NMI handler may bail early (stack mismatch),
         * skipping the PLA/PLP epilogue.  Without this save/restore,
         * the interrupted game code resumes with corrupted registers,
         * causing bugs like sprite tile corruption on the title screen. */
        uint8_t a_pre = g_cpu.A, x_pre = g_cpu.X, y_pre = g_cpu.Y;
        uint8_t n_pre = g_cpu.N, v_pre = g_cpu.V, d_pre = g_cpu.D;
        uint8_t i_pre = g_cpu.I, z_pre = g_cpu.Z, c_pre = g_cpu.C;
        if (nmi_will_run) {
            uint8_t p_save = (uint8_t)((g_cpu.N<<7)|(g_cpu.V<<6)|(1<<5)|
                                       (g_cpu.D<<3)|(g_cpu.I<<2)|(g_cpu.Z<<1)|g_cpu.C);
            g_ram[0x100+g_cpu.S] = 0x00;   g_cpu.S--;   /* PCH placeholder */
            g_ram[0x100+g_cpu.S] = 0x00;   g_cpu.S--;   /* PCL placeholder */
            g_ram[0x100+g_cpu.S] = p_save; g_cpu.S--;   /* P (status flags) */
            g_cpu.I = 1; /* NMI sets I after pushing the interrupted P */
            runtime_note_interrupt_entry();
            runtime_set_vblank_firing(1);
            nes_dring_mark('N', (uint16_t)runtime_get_vblank_depth());
            nes_fring_push('T', (uint16_t)runtime_get_vblank_depth());
        }
        benchmark_phase_start = benchmark_measure_callback
            ? SDL_GetPerformanceCounter() : 0;
        game_run_nmi();
        if (benchmark_measure_callback)
            s_benchmark_nmi_ticks +=
                SDL_GetPerformanceCounter() - benchmark_phase_start;
        if (nmi_will_run) {
            nes_dring_mark('n', (uint16_t)runtime_get_vblank_depth());
            runtime_set_vblank_firing(0);
            /* On real 6502, plain RTI restores S and all registers back to
             * the interrupted context. If the handler hijacked RTI, though,
             * func_NMI has already run the hijacked post-NMI code as resumed
             * game code; keep its CPU state instead of rewinding to the
             * interrupt-time snapshot. */
            if (g_rti_target == 0) {
                g_cpu.S = s_pre_nmi;
                g_cpu.A = a_pre; g_cpu.X = x_pre; g_cpu.Y = y_pre;
                g_cpu.N = n_pre; g_cpu.V = v_pre; g_cpu.D = d_pre;
                g_cpu.I = i_pre; g_cpu.Z = z_pre; g_cpu.C = c_pre;
            }
        }
    }

    /* Nested VBlanks (depth > 1) exist only to resolve spin-waits ($1A).
     * They must NOT run post-NMI, render, present, or advance frame count.
     * On real NES, NMI never re-enters — running PostNMI (sound engine,
     * etc.) during a nested NMI causes side effects like shadow OAM
     * corruption from sprite management code in the PostNMI chain. */
    if (runtime_get_vblank_depth() > 1) {
        finish_frame_callback();
        return;
    }

    benchmark_phase_start = benchmark_measure_callback
        ? SDL_GetPerformanceCounter() : 0;
    game_post_nmi(g_frame_count);
    if (benchmark_measure_callback)
        s_benchmark_post_nmi_ticks +=
            SDL_GetPerformanceCounter() - benchmark_phase_start;

    /* [STATE] per-frame debug tap (env NESRECOMP_TRACE_STATE): post-NMI ZP
     * snapshot for NMI-mode/palette-gate debugging ($BD = NMI mode, $BE/$A3
     * gate the palette upload loops in func_94EE). */
    if (getenv("NESRECOMP_TRACE_STATE")) {
        fprintf(stderr,
                "[STATE] f=%llu pre33=%02X nmiEn=%d depth=%d shim=%d "
                "33=%02X 68=%02X 69=%02X BD=%02X BE=%02X "
                "A3=%02X B9=%02X B0=%02X C0=%02X B1=%02X mask=%02X\n",
                (unsigned long long)g_frame_count,
                s_state_pre33, s_state_nmi_en, s_state_depth,
                s_state_shim_fired,
                g_ram[0x33], g_ram[0x68], g_ram[0x69], g_ram[0xBD],
                g_ram[0xBE], g_ram[0xA3], g_ram[0xB9], g_ram[0xB0],
                g_ram[0xC0], g_ram[0xB1], g_ppumask);
        if (g_frame_count % 60 == 0) {
            fprintf(stderr, "[PALDUMP] f=%llu pal:", (unsigned long long)g_frame_count);
            for (int i = 0; i < 32; i++) fprintf(stderr, " %02X", g_ppu_pal[i]);
            fprintf(stderr, "\n");
        }
        s_state_shim_fired = 0;
    }

    /* Record frame state to ring buffer for TCP timeseries queries */
    debug_server_record_frame();

    /* This is the one stable suspension point shared by every frame: the
     * game's NMI and post-NMI work have completed, but presentation and the
     * frame-count increment have not.  Keeping the TCP pause loop here makes
     * save/load resume on the same native call-stack continuation instead of
     * taking a snapshot at the earlier command-poll point and restoring it at
     * an unrelated phase of the callback. */
    debug_server_wait_if_paused();

    /* Cross-engine RNG/seed freeze (env-gated, accuracy harness) — applied at
     * the frame boundary so the nesref oracle and recomp share identical RNG. */
    { extern void nes_apply_freeze(void); nes_apply_freeze(); }

    /* Co-sim trace emission (WRAM/PPU/hash) — emitted here POST-NMI-handler so the
     * sampled state is at the same phase as the oracle (end-of-frame). The row is
     * tagged with the cycle-DERIVED video-frame index (round(g_frame_boundary_cyc /
     * 29780.5)), not a per-NMI counter, so NMI-off / suppressed frames don't skew
     * the index — the frames that emit carry their true video-frame number and align
     * to the oracle across gaps. Each trace fn is individually env-gated (no-op when
     * unset). See g_cosim_vframe / nes_cosim_emit_boundary. */
    { extern void nes_cosim_emit_boundary(void); nes_cosim_emit_boundary(); }

    /* (The APU frame-counter IRQ is driven on the CPU-cycle stream in
     * maybe_trigger_vblank → apu_clock_cycles, not per-NMI here, so it also
     * advances for NMI-disabled main-thread code such as the blargg APU tests.) */

    /* Generate one frame of audio after NMI (APU registers now up-to-date).
     * Skip in turbo mode — queued audio would pile up faster than it drains.
     *
     * Carry-accumulator pacing: the guest's true frame length (delta of
     * consecutive VBlank boundary cycle stamps) is converted to a fractional
     * sample count at the APU source rate. Each frame pushes
     * floor(carry + frame_cycles * rate / cpu_hz) samples and retains the
     * fraction, so the pushed audio tracks the video clock exactly (long-term
     * drift = 0) instead of a fixed 735 samples per nominal 29781-cycle frame.
     * cpu_hz = 21477272.727 (master) / 12 = 1789772.727; NTSC APU rate 44100. */
    if (s_audio_dev && !turbo_active() && !headless_run_active() && !s_rb_tick_replay) {
        static uint64_t s_last_boundary_cyc = 0;
        static int      s_have_boundary = 0;
        int push_n = AUDIO_SAMPLES_PER_FRAME;
        if (s_have_boundary && g_frame_boundary_cyc > s_last_boundary_cyc) {
            uint64_t delta = g_frame_boundary_cyc - s_last_boundary_cyc;
            /* clamp to one-frame outliers (startup gaps, debugger stalls) */
            if (delta >= 20000 && delta <= 45000) {
                double want = s_audio_sample_carry
                    + (double)delta * (AUDIO_SOURCE_RATE / 1789772.727);
                push_n = (int)want;
                if (push_n < 600)  push_n = 600;
                if (push_n > AUDIO_MAX_SAMPLES_PER_FRAME)
                    push_n = AUDIO_MAX_SAMPLES_PER_FRAME;
                /* Clamping an outlier must not create an unbounded sample
                 * debt. Carry only the fractional part into the next frame. */
                s_audio_sample_carry = want - (double)(int)want;
            }
        }
        s_last_boundary_cyc = g_frame_boundary_cyc;
        s_have_boundary = 1;
        static int s_synth_mode = -2;            /* -2 = not yet queried */
        static uint64_t s_synth_pos = 0;
        if (s_synth_mode == -2) s_synth_mode = recomp_audio_synth_mode();
        if (s_synth_mode != RAD_SYNTH_OFF)
            recomp_audio_synth_fill(s_synth_mode, s_audio_frame,
                                    push_n, 1, AUDIO_SOURCE_RATE, &s_synth_pos);
        else
            apu_generate(s_audio_frame, push_n);

        /* T1: raw emulator-rate PCM, before volume. */
        recomp_audio_debug_push_i16("t1_apu", s_audio_frame,
                                    push_n, AUDIO_SOURCE_RATE, 1);

        /* T0: per-channel raw DAC levels for the same 735-sample window
         * (pulse1/pulse2/triangle/noise/dmc), staged by apu_generate. NULL
         * when capture is off; skipped when a synth source replaced the APU. */
        if (s_synth_mode == RAD_SYNTH_OFF) {
            static const char *t0_names[5] =
                {"t0_pulse1", "t0_pulse2", "t0_triangle", "t0_noise", "t0_dmc"};
            for (int t0c = 0; t0c < 5; t0c++) {
                const int16_t *t0buf = apu_debug_t0(t0c);
                if (t0buf) recomp_audio_debug_push_i16(t0_names[t0c], t0buf,
                                                       push_n, AUDIO_SOURCE_RATE, 1);
            }
        }

        /* Trusted mods share the NES device and clock-domain bridge. Mix on
         * the producer thread before launcher volume so APU and overlays obey
         * the same user setting and the callback remains game-agnostic. */
        nes_mod_audio_mix(s_audio_frame, push_n);

        /* Apply the launcher volume (0..100) as a linear scale. */
        int vol = g_nes_config.volume;
        if (vol < 100) {
            if (vol < 0) vol = 0;
            for (int i = 0; i < push_n; i++)
                s_audio_frame[i] = (int16_t)((int)s_audio_frame[i] * vol / 100);
        }
        /* T2: what the bridge receives. */
        recomp_audio_debug_push_i16("t2_bridge_in", s_audio_frame,
                                    push_n, AUDIO_SOURCE_RATE, 1);

        if (s_bridge_ready) {
            SDL_LockMutex(s_audio_mtx);
            rab_push(&s_bridge, s_audio_frame, push_n);
            double fill = rab_fill_ms(&s_bridge);
            rab_stats st; rab_get_stats(&s_bridge, &st);
            SDL_UnlockMutex(s_audio_mtx);
            recomp_audio_debug_eventf("bfill",
                                      "fill_ms=%.1f under=%llu over=%llu stretch_f=%llu stretch_e=%llu",
                                      fill, (unsigned long long)st.underrun_events,
                                      (unsigned long long)st.overflow_drops,
                                      (unsigned long long)st.stretch_frames,
                                      (unsigned long long)st.stretch_events);
        } else {
            /* legacy fallback (bridge failed to init): raw queue push, capped
             * so a stalled consumer cannot accumulate an unbounded backlog. */
            if (SDL_GetQueuedAudioSize(s_audio_dev) < (Uint32)(AUDIO_SOURCE_RATE * 0.15 * sizeof(int16_t)))
                SDL_QueueAudio(s_audio_dev, s_audio_frame,
                               push_n * sizeof(int16_t));
        }
    }

    /* Headless capture helper: RECOMP_AUDIO_DEBUG_DUMP_SECS=N dumps the rings and
     * exits after N seconds of audio frames (for data collection, not ear tests). */
    if (recomp_audio_debug_enabled()) {
        static int s_dump_frames = -2;   /* -2 = unqueried, -1 = disabled */
        static uint64_t s_audio_frames_seen = 0;
        if (s_dump_frames == -2) {
            const char *e = getenv("RECOMP_AUDIO_DEBUG_DUMP_SECS");
            s_dump_frames = (e && *e) ? (int)(atof(e) * 60.0) : -1;
        }
        if (s_dump_frames > 0) {
            s_audio_frames_seen++;
            if ((int)s_audio_frames_seen >= s_dump_frames) {
                recomp_audio_debug_dump(0.0, NULL);
                printf("[audio-debug] dumped after %llu frames; exiting\n",
                       (unsigned long long)s_audio_frames_seen);
                fflush(stdout);
                nesrecomp_expect_process_exit();
                exit(0);
            }
        }
    }

    /* Predict sprite-0-hit scanline for this frame using the post-NMI OAM
     * and PPU state. Used by ppu_read_reg($2002) to set bit 6 at the right
     * CPU cycle position so games whose hit-detect spin-waits poll $2002
     * mid-frame (Gumshoe-style zappers) see the bit flip when the beam
     * would actually have reached sprite 0. */
    benchmark_phase_start = benchmark_measure_callback
        ? SDL_GetPerformanceCounter() : 0;
    g_predicted_spr0_scanline = ppu_predict_spr0_hit_scanline();
    if (benchmark_measure_callback)
        s_benchmark_sprite0_ticks +=
            SDL_GetPerformanceCounter() - benchmark_phase_start;

    /* Render PPU to framebuffer.
     * Dot-PPU mode (default): the frame was painted incrementally into the back
     * buffer (during this budget's NMI + main loop) and published to s_framebuf
     * by ppu_dot_frame_boundary at the next frame boundary — including
     * widescreen — so the per-frame compositor is skipped. Only NESRECOMP_DOT_PPU=0
     * uses ppu_render_frame now. */
    if (!g_dot_ppu_on && (!g_pre_nmi_render_on ||
                          (pre_nmi_rendered && !pre_nmi_render_irq))) {
        extern int g_disable_render_irq;
        int old_disable_render_irq = g_disable_render_irq;
        if (pre_nmi_rendered && !pre_nmi_render_irq)
            g_disable_render_irq = 1;
        benchmark_phase_start = benchmark_measure_callback
            ? SDL_GetPerformanceCounter() : 0;
        ppu_render_frame(s_framebuf);
        { extern uint32_t g_ppu_render_calls, g_ppu_render_skipped;
          extern uint8_t g_ppu_render_last_mask, g_ppu_render_last_pal0;
          if (getenv("NESRECOMP_TRACE_RENDER")) {
              extern uint8_t g_ppu_pal[0x20];
              fprintf(stderr, "[RENDER] f=%llu mask=$%02X pal0=$%02X calls=%u skipped=%u pal:",
                      (unsigned long long)g_frame_count,
                      g_ppu_render_last_mask, g_ppu_render_last_pal0,
                      g_ppu_render_calls, g_ppu_render_skipped);
              for (int _i = 0; _i < 8; _i++) fprintf(stderr, " %02X", g_ppu_pal[_i]);
              fprintf(stderr, "\n");
          } }
        if (benchmark_measure_callback)
            s_benchmark_ppu_ticks +=
                SDL_GetPerformanceCounter() - benchmark_phase_start;
        g_disable_render_irq = old_disable_render_irq;
    }

    /* Update Zapper light sensor framebuffer for next frame's $4017 reads */
    runtime_set_zapper_framebuf(s_framebuf);

    /* Game-specific post-render (e.g. widescreen margin sprites) */
    benchmark_phase_start = benchmark_measure_callback
        ? SDL_GetPerformanceCounter() : 0;
    game_post_render(s_framebuf);
    if (benchmark_measure_callback)
        s_benchmark_post_render_ticks +=
            SDL_GetPerformanceCounter() - benchmark_phase_start;

    /* Per-frame PNG dump (env-gated debug tap): NESRECOMP_FRAME_DUMP=<prefix>
     * dumps every frame in [NESRECOMP_FRAME_DUMP_LO, _HI] as <prefix><NNNN>.png
     * from the final framebuffer. Placed before the smoke early-return so it
     * works headless too. Re-added on fix/gumshoe-yoshiscookie-artifacts. */
    {
        static int s_fd_state = -1;
        static const char *s_fd_prefix = NULL;
        static unsigned long long s_fd_lo = 0, s_fd_hi = ~0ULL;
        if (s_fd_state < 0) {
            s_fd_prefix = getenv("NESRECOMP_FRAME_DUMP");
            s_fd_state = (s_fd_prefix && s_fd_prefix[0]) ? 1 : 0;
            const char *lo = getenv("NESRECOMP_FRAME_DUMP_LO");
            const char *hi = getenv("NESRECOMP_FRAME_DUMP_HI");
            if (lo && lo[0]) s_fd_lo = strtoull(lo, NULL, 10);
            if (hi && hi[0]) s_fd_hi = strtoull(hi, NULL, 10);
        }
        if (s_fd_state == 1 && g_frame_count >= s_fd_lo && g_frame_count <= s_fd_hi) {
            char p[256];
            snprintf(p, sizeof(p), "%s%04llu.png", s_fd_prefix,
                     (unsigned long long)g_frame_count);
            runner_screenshot(p);
        }
    }

    /* Scroll-free nametable dump (env-gated debug tap): NESRECOMP_NT_DUMP=<frame>
     * writes both physical nametables side-by-side to NESRECOMP_NT_DUMP_PATH (or
     * C:/temp/nt_dump.png) on that frame. Localizes render-vs-state bugs. */
    {
        static int s_nt_state = -1;
        static unsigned long long s_nt_frame = 0;
        static const char *s_nt_path = NULL;
        if (s_nt_state < 0) {
            const char *e = getenv("NESRECOMP_NT_DUMP");
            s_nt_state = (e && e[0]) ? 1 : 0;
            if (s_nt_state) s_nt_frame = strtoull(e, NULL, 10);
            s_nt_path = getenv("NESRECOMP_NT_DUMP_PATH");
            if (!s_nt_path || !s_nt_path[0]) s_nt_path = "C:/temp/nt_dump.png";
        }
        if (s_nt_state == 1 && g_frame_count == s_nt_frame) {
            extern void ppu_dump_nametables(const char *path);
            ppu_dump_nametables(s_nt_path);
        }
    }

    /* Smoke test: hash framebuffer at intervals and check exit */
    if (s_smoke_frames) {
        {
            char shot_path[256];
            if (script_wants_screenshot(shot_path, sizeof(shot_path))) {
                runner_screenshot(shot_path);
                printf("[Shot] %s\n", shot_path);
            }
        }
        {
            int ec = script_check_exit();
            if (ec >= 0) {
                smoke_write_results();
                if (ec == 0) nesrecomp_expect_process_exit();
                fprintf(stderr, "[RunnerExit] input script requested exit %d at frame %llu\n",
                        ec, (unsigned long long)g_frame_count);
                exit(ec);
            }
        }
        if (g_frame_count % s_smoke_interval == 0 &&
            s_smoke_hash_count < SMOKE_MAX_HASHES) {
            s_smoke_hashes[s_smoke_hash_count] =
                crc32_compute((const uint8_t *)s_framebuf,
                              (size_t)g_render_width * 240 * sizeof(uint32_t));
            s_smoke_hash_frames[s_smoke_hash_count] = (int)g_frame_count;
            s_smoke_hash_count++;
        }
        g_frame_count++;
        if ((int)g_frame_count >= s_smoke_frames) {
            extern int g_nes_expected_exit;
            g_nes_expected_exit = 1;
            smoke_write_results();
            nesrecomp_expect_process_exit();
            exit(0);
        }
        finish_frame_callback();
        return; /* skip all SDL rendering/pacing */
    }

    /* Benchmark: use the fully-rendered headless path above, but time only
     * post-warmup frames and calculate one final CRC outside the timed range. */
    if (s_benchmark_frames) {
        int ec = script_check_exit();
        if (ec >= 0) {
            fprintf(stderr,
                    "[Benchmark] input script exited before completion "
                    "(frame=%llu, code=%d)\n",
                    (unsigned long long)g_frame_count, ec);
            exit(ec ? ec : 2);
        }

        g_frame_count++;
        if ((int)g_frame_count == s_benchmark_warmup) {
            benchmark_breakdown_reset();
            s_benchmark_start = SDL_GetPerformanceCounter();
        }

        if ((int)g_frame_count >=
            s_benchmark_warmup + s_benchmark_frames) {
            Uint64 end_counter = SDL_GetPerformanceCounter();
            if (benchmark_measure_callback)
                s_benchmark_callback_ticks +=
                    end_counter - benchmark_callback_start;
            extern int g_nes_expected_exit;
            g_nes_expected_exit = 1;
            benchmark_write_results(end_counter);
            nesrecomp_expect_process_exit();
            exit(0);
        }
        if (benchmark_measure_callback)
            s_benchmark_callback_ticks +=
                SDL_GetPerformanceCounter() - benchmark_callback_start;
        return;
    }

    /* OAM debug window — updated every 6 frames to avoid flicker/lag */
    if (s_debug && s_dbg_texture && g_frame_count % 6 == 0) {
        ppu_render_oam_debug(s_dbg_buf);
        SDL_UpdateTexture(s_dbg_texture, NULL, s_dbg_buf, 256 * 4);
        SDL_RenderClear(s_dbg_renderer);
        SDL_RenderCopy(s_dbg_renderer, s_dbg_texture, NULL, NULL);
        SDL_RenderPresent(s_dbg_renderer);
        /* Update debug window title with frame + visible sprite count */
        {
            int vis = 0;
            for (int _s = 0; _s < 64; _s++)
                if (g_ppu_oam[_s*4] < 0xEF) vis++;
            char title[80];
            snprintf(title, sizeof(title),
                     "OAM Debug  frame=%llu  visible=%d  sprCHR=$%04X",
                     (unsigned long long)g_frame_count, vis,
                     (g_ppuctrl & 0x08) ? 0x1000 : 0x0000);
            SDL_SetWindowTitle(s_dbg_window, title);
        }
    }

    /* RAM watch window */
    watch_render_frame();

    /* Script-triggered named screenshot */
    {
        char shot_path[256];
        if (script_wants_screenshot(shot_path, sizeof(shot_path))) {
            if (s_hd_buf && hdpack_active() && !ppu_renderer_custom_render_active()) {
                /* Capture the HD output so screenshots match what is displayed. */
                int hw = g_render_width * s_hd_scale, hh = 240 * s_hd_scale;
                hdpack_upscale(s_framebuf, g_render_width, s_hd_buf);
                uint8_t *rgb = (uint8_t *)malloc((size_t)hw * hh * 3);
                if (rgb) {
                    for (int i = 0; i < hw * hh; i++) {
                        uint32_t px = s_hd_buf[i];
                        rgb[i*3+0] = (px >> 16) & 0xFF;
                        rgb[i*3+1] = (px >>  8) & 0xFF;
                        rgb[i*3+2] = (px      ) & 0xFF;
                    }
                    stbi_write_png(shot_path, hw, hh, 3, rgb, hw * 3);
                    free(rgb);
                    printf("[Shot] %s (HD %dx%d)\n", shot_path, hw, hh);
                }
            } else {
                static uint8_t rgb[NES_MAX_RENDER_WIDTH * 240 * 3];  /* max framebuffer width */
                int npx = g_render_width * 240;
                for (int i = 0; i < npx; i++) {
                    uint32_t px = s_framebuf[i];
                    rgb[i*3+0] = (px >> 16) & 0xFF;
                    rgb[i*3+1] = (px >>  8) & 0xFF;
                    rgb[i*3+2] = (px      ) & 0xFF;
                }
                stbi_write_png(shot_path, g_render_width, 240, 3, rgb, g_render_width*3);
                printf("[Shot] %s\n", shot_path);
            }
            /* Optional 8KB CHR snapshot dump (authoring HD packs for CHR-RAM
             * games — the active pattern tables aren't in the ROM). */
            const char *chrdump = getenv("NESRECOMP_CHR_DUMP");
            if (chrdump && chrdump[0]) {
                FILE *cf = fopen(chrdump, "wb");
                if (cf) { fwrite(g_chr_ram, 1, 0x2000, cf); fclose(cf);
                          printf("[ChrDump] %s (8KB)\n", chrdump); }
            }
        }
    }

    /* Exit check after screenshot is saved */
    {
        int ec = script_check_exit();
        if (ec >= 0) {
            if (ec == 0) nesrecomp_expect_process_exit();
            fprintf(stderr, "[RunnerExit] input script requested exit %d at frame %llu\n",
                    ec, (unsigned long long)g_frame_count);
            exit(ec);
        }
    }

#ifdef NESRECOMP_NET
    /* NES_NET_SHOT_TICK=N + NES_NET_SHOT_PATH: the frame tick N rendered,
     * rewritten by every replay of N, so the file left is the confirmed one
     * (compared across peers by tools/rb_loopback.sh). */
    if (nes_netplay_active()) {
        static long shot = -2;
        static const char *shot_path;
        if (shot == -2) {
            const char *e = getenv("NES_NET_SHOT_TICK");
            shot_path = getenv("NES_NET_SHOT_PATH");
            shot = (e && e[0] && shot_path && shot_path[0]) ? atol(e) : -1;
        }
        if (shot >= 0 && (long)nes_netplay_current_tick() == shot) {
            runner_screenshot(shot_path);
            /* NES_NET_SHOT_STATE=<file>: the snapshot image of the same
             * confirmed tick (u32 length + V7 save-state + trailer; strip the
             * first 4 bytes for a .sav), for reading game state behind a
             * screenshot. Rewritten by every replay of the tick. */
            {
                const char *sp = getenv("NES_NET_SHOT_STATE");
                if (sp && sp[0]) {
                    size_t n = 0;
                    const uint8_t *img;
                    nes_rb_state_invalidate();
                    img = nes_rb_state_image(&n);
                    FILE *f = img ? fopen(sp, "wb") : NULL;
                    if (f) { fwrite(img, 1, n, f); fclose(f); }
                }
            }
        }
    }
#endif
    /* Auto-screenshot disabled — use F8 or input scripts for screenshots */
    /* if (g_frame_count % 120 == 0) { save_screenshot(); } */
    g_frame_count++;

    /* NES_RUN_FRAMES=N (windowed runs, e.g. the in-process offline Play after
     * a rematch): stop at frame N and print the machine's identity so a
     * harness can compare it with a fresh process's run of the same length. */
    {
        static long s_run_frames = -1;
        if (s_run_frames < 0) {
            const char *e = getenv("NES_RUN_FRAMES");
            s_run_frames = (e && e[0]) ? atol(e) : 0;
        }
        if (s_run_frames > 0 && (long)g_frame_count >= s_run_frames
#ifdef NESRECOMP_NET
            && !nes_netplay_active()
#endif
        ) {
            NesRbDigest d;
            uint32_t fb = crc32_compute((const uint8_t *)s_framebuf,
                                        (size_t)g_render_width * 240 * sizeof(uint32_t));
            nes_rb_state_invalidate();
            nes_rb_state_digest(&d);
            fprintf(stderr, "RUN_DONE frames=%llu fb_crc=%08x state=%08x cpu_wram=%08x "
                            "ppu=%08x apu_io_mods=%08x\n",
                    (unsigned long long)g_frame_count, (unsigned)fb, (unsigned)d.master,
                    (unsigned)d.part[0], (unsigned)d.part[1], (unsigned)d.part[2]);
            {
                const char *shot = getenv("NES_RUN_SCREENSHOT");
                if (shot && shot[0]) runner_screenshot(shot);
            }
            fflush(stderr); fflush(stdout);
            nesrecomp_expect_process_exit();
            exit(0);
        }
    }

    /* Zapper crosshair — always visible when enabled in keybinds.ini */
    if (g_zapper_enabled && keybinds_zapper_mouse() && keybinds_zapper_crosshair()) {
        int cx = g_zapper_x, cy = g_zapper_y;
        uint32_t color = g_zapper_trigger ? 0xFFFF0000 : 0xFFFFFFFF; /* red on fire, white otherwise */
        /* Draw crosshair: horizontal and vertical lines, 11px each */
        for (int d = -5; d <= 5; d++) {
            if (d == 0) continue; /* skip center, drawn separately */
            int hx = cx + d, vy = cy + d;
            if (hx >= 0 && hx < g_render_width && cy >= 0 && cy < 240)
                s_framebuf[cy * g_render_width + hx] = color;
            if (cx >= 0 && cx < g_render_width && vy >= 0 && vy < 240)
                s_framebuf[vy * g_render_width + cx] = color;
        }
        /* Center dot — always bright */
        if (cx >= 0 && cx < g_render_width && cy >= 0 && cy < 240)
            s_framebuf[cy * g_render_width + cx] = 0xFFFFFFFF;
    }

#ifdef NESRECOMP_NET
    /* A tick's host cost: admit -> the frame's work done, before the present
     * (which may wait on vsync) and the pacing sleep. */
    if (s_rb_tick_t0 && nes_netplay_active()) {
        nes_netplay_rb_note_tick_cost(s_rb_tick_replay,
            (double)(SDL_GetPerformanceCounter() - s_rb_tick_t0) * 1e6 /
            (double)SDL_GetPerformanceFrequency());
        s_rb_tick_t0 = 0;
    }
#endif
    /* Upload texture and present.
     * In turbo mode, only present every 16th frame to avoid vsync blocking
     * on every SDL_RenderPresent call (~6ms each on a 165Hz monitor). */
    if (!s_rb_tick_replay && (!turbo_active() || (g_frame_count & 15) == 0)) {
        /* Present-time palette swap (opt-in, default Raw = passthrough). Raw
         * presents the raw framebuffer untouched => byte-identical to canon. */
        const uint32_t *present = s_framebuf;
        if (!color_lut_is_passthrough()) {
            color_lut_apply(s_framebuf, s_present_buf, g_render_width, 240);
            present = s_present_buf;
        }
        SDL_RenderClear(s_renderer);
        if (s_hd_texture && hdpack_active() && !ppu_renderer_custom_render_active()) {
            /* HD pack active: upscale the native frame + per-pixel side channel
             * into the HD buffer, present the HD texture. (A game-owned wide
             * compositor bypasses the pack: its side channel is native-space.) */
            hdpack_upscale(present, g_render_width, s_hd_buf);
            SDL_UpdateTexture(s_hd_texture, NULL, s_hd_buf, g_render_width * s_hd_scale * 4);
            SDL_RenderCopy(s_renderer, s_hd_texture, NULL, NULL);
        } else {
            SDL_UpdateTexture(s_texture, NULL, present, g_render_width * 4);
            SDL_RenderCopy(s_renderer, s_texture, NULL, NULL);
        }
        SDL_RenderPresent(s_renderer);
        if (s_startup_first_frame) {
            startup_timing_mark("first_frame_presented");
            s_startup_first_frame = 0;
        }
    }

    /* Safe point for a queued geometry change: this frame is presented, the
     * next one has not started rendering. */
    video_apply_pending();

    if (!s_rb_tick_replay) pace_ntsc_frame();
    finish_frame_callback();
}

/* ---- Public render function for an external emulator mode ---- */
/* Accepts a 256x240 ARGB8888 buffer and presents it to the SDL window.
 * Used by game-specific emulator-backed frame loops. */
void runner_present_framebuf(const uint32_t *argb_buf) {
    if (!s_texture || !s_renderer || !argb_buf) return;
    /* Copy to s_framebuf so TCP screenshots see the presented frame. */
    memcpy(s_framebuf, argb_buf, (size_t)g_render_width * 240 * 4);
    SDL_UpdateTexture(s_texture, NULL, argb_buf, g_render_width * 4);
    SDL_RenderClear(s_renderer);
    SDL_RenderCopy(s_renderer, s_texture, NULL, NULL);
    SDL_RenderPresent(s_renderer);
}

/* ---- ROM Loading ---- */
static uint8_t *s_prg_data = NULL;
static int      s_prg_banks = 0;
static uint8_t *s_chr_rom_full = NULL; /* Full CHR ROM for bank switching */
static int      s_rom_has_battery = 0; /* iNES header[6] bit1 — battery-backed SRAM */

static bool load_rom(const char *path) {
#ifdef NESRECOMP_NET
    /* content_fingerprint: SHA-256 of the exact image this process runs. */
    (void)nes_netplay_identity_set_rom_file(path);
#endif
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "Cannot open %s\n", path); return false; }

    uint8_t header[16];
    fread(header, 1, 16, f);

    if (header[0]!='N'||header[1]!='E'||header[2]!='S'||header[3]!=0x1A) {
        fprintf(stderr, "Not an iNES ROM\n");
        fclose(f); return false;
    }

    s_prg_banks   = header[4];
    int chr_banks = header[5];
    int mapper    = ((header[6] >> 4) & 0x0F) | (header[7] & 0xF0);
    int mirroring = (header[6] & 0x01);  /* 0=horizontal, 1=vertical */
    int has_trainer = (header[6] & 0x04) ? 1 : 0;
    s_rom_has_battery = (header[6] & 0x02) ? 1 : 0;

    printf("[Runner] ROM: %d PRG banks x 16KB, %d CHR banks x 8KB, Mapper %d\n",
           s_prg_banks, chr_banks, mapper);

    if (has_trainer) fseek(f, 512, SEEK_CUR);

    /* Load PRG ROM */
    size_t prg_size = (size_t)s_prg_banks * 0x4000;
    s_prg_data = (uint8_t *)malloc(prg_size);
    if (!s_prg_data) { fclose(f); return false; }
    fread(s_prg_data, 1, prg_size, f);

    /* Load CHR ROM, if present.
     * For multi-bank CHR ROM, store the full data for mapper bank switching.
     * The mapper will copy the correct bank(s) into g_chr_ram (8KB PPU view).
     * For CHR RAM games (chr_banks==0), g_chr_ram starts zeroed and
     * is populated dynamically via PPU $2007 DMA writes. */
    if (chr_banks > 0) {
        size_t chr_size = (size_t)chr_banks * 0x2000;
        s_chr_rom_full = (uint8_t *)malloc(chr_size);
        if (s_chr_rom_full) {
            size_t n = fread(s_chr_rom_full, 1, chr_size, f);
            printf("[Runner] CHR ROM: loaded %zu bytes (%d banks)\n", n, chr_banks);
            /* Copy first 8KB into g_chr_ram as initial state */
            size_t init_size = (chr_size < sizeof(g_chr_ram)) ? chr_size : sizeof(g_chr_ram);
            memcpy(g_chr_ram, s_chr_rom_full, init_size);
        }
        g_chr_is_rom = 1; /* protect CHR ROM from PPU $2007 writes */
    }

    fclose(f);

    const uint8_t *fixed = s_prg_data + (size_t)(s_prg_banks - 1) * 0x4000;
    uint16_t nmi   = fixed[0x3FFA] | ((uint16_t)fixed[0x3FFB] << 8);
    uint16_t reset = fixed[0x3FFC] | ((uint16_t)fixed[0x3FFD] << 8);
    uint16_t irq   = fixed[0x3FFE] | ((uint16_t)fixed[0x3FFF] << 8);
    printf("[Runner] Vectors: NMI=$%04X RESET=$%04X IRQ=$%04X\n", nmi, reset, irq);

    mapper_init(s_prg_data, s_prg_banks, mapper, mirroring);
    if (s_chr_rom_full && chr_banks > 0)
        mapper_init_chr(s_chr_rom_full, chr_banks);
    return true;
}

/* ---- PRG ROM writable accessor (for runtime text/data overrides) ----
 * Returns a writable pointer to the start of the given 16KB PRG bank,
 * or NULL if bank_num is out of range or ROM not yet loaded.
 * The caller may write override bytes into this buffer; nes_read() will
 * return the patched values on subsequent reads from that address range.
 * Safe to call from game_on_init() after ROM is loaded. */
uint8_t *runner_get_prg_bank_rw(int bank_num) {
    if (!s_prg_data || bank_num < 0 || bank_num >= s_prg_banks) return NULL;
    return s_prg_data + (size_t)bank_num * 0x4000;
}

/*
 * nesrecomp_runner_run — main runner entry point, called by launcher.c after
 * ROM discovery and CRC verification. argv[1] is guaranteed to be the ROM path.
 */
int nesrecomp_runner_run(int argc, char *argv[]) {
    startup_timing_begin();
    startup_timing_mark("runner_enter");
    video_alloc_buffers();

    /* Parse optional flags */
    for (int i = 2; i < argc; i++) {
        if      (strcmp(argv[i], "--script")    == 0 && i+1 < argc) s_script_path    = argv[++i];
        else if (strcmp(argv[i], "--record")    == 0 && i+1 < argc) s_record_path    = argv[++i];
        else if (strcmp(argv[i], "--loadstate") == 0 && i+1 < argc) s_loadstate_path = argv[++i];
        else if (strcmp(argv[i], "--debug")     == 0) s_debug = 1;
        else if (strcmp(argv[i], "--smoke")     == 0 && i+1 < argc) s_smoke_frames   = atoi(argv[++i]);
        else if (strcmp(argv[i], "--smoke-interval") == 0 && i+1 < argc) s_smoke_interval = atoi(argv[++i]);
        else if (strcmp(argv[i], "--smoke-output")   == 0 && i+1 < argc) s_smoke_output   = argv[++i];
        else if (strcmp(argv[i], "--benchmark") == 0 && i+1 < argc) s_benchmark_frames = atoi(argv[++i]);
        else if (strcmp(argv[i], "--benchmark-warmup") == 0 && i+1 < argc) s_benchmark_warmup = atoi(argv[++i]);
        else if (strcmp(argv[i], "--benchmark-output") == 0 && i+1 < argc) s_benchmark_output = argv[++i];
        else if (strcmp(argv[i], "--benchmark-breakdown") == 0) s_benchmark_breakdown = 1;
        else {
            /* Offer remaining args to the game-specific handler */
            const char *val = (i+1 < argc && argv[i+1][0] != '-') ? argv[i+1] : NULL;
            if (game_handle_arg(argv[i], val)) {
                if (val) i++; /* game consumed the value */
            }
        }
    }

    if (s_debug) printf("[Debug] OAM debug window enabled\n");

    if (!load_rom(argv[1])) exit(1);
    startup_timing_mark("rom_loaded");

    /* Expose ROM path to game extras (used by verify mode to init FCEUX) */
    extern const char *g_rom_path_for_extras;
    g_rom_path_for_extras = argv[1];

    runtime_session_reset();
    runtime_init();
    keybinds_init(argv[0]);
    savestate_slots_init();
    game_on_init();
    startup_timing_mark("game_initialized");

    nes_rb_probe_init();
#ifdef NESRECOMP_NET
    int net_on = 0;
    nes_runner_register_session_keys();
    {
        NesNetplayConfig net;
        int from_lobby = nes_netplay_take_pending_config(&net);
        if (!from_lobby) nes_netplay_config_defaults(&net);
        nes_netplay_config_apply_env(&net);
        if (net.enabled) {
            /* Refuse, before connecting, what an online session cannot
             * honour: every input must come from the published rows, and a
             * rewind/record path outside the episode driver would put local
             * state into the shared simulation (recomp-ai-rules/NETPLAY.md). */
            const char *refuse = NULL;
            if (s_script_path) refuse = "input scripts";
            else if (s_record_path) refuse = "input recording";
            else if (s_loadstate_path) refuse = "--loadstate";
            else if (nes_rb_probe_active()) refuse = "NES_RB_PROBE";
            else if (s_smoke_frames || s_benchmark_frames) refuse = "--smoke/--benchmark";
#if NESRECOMP_ENABLE_MODS
            else if (nes_mod_local_only_reason()) refuse = nes_mod_local_only_reason();
#endif
            if (refuse) {
                fprintf(stderr, "[Netplay] %s requires local play — refusing the "
                                "online session before connecting.\n", refuse);
                /* A lobby launch goes back to the room (nonzero return); an
                 * environment-driven launch has no room to go back to. */
                if (!from_lobby || getenv("NES_NET_EXIT_ON_RETURN")) {
                    nesrecomp_expect_process_exit();
                    exit(1);
                }
                return 1;
            }
            if (nes_netplay_start(&net) != 0) {
                fprintf(stderr, "[Netplay] Could not start the requested session (%s).\n",
                        nes_netplay_last_error());
                if (!from_lobby || getenv("NES_NET_EXIT_ON_RETURN")) {
                    nesrecomp_expect_process_exit();
                    exit(1);
                }
                return 1;
            }
            net_on = 1;
            g_nes_session_locked = 1;
        }
        nes_netplay_set_publish_hook(rb_on_publish);
        nes_netplay_set_resim_hook(rb_on_resim);
    }
#endif

    /* SRAM persistence (saves/<title>.srm <-> g_sram). Auto-enabled for battery
     * games via the iNES bit; synthetic-SRAM games opt in from game_on_init()
     * (which ran just above) via save_ram_request_enable(). NONE backend = no-op.
     * A netplay guest resolves to its sandbox (nes_netplay_start). */
    save_ram_init(game_get_name(), s_rom_has_battery);
#ifdef NESRECOMP_NET
    if (net_on && nes_netplay_boot_barrier() != 0) {
        fprintf(stderr, "[Netplay] Match could not boot (%s) — back to the lobby.\n",
                nes_netplay_last_error());
        nes_netplay_shutdown();
        g_nes_session_locked = 0;
        if (getenv("NES_NET_EXIT_ON_RETURN")) { nesrecomp_expect_process_exit(); exit(3); }
        return 1;
    }
#endif

    if (g_zapper_enabled) {
        runtime_set_zapper_render_callback(zapper_on_demand_render);
        if (keybinds_zapper_mouse())
            printf("[Zapper] Mouse mode enabled — left click to shoot\n");
    }

    if (s_loadstate_path) savestate_load(s_loadstate_path);
    if (s_record_path) { record_open(s_record_path); atexit(record_close); }
    if (s_script_path) script_load(s_script_path);

    /* Dot-accurate PPU (opt-in, EXPERIMENTAL): reads NESRECOMP_DOT_PPU and
     * registers the framebuffer. No-op (per-frame renderer) unless set. */
    ppu_dot_init(s_framebuf);

    if (s_benchmark_frames < 0 || s_benchmark_warmup < 0) {
        fprintf(stderr, "[Benchmark] frame counts must be non-negative\n");
        exit(2);
    }

    /* In smoke/benchmark mode, skip all SDL initialization and run headless.
     * Input scripts still need the event queue (no window, no video) so
     * KEY_TAP reaches the game hook through the real SDL event path. */
    if (headless_run_active()) {
        if (s_script_path && !SDL_WasInit(SDL_INIT_EVENTS) &&
            SDL_InitSubSystem(SDL_INIT_EVENTS) < 0)
            fprintf(stderr, "[Script] SDL events unavailable (%s); KEY_TAP will fail\n",
                    SDL_GetError());
        if (s_benchmark_frames) {
            printf("[Benchmark] Headless mode: warmup=%d measured=%d\n",
                   s_benchmark_warmup, s_benchmark_frames);
            if (s_benchmark_warmup == 0)
                s_benchmark_start = SDL_GetPerformanceCounter();
        } else {
            printf("[Smoke] Headless mode: running %d frames, hashing every %d\n",
                   s_smoke_frames, s_smoke_interval);
        }
        fflush(stdout); /* publish headless startup before entering the guest */
        memset(s_framebuf, 0, VIDEO_BUF_BYTES);
        run_guest_execution();
        fprintf(stderr, "[Headless] game_run_main returned unexpectedly at frame %llu\n",
                (unsigned long long)g_frame_count);
        nes_dump_dispatch_ring();
        if (s_smoke_frames) smoke_write_results();
        exit(1);
    }

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER) < 0) {
        fprintf(stderr, "SDL_Init: %s\n", SDL_GetError());
        exit(1);
    }

    /* Gamepad support (Xbox/PS/Switch/generic via SDL's mapping DB). */
    startup_timing_mark("sdl_initialized");
    controller_init();
    startup_timing_mark("controllers_opened");

    /* Open audio device — use SDL_QueueAudio (callback=NULL) to push samples
     * from the game thread without needing a separate audio thread. */
    {
        SDL_AudioSpec want;
        SDL_memset(&want, 0, sizeof(want));
        want.freq     = 44100;
        want.format   = AUDIO_S16SYS;
        want.channels = 1;
        want.samples  = 512;
        want.callback = nes_audio_cb;   /* round-2: pull from the bridge */
        SDL_AudioSpec got;
        s_audio_dev = SDL_OpenAudioDevice(NULL, 0, &want, &got,
                                          SDL_AUDIO_ALLOW_FREQUENCY_CHANGE);
        if (s_audio_dev == 0) {
            fprintf(stderr, "[APU] SDL_OpenAudioDevice: %s (continuing without audio)\n",
                    SDL_GetError());
        } else {
            s_audio_mtx = SDL_CreateMutex();
            rab_config rc; rab_config_defaults(&rc);
            rc.channels    = 1;
            rc.source_rate = 44100.0;
            rc.host_rate   = (double)got.freq;
            /* Video-paced bursts (~100 ms swing) plus the carry-accumulator
             * push variance need a moderately deep target; 40 ms holds the
             * ring near its steady state without starving the callback. */
            rc.target_ms   = 40.0;
            rc.ring_ms     = 250.0;
            /* Allow up to +/-3% ratio correction so the controller can track a
             * real producer/consumer clock mismatch and hold the fill at target
             * instead of drifting toward underrun/overflow. Only the steady-state
             * offset is continuous; for matched clocks it sits near 0. */
            rc.max_correction = 0.03;
            /* Phase-1 boot pre-roll: prime the ring to ~200 ms before playback so
             * the cold-start hitch (JIT warm-up / first audio bursts) is concealed.
             * The added latency is irrelevant pre-gameplay; the servo drains the
             * excess down to target_ms over time. Underrun time-stretch concealment
             * (stretch_enable) is on by default via rab_config_defaults. */
            rc.preroll_ms = 200.0;
            s_bridge_ready = (rab_init(&s_bridge, &rc) == 0);
            SDL_PauseAudioDevice(s_audio_dev, 0); /* start playback */
            printf("[APU] Audio device opened: %d Hz, %d ch  (bridge=%s, target=%.0fms)\n",
                   got.freq, got.channels, s_bridge_ready ? "on" : "FAILED", rc.target_ms);
            if (recomp_audio_debug_init())
                printf("[audio-debug] capture ON (synth=%d)\n", recomp_audio_synth_mode());
        }
    }

    startup_timing_mark("audio_opened");
    {
        char window_title[64];
        snprintf(window_title, sizeof(window_title), "NESRecomp - %s", game_get_name());
        /* Exercise the real video/audio startup without taking desktop focus. */
        const char *test_hidden = getenv("NESRECOMP_TEST_HIDDEN");
        int hidden = test_hidden && test_hidden[0] == '1';
        Uint32 win_flags = SDL_WINDOW_RESIZABLE |
            (hidden ? SDL_WINDOW_HIDDEN : SDL_WINDOW_SHOWN);
        /* Launcher tri-state: 1 = borderless (desktop resolution, letterboxed by
         * SDL_RenderSetLogicalSize), 2 = exclusive (real display mode change). */
        if (!hidden && g_nes_config.fullscreen == 2) win_flags |= SDL_WINDOW_FULLSCREEN;
        else if (!hidden && g_nes_config.fullscreen == 1) win_flags |= SDL_WINDOW_FULLSCREEN_DESKTOP;
        int scale = g_nes_config.window_scale < 1 ? 1 : g_nes_config.window_scale;
        s_window = SDL_CreateWindow(window_title,
            SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
            g_render_width * scale, 240 * scale,
            win_flags);
    }
    if (!s_window) {
        fprintf(stderr, "SDL_CreateWindow: %s\n", SDL_GetError());
        exit(1);
    }

    /* Pixel-art scaling: nearest (crisp) by default, linear if the user opted in. */
    startup_timing_mark("window_created");
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY,
                g_nes_config.linear_filter ? "linear" : "nearest");

    Uint32 render_flags = SDL_RENDERER_PRESENTVSYNC |
        (g_nes_config.renderer == 1 ? SDL_RENDERER_SOFTWARE : SDL_RENDERER_ACCELERATED);
    s_renderer = SDL_CreateRenderer(s_window, -1, render_flags);
    if (!s_renderer) {
        fprintf(stderr, "SDL_CreateRenderer: %s\n", SDL_GetError());
        exit(1);
    }

    /* Preserve the NES aspect ratio (letterbox instead of stretch) and keep
     * scaling to whole-pixel multiples so every NES pixel stays the same size.
     * Applies to both windowed-resize and fullscreen. */
    startup_timing_mark("renderer_created");
    SDL_RenderSetLogicalSize(s_renderer, g_render_width, 240);
    SDL_RenderSetIntegerScale(s_renderer, g_nes_config.integer_scale ? SDL_TRUE : SDL_FALSE);

    s_texture = SDL_CreateTexture(s_renderer,
        SDL_PIXELFORMAT_ARGB8888,
        SDL_TEXTUREACCESS_STREAMING,
        g_render_width, 240);
    if (!s_texture) {
        fprintf(stderr, "SDL_CreateTexture: %s\n", SDL_GetError());
        exit(1);
    }
    SDL_RenderSetLogicalSize(s_renderer, g_render_width, 240);
    /* From here on geometry requests are queued and applied per frame
     * (video_apply_pending); seed the Fit mode with the real drawable size. */
    nes_video_mark_window_ready();
    {
        int out_w = 0, out_h = 0;
        SDL_GetRendererOutputSize(s_renderer, &out_w, &out_h);
        nes_video_on_window_resized(out_w, out_h);
    }

    /* HD texture pack (Mesen HD Pack): opt-in via the NESRECOMP_HDPACK env var
     * or config.ini [Display] HdPackEnabled/HdPackDir. When a pack loads, present
     * an HD-resolution texture and set the renderer logical size to match so the
     * upscaled art shows at full detail. Mirrors the SNES MSU-1 opt-in wiring. */
    if (hdpack_load_from_config(mapper_is_chr_ram(), g_render_width) == 0) {
        s_hd_scale = hdpack_scale();
        int hw = g_render_width * s_hd_scale, hh = 240 * s_hd_scale;
        s_hd_buf = (uint32_t *)malloc((size_t)hw * hh * sizeof(uint32_t));
        s_hd_texture = SDL_CreateTexture(s_renderer, SDL_PIXELFORMAT_ARGB8888,
                                         SDL_TEXTUREACCESS_STREAMING, hw, hh);
        if (s_hd_buf && s_hd_texture) {
            SDL_RenderSetLogicalSize(s_renderer, hw, hh);
            /* The HD logical size is larger than the native window, so integer
             * scaling would round to 0 and draw nothing. Use fractional fit and
             * size the window to the HD frame (capped to ~90% of the desktop). */
            SDL_RenderSetIntegerScale(s_renderer, SDL_FALSE);
            if (!g_nes_config.fullscreen) {
                int ww = hw, wh = hh;
                SDL_DisplayMode dm;
                if (SDL_GetCurrentDisplayMode(0, &dm) == 0) {
                    double sc = 1.0;
                    int maxw = (int)(dm.w * 0.9), maxh = (int)(dm.h * 0.9);
                    if (ww > maxw) sc = (double)maxw / ww;
                    if (wh * sc > maxh) sc = (double)maxh / wh;
                    ww = (int)(ww * sc); wh = (int)(wh * sc);
                }
                SDL_SetWindowSize(s_window, ww, wh);
                SDL_SetWindowPosition(s_window, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED);
            }
            printf("[HDPack] HD output enabled: %dx%d (%dx)\n", hw, hh, s_hd_scale);
        } else {
            fprintf(stderr, "[HDPack] HD texture/buffer alloc failed; using native output\n");
            free(s_hd_buf); s_hd_buf = NULL;
            if (s_hd_texture) { SDL_DestroyTexture(s_hd_texture); s_hd_texture = NULL; }
            hdpack_unload();
            s_hd_scale = 1;
        }
    }

    memset(s_framebuf, 0, VIDEO_BUF_BYTES);

    /* Present-time palette LUT: default Raw (passthrough, byte-identical);
     * opt in via NESRECOMP_PALETTE={raw,2c02,fbx}. */
    color_lut_init_from_env();

    /* Hide OS cursor when the Zapper crosshair replaces it */
    if (g_zapper_enabled && keybinds_zapper_mouse() && keybinds_zapper_crosshair())
        SDL_ShowCursor(SDL_DISABLE);

    /* OAM debug window — created only when --debug is passed */
    if (s_debug) {
        s_dbg_window = SDL_CreateWindow(
            "OAM Debug",
            SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
            512, 512,   /* 256x256 content at 2x display scale */
            SDL_WINDOW_SHOWN
        );
        if (s_dbg_window) {
            s_dbg_renderer = SDL_CreateRenderer(s_dbg_window, -1,
                SDL_RENDERER_ACCELERATED);
            if (s_dbg_renderer) {
                s_dbg_texture = SDL_CreateTexture(s_dbg_renderer,
                    SDL_PIXELFORMAT_ARGB8888,
                    SDL_TEXTUREACCESS_STREAMING,
                    256, 256);
                if (!s_dbg_texture)
                    fprintf(stderr, "[Debug] SDL_CreateTexture: %s\n", SDL_GetError());
                else
                    printf("[Debug] OAM window created (256x256 content, 512x512 display)\n");
            } else {
                fprintf(stderr, "[Debug] SDL_CreateRenderer: %s\n", SDL_GetError());
            }
        } else {
            fprintf(stderr, "[Debug] SDL_CreateWindow: %s\n", SDL_GetError());
        }
    }

    /* RAM Watch window — created alongside OAM debug window */
    if (s_debug) {
        /* ---- Watched variables ---- */

        int wh = s_watch_count * WATCH_ENTRY_H + 20 + MAX_MISS_UNIQUE * 6 + 60; /* watch + miss list */
        s_watch_window = SDL_CreateWindow(
            "RAM Watch",
            SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
            WATCH_W, wh,
            SDL_WINDOW_SHOWN
        );
        if (s_watch_window) {
            s_watch_renderer = SDL_CreateRenderer(s_watch_window, -1,
                SDL_RENDERER_ACCELERATED);
            if (s_watch_renderer)
                printf("[Debug] Watch window created (%d entries)\n", s_watch_count);
        }
    }

    /* Don't force window on top — let the user manage window stacking */

    printf("[Runner] Starting main game loop...\n");
    fflush(stdout); /* publish buffered startup as a block, not byte by byte */
    startup_timing_mark("game_loop");

    /* game_run_main() defaults to func_RESET() (native recompiled main loop,
     * never returns). In emulated mode, it runs FCEUX frames in a loop. */
#ifdef NESRECOMP_NET
    s_netplay_return_ready = 1;
    if (setjmp(s_netplay_return) == 0)
#endif
        run_guest_execution();
#ifdef NESRECOMP_NET
    s_netplay_return_ready = 0;
#endif

    /* Unreachable for most games, but clean up anyway */
    if (s_audio_dev) { SDL_CloseAudioDevice(s_audio_dev); s_audio_dev = 0; }
    if (s_bridge_ready) { rab_free(&s_bridge); s_bridge_ready = 0; }
    if (s_audio_mtx) { SDL_DestroyMutex(s_audio_mtx); s_audio_mtx = NULL; }
    save_ram_flush();
    debug_server_shutdown();
    controller_shutdown();
    if (s_hd_texture) { SDL_DestroyTexture(s_hd_texture); s_hd_texture = NULL; }
    free(s_hd_buf); s_hd_buf = NULL; hdpack_unload();
    if (s_texture) { SDL_DestroyTexture(s_texture); s_texture = NULL; }
    if (s_renderer) { SDL_DestroyRenderer(s_renderer); s_renderer = NULL; }
    if (s_window) { SDL_DestroyWindow(s_window); s_window = NULL; }
    if (s_dbg_texture) { SDL_DestroyTexture(s_dbg_texture); s_dbg_texture = NULL; }
    if (s_dbg_renderer) { SDL_DestroyRenderer(s_dbg_renderer); s_dbg_renderer = NULL; }
    if (s_dbg_window) { SDL_DestroyWindow(s_dbg_window); s_dbg_window = NULL; }
    if (s_watch_renderer) { SDL_DestroyRenderer(s_watch_renderer); s_watch_renderer = NULL; }
    if (s_watch_window) { SDL_DestroyWindow(s_watch_window); s_watch_window = NULL; }
    SDL_Quit();
    free(s_prg_data); s_prg_data = NULL;
#ifdef NESRECOMP_NET
    if (nes_netplay_active()) {
        nes_netplay_shutdown();
        g_nes_session_locked = 0;
        return 1;
    }
#endif
    return 0;
}
