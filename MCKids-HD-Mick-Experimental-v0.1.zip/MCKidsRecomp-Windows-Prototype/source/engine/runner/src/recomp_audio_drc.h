/* recomp_audio_drc.h - shared audio clock-domain bridge for the *recomp ecosystems.
 *
 * One persistent band-limited polyphase windowed-sinc fractional resampler driven
 * by a P-only normalized-fill controller, fed by a millisecond-measured SPSC ring,
 * with smooth fade-based startup / underrun / overflow handling.
 *
 * It exists because every runner (NES/SNES/GBA/N64/Genesis) is video-master /
 * audio-slaved: guest audio is produced ~1 frame per wall-clock frame while the
 * host device consumes at its own crystal rate. The unsynchronized clocks drift,
 * and the historical "fix" was to discard samples (drop/flush/decimate or a
 * nearest-neighbor servo) -- every discard is a click, and continuous micro
 * discard/dup is a sustained crackle. This bridge replaces all of that: the
 * controller nudges the *resample ratio* by <= +/-0.5% to hold the ring near a
 * target fill, and the band-limited resampler keeps the waveform continuous.
 *
 * Single-file. Define RECOMP_AUDIO_DRC_IMPL in exactly ONE translation unit.
 * C99 and C++ compatible. Depends only on the C stdlib + libm.
 *
 * Threading: rab_push() is called by the producer (emulation thread), rab_pull()
 * by the consumer (host audio callback). One producer, one consumer. The shared
 * state touched across threads (in_count / out_pos / ring) is accessed in a
 * single-producer/single-consumer pattern; integate with whatever memory ordering
 * the host runner already uses for its existing queue (a mutex around push/pull is
 * fine and is what most of these runners already have).
 */
#ifndef RECOMP_AUDIO_DRC_H
#define RECOMP_AUDIO_DRC_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int    channels;        /* 1 or 2                                          */
    double source_rate;     /* nominal guest source sample rate (Hz)           */
    double host_rate;       /* host device sample rate (Hz)                     */
    int    taps;            /* prototype length; 16 min, 32 preferred          */
    int    phases;          /* fractional phases; 256-1024 (512 default)       */
    double target_ms;       /* steady-state ring fill target (default 50)      */
    double ring_ms;         /* ring capacity in ms (default 150)               */
    double kp;              /* proportional gain (default 0.02)                */
    double max_correction;  /* clamp on ratio correction (default 0.005)       */
    double err_lp_ms;       /* error low-pass time constant ms (default 75)    */
    double slew_pp_per_s;   /* correction slew, percent-points/sec (default 0.75) */
    double deadband_ms;     /* +/- band around target with no correction (1.0)  */
    double em_low_ms;       /* below this = underrun emergency (default 12)     */
    double em_high_ms;      /* above this = overflow emergency (default 105)    */
    /* --- Phase-1 stall concealment (brief transition/startup producer stalls) --- */
    double preroll_ms;      /* initial prime cushion; 0 => prime at target_ms.      *
                             * A boot pre-roll hides the cold-start hitch for free   *
                             * (latency before gameplay is irrelevant); the servo    *
                             * drains the excess down to target over time.           */
    int    stretch_enable;  /* 1 = conceal underruns by pitch-preserving loop of the *
                             * most recent audio instead of fading to silence (1)    */
    double stretch_min_ms;  /* min loop period / correlation search floor (5)        */
    double stretch_max_ms;  /* max loop period / correlation search ceil  (25)       */
    double stretch_xfade_ms;/* loop-wrap crossfade length (4)                        */
} rab_config;

typedef struct {
    uint64_t pushed_frames;
    uint64_t pulled_frames;
    uint64_t underrun_events;   /* times the ring ran dry mid-pull            */
    uint64_t overflow_drops;    /* source frames dropped on ring overflow     */
    uint64_t stretch_frames;    /* output frames synthesized by stall conceal */
    uint64_t stretch_events;    /* distinct stall episodes concealed          */
    double   last_fill_ms;
    double   last_correction;   /* applied ratio correction (signed)          */
} rab_stats;

typedef struct rab_bridge {
    rab_config cfg;
    int    half;            /* taps/2                                          */
    float *coeffs;          /* phases*taps, DC-normalized per phase            */
    float *ring;            /* cap_frames*channels, interleaved float          */
    int64_t cap;            /* ring capacity in frames                         */

    /* SPSC stream position */
    uint64_t in_count;      /* frames ever pushed (monotonic)                  */
    double   out_pos;       /* fractional source-frame read cursor             */

    /* controller */
    double cur_step;        /* current source frames consumed per output frame */
    double err_lp;          /* low-passed normalized error                     */
    double corr;            /* current (slew-limited) correction               */

    /* fade / emergency */
    double gain;            /* 0..1 smooth gate for startup/underrun           */
    int    primed;          /* set once fill first reaches prime_ms            */
    double prime_ms;        /* fill needed to prime (preroll_ms or target_ms)  */
    float  last_out[2];     /* last emitted sample per channel (for holds)     */

    /* stall concealment (pitch-preserving loop of recent audio on starvation) */
    int    concealing;      /* currently looping to conceal a producer stall   */
    double loop_start;      /* source-frame index: start of the looped region  */
    double loop_len;        /* looped region length in source frames           */
    double loop_pos;        /* fractional read cursor within the looped region */

    rab_stats stats;
} rab_bridge;

/* Fill a config with the locked-in ecosystem defaults. You must still set
 * channels, source_rate and host_rate afterwards. */
void rab_config_defaults(rab_config *c);

/* Allocate internal buffers and build the polyphase filter bank. Returns 0 on
 * success, non-zero on allocation/parameter failure. */
int  rab_init(rab_bridge *b, const rab_config *cfg);
void rab_free(rab_bridge *b);

/* Producer: append `frames` interleaved int16 source samples. Thread: emu side. */
void rab_push(rab_bridge *b, const int16_t *interleaved, int frames);

/* Consumer: render exactly `frames` interleaved int16 host samples (never
 * blocks; emits faded silence on underrun / before prime). Thread: callback. */
void rab_pull(rab_bridge *b, int16_t *out, int frames);

/* Current ring fill expressed in milliseconds of source audio. */
double rab_fill_ms(const rab_bridge *b);

void rab_get_stats(const rab_bridge *b, rab_stats *out);

#ifdef __cplusplus
}
#endif

/* ---------------------------------------------------------------------------- */
#ifdef RECOMP_AUDIO_DRC_IMPL

#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef RAB_PI
#define RAB_PI 3.14159265358979323846
#endif

static double rab__sinc(double x) {
    if (x > -1e-9 && x < 1e-9) return 1.0;
    double p = RAB_PI * x;
    return sin(p) / p;
}

/* Blackman window over [-1,1] mapped from t/half. */
static double rab__blackman(double tn) { /* tn in [-1,1] */
    double a = RAB_PI * (tn + 1.0); /* 0..2pi */
    return 0.42 - 0.5 * cos(a) + 0.08 * cos(2.0 * a);
}

void rab_config_defaults(rab_config *c) {
    c->channels       = 2;
    c->source_rate    = 48000.0;
    c->host_rate      = 48000.0;
    c->taps           = 32;
    c->phases         = 512;
    c->target_ms      = 50.0;
    c->ring_ms        = 150.0;
    c->kp             = 0.02;
    c->max_correction = 0.005;
    c->err_lp_ms      = 75.0;
    c->slew_pp_per_s  = 0.75;
    c->deadband_ms    = 1.0;
    c->em_low_ms      = 12.0;
    c->em_high_ms     = 105.0;
    c->preroll_ms       = 0.0;    /* 0 => prime at target_ms (no extra boot cushion) */
    c->stretch_enable   = 1;
    c->stretch_min_ms   = 5.0;
    c->stretch_max_ms   = 25.0;
    c->stretch_xfade_ms = 4.0;
}

int rab_init(rab_bridge *b, const rab_config *cfg) {
    if (!b || !cfg) return 1;
    if (cfg->channels < 1 || cfg->channels > 2) return 2;
    if (cfg->taps < 4 || (cfg->taps & 1)) return 3;
    if (cfg->phases < 16) return 4;
    if (cfg->source_rate <= 0.0 || cfg->host_rate <= 0.0) return 5;

    memset(b, 0, sizeof(*b));
    b->cfg  = *cfg;
    b->half = cfg->taps / 2;

    /* Prototype lowpass cutoff (normalized to source Nyquist). When downsampling
     * (host < source) we must pull the cutoff in to suppress aliases; when
     * upsampling we keep the full source band. A small guard avoids the corner. */
    double fc = (cfg->host_rate < cfg->source_rate)
                    ? (cfg->host_rate / cfg->source_rate) : 1.0;
    fc *= 0.92;

    size_t ncoef = (size_t)cfg->phases * (size_t)cfg->taps;
    b->coeffs = (float *)malloc(ncoef * sizeof(float));
    if (!b->coeffs) return 6;

    for (int p = 0; p < cfg->phases; ++p) {
        double frac = (double)p / (double)cfg->phases; /* [0,1) sub-sample delay */
        double sum = 0.0;
        float *row = b->coeffs + (size_t)p * cfg->taps;
        for (int k = 0; k < cfg->taps; ++k) {
            /* input tap index relative to the interpolation point */
            double t = (double)(k - (b->half - 1)) - frac;
            double tn = t / (double)b->half;          /* window arg in [-~1,~1] */
            double w  = (tn <= -1.0 || tn >= 1.0) ? 0.0 : rab__blackman(tn);
            double h  = fc * rab__sinc(fc * t) * w;
            row[k] = (float)h;
            sum += h;
        }
        /* normalize each phase to unit DC gain to kill level ripple / zipper */
        if (sum > 1e-12) {
            float inv = (float)(1.0 / sum);
            for (int k = 0; k < cfg->taps; ++k) row[k] *= inv;
        }
    }

    double cap_ms = cfg->ring_ms;
    if (cap_ms < cfg->target_ms + 40.0) cap_ms = cfg->target_ms + 40.0;
    if (cap_ms < cfg->preroll_ms + 40.0) cap_ms = cfg->preroll_ms + 40.0; /* hold the boot pre-roll */
    b->cap = (int64_t)(cfg->source_rate * cap_ms / 1000.0) + cfg->taps + 2;
    b->ring = (float *)calloc((size_t)b->cap * cfg->channels, sizeof(float));
    if (!b->ring) { free(b->coeffs); b->coeffs = NULL; return 7; }

    b->in_count = 0;
    /* Start the read cursor half a window in so the polyphase filter always has
     * valid history behind it; otherwise the first half-1 outputs can't be
     * computed and the cursor would never advance. */
    b->out_pos  = (double)(b->half - 1);
    b->cur_step = cfg->source_rate / cfg->host_rate;
    b->err_lp   = 0.0;
    b->corr     = 0.0;
    b->gain     = 0.0;
    b->primed   = 0;
    b->prime_ms = (cfg->preroll_ms > cfg->target_ms) ? cfg->preroll_ms : cfg->target_ms;
    b->concealing = 0;
    b->loop_start = b->loop_len = b->loop_pos = 0.0;
    return 0;
}

void rab_free(rab_bridge *b) {
    if (!b) return;
    free(b->coeffs); b->coeffs = NULL;
    free(b->ring);   b->ring   = NULL;
}

double rab_fill_ms(const rab_bridge *b) {
    double fill = (double)b->in_count - b->out_pos;
    if (fill < 0.0) fill = 0.0;
    return fill * 1000.0 / b->cfg.source_rate;
}

void rab_push(rab_bridge *b, const int16_t *in, int frames) {
    int ch = b->cfg.channels;
    for (int f = 0; f < frames; ++f) {
        double fill = (double)b->in_count - b->out_pos;
        if (fill >= (double)(b->cap - 1)) {
            /* Overflow emergency: producer outran consumer past the ring. Drop the
             * oldest source frame by nudging the read cursor forward. Rare under
             * DRC; the resampler's continuous history limits the audible seam. */
            b->out_pos += 1.0;
            b->stats.overflow_drops++;
        }
        int64_t w = (int64_t)(b->in_count % (uint64_t)b->cap);
        float *slot = b->ring + w * ch;
        for (int c = 0; c < ch; ++c)
            slot[c] = (float)in[f * ch + c] * (1.0f / 32768.0f);
        b->in_count++;
    }
    b->stats.pushed_frames += (uint64_t)frames;
}

static void rab__update_controller(rab_bridge *b) {
    rab_config *c = &b->cfg;
    double fill_ms = rab_fill_ms(b);
    b->stats.last_fill_ms = fill_ms;

    if (!b->primed && fill_ms >= b->prime_ms) b->primed = 1;

    /* one control update per pull; low-pass the normalized error. Use the pull
     * block duration as dt (approx via host_rate is unnecessary here -- we fold
     * the time constant into a per-update smoothing alpha sized for ~10-20ms). */
    double err = (fill_ms - c->target_ms) / c->target_ms;
    if (fill_ms > c->target_ms - c->deadband_ms &&
        fill_ms < c->target_ms + c->deadband_ms) {
        err = 0.0; /* deadband */
    }
    /* smoothing alpha: assume ~one update per host audio block (~10ms typical). */
    double dt_ms = 12.0;
    double alpha = dt_ms / (c->err_lp_ms + dt_ms);
    b->err_lp += alpha * (err - b->err_lp);

    double target_corr = c->kp * b->err_lp;
    if (target_corr >  c->max_correction) target_corr =  c->max_correction;
    if (target_corr < -c->max_correction) target_corr = -c->max_correction;

    /* slew limit (percentage points per second -> fraction per update) */
    double slew = (c->slew_pp_per_s / 100.0) * (dt_ms / 1000.0);
    double d = target_corr - b->corr;
    if (d >  slew) d =  slew;
    if (d < -slew) d = -slew;
    b->corr += d;

    /* A high queue (positive error) must be consumed FASTER -> larger step. */
    b->cur_step = (c->source_rate / c->host_rate) * (1.0 + b->corr);
    b->stats.last_correction = b->corr;
}

/* Evaluate the polyphase resampler at an absolute fractional source position.
 * Caller guarantees [floor(pos)-half+1 .. floor(pos)+half] are live ring frames. */
static void rab__sample_at(const rab_bridge *b, double pos, float *s) {
    int ch = b->cfg.channels;
    int64_t i  = (int64_t)floor(pos);
    double  fr = pos - (double)i;
    int phase = (int)(fr * b->cfg.phases);
    if (phase >= b->cfg.phases) phase = b->cfg.phases - 1;
    if (phase < 0) phase = 0;
    const float *cz = b->coeffs + (size_t)phase * b->cfg.taps;
    float s0 = 0.0f, s1 = 0.0f;
    for (int k = 0; k < b->cfg.taps; ++k) {
        int64_t m = i - b->half + 1 + k;
        if (m < 0) m = 0;
        const float *sl = b->ring + (m % b->cap) * ch;
        s0 += cz[k] * sl[0];
        if (ch == 2) s1 += cz[k] * sl[1];
    }
    s[0] = s0; s[1] = (ch == 2) ? s1 : 0.0f;
}

/* Choose a loop length (source frames) ending at end_i whose period best matches
 * the signal one period earlier (normalized cross-correlation on ch0), so the
 * loop wrap is pitch-continuous instead of buzzy. */
static double rab__find_loop_len(const rab_bridge *b, int64_t end_i) {
    int ch = b->cfg.channels;
    double sr = b->cfg.source_rate;
    int Lmin = (int)(b->cfg.stretch_min_ms * sr / 1000.0); if (Lmin < 1) Lmin = 1;
    int Lmax = (int)(b->cfg.stretch_max_ms * sr / 1000.0); if (Lmax < Lmin) Lmax = Lmin;
    int W = Lmin; if (W < 1) W = 1;
    int64_t oldest = (int64_t)b->in_count - b->cap + b->half + 2;
    if (oldest < (int64_t)b->half) oldest = (int64_t)b->half;
    while (Lmax > Lmin && (end_i - Lmax - W) < oldest) Lmax--;
    if ((end_i - Lmax - W) < oldest) return (double)Lmin;
    double best = -1e30; int bestL = Lmin;
    for (int L = Lmin; L <= Lmax; ++L) {
        double num = 0.0, d1 = 0.0, d2 = 0.0;
        for (int k = 0; k < W; ++k) {
            float a = b->ring[((end_i - k)     % b->cap) * ch];
            float c = b->ring[((end_i - L - k) % b->cap) * ch];
            num += (double)a * c; d1 += (double)a * a; d2 += (double)c * c;
        }
        double r = num / (sqrt(d1 * d2) + 1e-9);
        if (r > best) { best = r; bestL = L; }
    }
    return (double)bestL;
}

void rab_pull(rab_bridge *b, int16_t *out, int frames) {
    int ch = b->cfg.channels;
    rab__update_controller(b);

    double gstep = 1.0 / (b->cfg.host_rate * 0.003); /* ~3ms fade in/out */
    double step  = b->cur_step;
    double xf    = b->cfg.stretch_xfade_ms * b->cfg.source_rate / 1000.0;
    if (xf < 1.0) xf = 1.0;

    for (int f = 0; f < frames; ++f) {
        int64_t i   = (int64_t)floor(b->out_pos);
        int64_t newest_needed = i + b->half;
        int     have = b->primed && (newest_needed < (int64_t)b->in_count)
                       && ((i - b->half + 1) >= 0);

        float s[2] = {0.0f, 0.0f};
        int   delivering = 0;

        if (have) {
            /* live forward play; caught up to real audio, so leave conceal mode */
            b->concealing = 0;
            double fr = b->out_pos - (double)i;
            int phase = (int)(fr * b->cfg.phases);
            if (phase >= b->cfg.phases) phase = b->cfg.phases - 1;
            const float *cz = b->coeffs + (size_t)phase * b->cfg.taps;
            for (int k = 0; k < b->cfg.taps; ++k) {
                int64_t m = i - b->half + 1 + k;
                const float *sl = b->ring + (m % b->cap) * ch;
                s[0] += cz[k] * sl[0];
                if (ch == 2) s[1] += cz[k] * sl[1];
            }
            b->out_pos += step;             /* advance only when we consumed live */
            delivering = 1;
        } else if (b->primed && b->cfg.stretch_enable
                   && (int64_t)b->in_count > (int64_t)(2 * b->half + 4)) {
            /* Producer stalled: conceal by looping the most recent audio,
             * pitch-aligned, instead of fading to silence. out_pos is held at the
             * stall edge so live play resumes seamlessly once the producer
             * recovers (the concealed time becomes latency the servo drains). */
            if (!b->concealing) {
                int64_t end_i = (int64_t)b->in_count - b->half - 1;
                if (end_i < (int64_t)b->half + 2) end_i = (int64_t)b->half + 2;
                b->loop_len   = rab__find_loop_len(b, end_i);
                b->loop_start = (double)end_i - b->loop_len;
                if (b->loop_start < (double)b->half) b->loop_start = (double)b->half;
                b->loop_pos   = b->loop_start;
                b->concealing = 1;
                b->stats.stretch_events++;
            }
            double loop_end = b->loop_start + b->loop_len;
            rab__sample_at(b, b->loop_pos, s);
            double into_xf = b->loop_pos - (loop_end - xf);
            if (into_xf > 0.0 && b->loop_len > xf) {   /* pitch-continuous wrap */
                float sw[2];
                rab__sample_at(b, b->loop_pos - b->loop_len, sw);
                double w = into_xf / xf; if (w > 1.0) w = 1.0;
                s[0] = (float)((1.0 - w) * s[0] + w * sw[0]);
                if (ch == 2) s[1] = (float)((1.0 - w) * s[1] + w * sw[1]);
            }
            b->loop_pos += step;
            if (b->loop_pos >= loop_end) b->loop_pos -= b->loop_len;
            b->stats.stretch_frames++;
            delivering = 1;
        } else {
            /* not primed, or no history to loop: hold last sample, fade to silence */
            s[0] = b->last_out[0];
            if (ch == 2) s[1] = b->last_out[1];
            if (b->primed && newest_needed >= (int64_t)b->in_count)
                b->stats.underrun_events++;
        }

        if (delivering) {
            b->last_out[0] = s[0];
            if (ch == 2) b->last_out[1] = s[1];
        }

        /* smooth gate: fade toward 1 when delivering audio, toward 0 else */
        double target_gain = delivering ? 1.0 : 0.0;
        if (b->gain < target_gain) {
            b->gain += gstep; if (b->gain > target_gain) b->gain = target_gain;
        } else if (b->gain > target_gain) {
            b->gain -= gstep; if (b->gain < target_gain) b->gain = target_gain;
        }

        for (int c = 0; c < ch; ++c) {
            double v = (double)s[c] * b->gain * 32768.0;
            if (v >  32767.0) v =  32767.0;
            if (v < -32768.0) v = -32768.0;
            out[f * ch + c] = (int16_t)lrint(v);
        }
    }
    b->stats.pulled_frames += (uint64_t)frames;
}

void rab_get_stats(const rab_bridge *b, rab_stats *out) { *out = b->stats; }

#endif /* RECOMP_AUDIO_DRC_IMPL */
#endif /* RECOMP_AUDIO_DRC_H */
