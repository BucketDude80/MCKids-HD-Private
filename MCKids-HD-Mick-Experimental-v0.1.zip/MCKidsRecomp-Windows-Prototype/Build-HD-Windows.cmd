@echo off
setlocal
cd /d "%~dp0"
echo Building the experimental M.C. Kids HD renderer...
where cmake >nul 2>nul
if errorlevel 1 (
  echo CMake not found. Install Visual Studio 2022 with Desktop development with C++ and CMake.
  pause
  exit /b 1
)
cmake -S "source" -B "source\build-hd-windows" -G "Visual Studio 17 2022" -A x64 -DNESRECOMP_ROM="%CD%\MCKids.nes"
if errorlevel 1 goto :failed
cmake --build "source\build-hd-windows" --config Release --parallel 4
if errorlevel 1 goto :failed
if not exist "source\build-hd-windows\Release\MCKidsRecomp.exe" goto :failed
copy /Y "source\build-hd-windows\Release\MCKidsRecomp.exe" "MCKidsRecomp-HD.exe" >nul
if errorlevel 1 goto :failed
copy /Y "source\engine\runner\external\SDL2\lib\x64\SDL2.dll" "SDL2.dll" >nul
if errorlevel 1 goto :failed
echo.
echo HD executable created: MCKidsRecomp-HD.exe
echo Next: Launch-HD.cmd or Launch-HD-Widescreen.cmd
pause
exit /b 0
:failed
echo Build failed. Original MCKidsRecomp.exe has not been modified.
pause
exit /b 1
