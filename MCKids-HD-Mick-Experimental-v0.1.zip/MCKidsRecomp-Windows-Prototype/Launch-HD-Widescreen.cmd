@echo off
cd /d "%~dp0"
if not exist "MCKidsRecomp-HD.exe" (
 echo The new HD-enabled EXE has not been built yet.
 echo Run Build-HD-Windows.cmd first. The existing EXEs do not contain HD code.
 pause
 exit /b 1
)
"MCKidsRecomp-HD.exe" "MCKids.nes" --hd-mick --widescreen
if errorlevel 1 pause
