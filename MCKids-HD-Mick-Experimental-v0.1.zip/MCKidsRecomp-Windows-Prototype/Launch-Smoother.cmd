@echo off
call "%~dp0Launch.cmd" --extra-scanlines 128
