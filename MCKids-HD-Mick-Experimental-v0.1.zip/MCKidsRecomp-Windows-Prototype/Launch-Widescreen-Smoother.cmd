@echo off
call "%~dp0Launch-Widescreen.cmd" --extra-scanlines 128
